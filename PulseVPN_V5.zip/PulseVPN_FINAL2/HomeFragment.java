package com.pulsevpn.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeFragment extends Fragment {
    private TextView tvStatus, tvTimer, tvDl, tvUl, tvIp, tvIpLocation, tvIpFlag;
    private TextView btnConnect, tvSelFlag, tvSelName, tvSelSub, tvSelPing, tvSelLabel;
    private TextView btnAddServer, btnUseCustom, btnDeleteCustom;
    private TextView tvCustomName, tvCustomHost, tvCustomProto;
    private TextView btnWg, btnOvpn, btnAutoProto;
    private LinearLayout statsRow, customServerCard, customServerEmpty;
    private View ring1, ring2;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable timerRunnable, speedRunnable, pulseRunnable;
    private AppState st;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Random rnd = new Random();
    private SharedPreferences prefs;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inf.inflate(R.layout.fragment_home, container, false);
        st = AppState.get();
        prefs = requireContext().getSharedPreferences("pulsevpn", Context.MODE_PRIVATE);
        String saved = prefs.getString("custom_server", null);
        if (saved != null) st.customServer = CustomServer.deserialize(saved);
        bindViews(v);
        setupListeners();
        refreshCustomServerUI();
        updateSelectedCard();
        updateUI();
        setIpDefault();
        fetchRealIpSafe();
        if (st.connected) { startTimer(); startSpeedSim(); startPulse(); }
        return v;
    }

    private void bindViews(View v) {
        tvStatus = v.findViewById(R.id.tv_status);
        tvTimer = v.findViewById(R.id.tv_timer);
        tvDl = v.findViewById(R.id.tv_dl);
        tvUl = v.findViewById(R.id.tv_ul);
        tvIp = v.findViewById(R.id.tv_ip);
        tvIpLocation = v.findViewById(R.id.tv_ip_location);
        tvIpFlag = v.findViewById(R.id.tv_ip_flag);
        statsRow = v.findViewById(R.id.stats_row);
        btnConnect = v.findViewById(R.id.btn_connect);
        ring1 = v.findViewById(R.id.ring1);
        ring2 = v.findViewById(R.id.ring2);
        btnWg = v.findViewById(R.id.btn_wg);
        btnOvpn = v.findViewById(R.id.btn_ovpn);
        btnAutoProto = v.findViewById(R.id.btn_auto_proto);
        tvSelFlag = v.findViewById(R.id.tv_sel_flag);
        tvSelLabel = v.findViewById(R.id.tv_sel_label);
        tvSelName = v.findViewById(R.id.tv_sel_name);
        tvSelSub = v.findViewById(R.id.tv_sel_sub);
        tvSelPing = v.findViewById(R.id.tv_sel_ping);
        btnAddServer = v.findViewById(R.id.btn_add_server);
        customServerCard = v.findViewById(R.id.custom_server_card);
        customServerEmpty = v.findViewById(R.id.custom_server_empty);
        tvCustomName = v.findViewById(R.id.tv_custom_name);
        tvCustomHost = v.findViewById(R.id.tv_custom_host);
        tvCustomProto = v.findViewById(R.id.tv_custom_proto);
        btnUseCustom = v.findViewById(R.id.btn_use_custom);
        btnDeleteCustom = v.findViewById(R.id.btn_delete_custom);
    }

    private void setupListeners() {
        if (btnConnect != null) btnConnect.setOnClickListener(v -> onConnectClick());
        if (btnWg != null) btnWg.setOnClickListener(v -> setProtocol("wireguard"));
        if (btnOvpn != null) btnOvpn.setOnClickListener(v -> setProtocol("openvpn"));
        if (btnAutoProto != null) btnAutoProto.setOnClickListener(v -> setProtocol("auto"));
        if (btnAddServer != null) btnAddServer.setOnClickListener(v -> showAddServerDialog());
        if (btnUseCustom != null) btnUseCustom.setOnClickListener(v -> selectCustomServer());
        if (btnDeleteCustom != null) btnDeleteCustom.setOnClickListener(v -> deleteCustomServer());
    }

    private void onConnectClick() {
        if (st.connecting) return;
        if (st.connected) doDisconnect(); else doConnect();
    }

    private void doConnect() {
        st.connecting = true; updateUI();
        handler.postDelayed(() -> {
            if (!isAdded()) return;
            st.connecting = false; st.connected = true;
            updateUI(); startTimer(); startSpeedSim(); startPulse();
            String name = st.isCustomSelected() ? "🔧 " + st.customServer.name :
                (st.getSelectedServer() != null ? st.getSelectedServer().flag + " " + st.getSelectedServer().name : "⚡ Smart");
            toast("✅ Подключён — " + name);
            updateIpConnected();
        }, 2200);
    }

    private void doDisconnect() {
        st.connected = false; st.connecting = false; st.timerSec = 0;
        stopAll(); updateUI(); toast("🔌 Отключён");
        setIpDefault(); fetchRealIpSafe();
    }

    private void updateUI() {
        if (!isAdded() || btnConnect == null) return;
        int green = 0xFF00FF88, yellow = 0xFFFFCC00, dim = 0xFF8CA8A0;
        if (st.connected) {
            tvStatus.setText("● ПОДКЛЮЧЁН"); tvStatus.setTextColor(green);
            btnConnect.setText("⏻\nОТКЛЮЧИТЬ"); btnConnect.setTextColor(green);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_connected);
            statsRow.setVisibility(View.VISIBLE); tvTimer.setVisibility(View.VISIBLE);
        } else if (st.connecting) {
            tvStatus.setText("● ПОДКЛЮЧЕНИЕ…"); tvStatus.setTextColor(yellow);
            btnConnect.setText("⏻\n…"); btnConnect.setTextColor(yellow);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_normal);
            statsRow.setVisibility(View.GONE); tvTimer.setVisibility(View.GONE);
            AlphaAnimation a = new AlphaAnimation(0.3f, 1f);
            a.setDuration(600); a.setRepeatMode(Animation.REVERSE); a.setRepeatCount(Animation.INFINITE);
            btnConnect.startAnimation(a);
        } else {
            tvStatus.setText("● НЕ ПОДКЛЮЧЁН"); tvStatus.setTextColor(dim);
            btnConnect.setText("⏻\nCONNECT"); btnConnect.setTextColor(dim);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_normal);
            btnConnect.clearAnimation();
            statsRow.setVisibility(View.GONE); tvTimer.setVisibility(View.GONE);
        }
    }

    private void startTimer() {
        timerRunnable = new Runnable() { public void run() {
            if (!isAdded() || !st.connected) return;
            st.timerSec++;
            if (tvTimer != null) tvTimer.setText(String.format(Locale.US, "%02d:%02d:%02d",
                st.timerSec/3600, (st.timerSec%3600)/60, st.timerSec%60));
            handler.postDelayed(this, 1000);
        }};
        handler.post(timerRunnable);
    }

    private void startSpeedSim() {
        speedRunnable = new Runnable() { public void run() {
            if (!isAdded() || !st.connected) return;
            if (tvDl != null) tvDl.setText(String.format(Locale.US, "%.1f MB/s", 2+rnd.nextDouble()*8));
            if (tvUl != null) tvUl.setText(String.format(Locale.US, "%.1f MB/s", 0.5+rnd.nextDouble()*3));
            handler.postDelayed(this, 1000);
        }};
        handler.post(speedRunnable);
    }

    private void startPulse() {
        pulseRunnable = new Runnable() { boolean s=true; public void run() {
            if (!isAdded() || !st.connected) return;
            if (ring1!=null) ring1.animate().alpha(s?0.4f:0.1f).setDuration(800).start();
            if (ring2!=null) ring2.animate().alpha(s?0.25f:0.08f).setDuration(1000).start();
            s=!s; handler.postDelayed(this, 900);
        }};
        handler.post(pulseRunnable);
    }

    private void stopAll() {
        if (btnConnect != null) btnConnect.clearAnimation();
        if (timerRunnable != null) handler.removeCallbacks(timerRunnable);
        if (speedRunnable != null) handler.removeCallbacks(speedRunnable);
        if (pulseRunnable != null) handler.removeCallbacks(pulseRunnable);
        if (isAdded() && tvTimer != null) tvTimer.setText("");
        if (ring1 != null) ring1.setAlpha(0.15f);
        if (ring2 != null) ring2.setAlpha(0.2f);
    }

    private void setIpDefault() {
        if (!isAdded()) return;
        if (tvIp != null) tvIp.setText("Определяется…");
        if (tvIpLocation != null) tvIpLocation.setText("Загрузка…");
        if (tvIpFlag != null) tvIpFlag.setText("🌐");
    }

    private void fetchRealIpSafe() {
        executor.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("https://ipapi.co/json/").openConnection();
                c.setConnectTimeout(7000); c.setReadTimeout(7000);
                c.setRequestProperty("User-Agent","PulseVPN/2.0");
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line); br.close();
                org.json.JSONObject j = new org.json.JSONObject(sb.toString());
                String ip = j.optString("ip",""); String country = j.optString("country_name","") + ", " + j.optString("city","");
                String flag = countryToFlag(j.optString("country_code","").toUpperCase());
                st.realIp=ip; st.realCountry=country; st.realFlag=flag; st.ipLoaded=true;
                handler.post(() -> { if (!isAdded() || st.connected) return;
                    if (tvIp!=null) tvIp.setText(ip.isEmpty()?"Скрыт":ip);
                    if (tvIpLocation!=null) tvIpLocation.setText("📍 "+country);
                    if (tvIpFlag!=null) tvIpFlag.setText(flag); });
            } catch (Exception e) {
                handler.post(() -> { if (!isAdded()) return;
                    if (tvIp!=null) tvIp.setText("Скрыт");
                    if (tvIpLocation!=null) tvIpLocation.setText("📍 Россия");
                    if (tvIpFlag!=null) tvIpFlag.setText("🇷🇺"); });
            }
        });
    }

    private void updateIpConnected() {
        if (!isAdded()) return;
        Server srv = st.getSelectedServer();
        if (tvIp!=null) tvIp.setText("10."+rnd.nextInt(255)+"."+rnd.nextInt(255)+"."+rnd.nextInt(255));
        if (tvIpLocation!=null) tvIpLocation.setText("📍 "+(srv!=null?srv.city+", VPN":"VPN"));
        if (tvIpFlag!=null) tvIpFlag.setText(st.isCustomSelected()?"🔧":(srv!=null?srv.flag:"⚡"));
    }

    private String countryToFlag(String cc) {
        if (cc==null||cc.length()!=2) return "🌐";
        try { return new String(Character.toChars(cc.charAt(0)-'A'+0x1F1E6))+new String(Character.toChars(cc.charAt(1)-'A'+0x1F1E6)); }
        catch (Exception e) { return "🌐"; }
    }

    private void setProtocol(String p) {
        st.protocol = p;
        int black=Color.BLACK, dim=Color.parseColor("#8CA8A0");
        if (btnWg!=null) { btnWg.setBackgroundResource(p.equals("wireguard")?R.drawable.btn_proto_active:R.drawable.btn_proto_inactive); btnWg.setTextColor(p.equals("wireguard")?black:dim); }
        if (btnOvpn!=null) { btnOvpn.setBackgroundResource(p.equals("openvpn")?R.drawable.btn_proto_active:R.drawable.btn_proto_inactive); btnOvpn.setTextColor(p.equals("openvpn")?black:dim); }
        if (btnAutoProto!=null) { btnAutoProto.setBackgroundResource(p.equals("auto")?R.drawable.btn_proto_active:R.drawable.btn_proto_inactive); btnAutoProto.setTextColor(p.equals("auto")?black:dim); }
        toast("⚡ Протокол: "+(p.equals("wireguard")?"WireGuard":p.equals("openvpn")?"OpenVPN":"Auto"));
    }

    private void showAddServerDialog() {
        if (!isAdded()) return;
        try {
            View dv = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_server, null);
            TextView tabManual = dv.findViewById(R.id.tab_manual);
            TextView tabUrl = dv.findViewById(R.id.tab_url);
            LinearLayout panelManual = dv.findViewById(R.id.panel_manual);
            LinearLayout panelUrl = dv.findViewById(R.id.panel_url);
            EditText etName = dv.findViewById(R.id.et_name);
            EditText etHost = dv.findViewById(R.id.et_host);
            EditText etPort = dv.findViewById(R.id.et_port);
            EditText etUrl = dv.findViewById(R.id.et_url);
            EditText etUrlName = dv.findViewById(R.id.et_url_name);
            TextView protoWg = dv.findViewById(R.id.proto_wg);
            TextView protoOvpn = dv.findViewById(R.id.proto_ovpn);
            TextView btnSave = dv.findViewById(R.id.btn_save);
            TextView btnCancel = dv.findViewById(R.id.btn_cancel);
            TextView btnQr = dv.findViewById(R.id.btn_qr_scan);
            final String[] proto = {"wireguard"};
            final boolean[] isUrlMode = {false};

            // Tab switching
            if (tabManual!=null) tabManual.setOnClickListener(v2 -> {
                isUrlMode[0]=false;
                tabManual.setBackgroundResource(R.drawable.btn_green); tabManual.setTextColor(Color.BLACK);
                tabUrl.setBackground(null); tabUrl.setTextColor(Color.parseColor("#8CA8A0"));
                if(panelManual!=null) panelManual.setVisibility(View.VISIBLE);
                if(panelUrl!=null) panelUrl.setVisibility(View.GONE);
            });
            if (tabUrl!=null) tabUrl.setOnClickListener(v2 -> {
                isUrlMode[0]=true;
                tabUrl.setBackgroundResource(R.drawable.btn_green); tabUrl.setTextColor(Color.BLACK);
                tabManual.setBackground(null); tabManual.setTextColor(Color.parseColor("#8CA8A0"));
                if(panelUrl!=null) panelUrl.setVisibility(View.VISIBLE);
                if(panelManual!=null) panelManual.setVisibility(View.GONE);
            });

            if (protoWg!=null) protoWg.setOnClickListener(v2 -> { proto[0]="wireguard"; protoWg.setBackgroundResource(R.drawable.btn_proto_active); protoWg.setTextColor(Color.BLACK); if(protoOvpn!=null){protoOvpn.setBackgroundResource(R.drawable.btn_proto_inactive);protoOvpn.setTextColor(Color.parseColor("#8CA8A0"));} });
            if (protoOvpn!=null) protoOvpn.setOnClickListener(v2 -> { proto[0]="openvpn"; protoOvpn.setBackgroundResource(R.drawable.btn_proto_active); protoOvpn.setTextColor(Color.BLACK); if(protoWg!=null){protoWg.setBackgroundResource(R.drawable.btn_proto_inactive);protoWg.setTextColor(Color.parseColor("#8CA8A0"));} });

            if (st.customServer!=null && !st.customServer.isSubscription && etName!=null) { etName.setText(st.customServer.name); if(etHost!=null)etHost.setText(st.customServer.host); if(etPort!=null)etPort.setText(st.customServer.port); }

            AlertDialog dialog = new AlertDialog.Builder(requireContext()).setView(dv).create();
            if (dialog.getWindow()!=null) dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

            if (btnQr!=null) btnQr.setOnClickListener(v2 -> { dialog.dismiss(); toast("📷 QR-сканер: сканируй конфиг WireGuard!"); });
            if (btnCancel!=null) btnCancel.setOnClickListener(v2 -> dialog.dismiss());
            if (btnSave!=null) btnSave.setOnClickListener(v2 -> {
                if (isUrlMode[0]) {
                    String url = etUrl!=null?etUrl.getText().toString().trim():"";
                    if (url.isEmpty()||!url.startsWith("http")) { toast("⚠️ Введи правильный URL"); return; }
                    String nm = etUrlName!=null&&!etUrlName.getText().toString().trim().isEmpty()?etUrlName.getText().toString().trim():"URL подписка";
                    st.customServer = new CustomServer(nm, url);
                } else {
                    String host = etHost!=null?etHost.getText().toString().trim():"";
                    if (host.isEmpty()) { toast("⚠️ Введи хост или IP"); return; }
                    String nm = etName!=null&&!etName.getText().toString().trim().isEmpty()?etName.getText().toString().trim():host;
                    String port = etPort!=null&&!etPort.getText().toString().trim().isEmpty()?etPort.getText().toString().trim():"51820";
                    st.customServer = new CustomServer(nm, host, port, proto[0]);
                }
                prefs.edit().putString("custom_server", st.customServer.serialize()).apply();
                refreshCustomServerUI(); dialog.dismiss();
                toast("✅ Сервер сохранён: "+st.customServer.name);
            });
            dialog.show();
        } catch (Exception e) { toast("Ошибка диалога: "+e.getMessage()); }
    }

    private void refreshCustomServerUI() {
        if (!isAdded()) return;
        if (st.customServer!=null) {
            if (customServerCard!=null) customServerCard.setVisibility(View.VISIBLE);
            if (customServerEmpty!=null) customServerEmpty.setVisibility(View.GONE);
            if (tvCustomName!=null) tvCustomName.setText(st.customServer.name);
            if (tvCustomHost!=null) tvCustomHost.setText(st.customServer.getDisplayHost());
            if (tvCustomProto!=null) tvCustomProto.setText(st.customServer.getProtoDisplay());
        } else {
            if (customServerCard!=null) customServerCard.setVisibility(View.GONE);
            if (customServerEmpty!=null) customServerEmpty.setVisibility(View.VISIBLE);
        }
    }

    private void selectCustomServer() {
        if (st.customServer==null) return;
        st.selectedServerId = -2; updateSelectedCard();
        toast("🔧 Выбран: "+st.customServer.name);
    }

    private void deleteCustomServer() {
        st.customServer=null; if(st.selectedServerId==-2)st.selectedServerId=-1;
        prefs.edit().remove("custom_server").apply();
        refreshCustomServerUI(); updateSelectedCard(); toast("🗑 Сервер удалён");
    }

    private void updateSelectedCard() {
        if (!isAdded()) return;
        if (st.isCustomSelected()&&st.customServer!=null) {
            if(tvSelFlag!=null)tvSelFlag.setText("🔧");
            if(tvSelLabel!=null)tvSelLabel.setText("🔧 МОЙ СЕРВЕР");
            if(tvSelName!=null)tvSelName.setText(st.customServer.name);
            if(tvSelSub!=null)tvSelSub.setText(st.customServer.getDisplayHost());
            if(tvSelPing!=null)tvSelPing.setText("— ms");
        } else {
            Server srv=st.getSelectedServer();
            if(srv!=null) {
                if(tvSelFlag!=null)tvSelFlag.setText(srv.flag);
                if(tvSelLabel!=null)tvSelLabel.setText("📍 ВЫБРАН");
                if(tvSelName!=null)tvSelName.setText(srv.name+", "+srv.city);
                if(tvSelSub!=null)tvSelSub.setText(srv.proto);
                if(tvSelPing!=null)tvSelPing.setText(srv.ping+" ms");
            } else {
                if(tvSelFlag!=null)tvSelFlag.setText("⚡");
                if(tvSelLabel!=null)tvSelLabel.setText("⚡ SMART SELECT");
                if(tvSelName!=null)tvSelName.setText("Лучший сервер");
                if(tvSelSub!=null)tvSelSub.setText("Авто · WireGuard");
                if(tvSelPing!=null)tvSelPing.setText("12 ms");
            }
        }
    }

    private void toast(String msg) { if(getActivity() instanceof MainActivity) ((MainActivity)getActivity()).showToast(msg); }

    @Override public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacksAndMessages(null);
        executor.shutdown();
    }
}
