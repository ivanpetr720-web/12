package com.pulsevpn.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeFragment extends Fragment {

    private TextView tvStatus, tvTimer, tvDl, tvUl, tvIp, tvIpLocation, tvIpFlag;
    private TextView btnConnect, tvSelFlag, tvSelName, tvSelSub, tvSelPing, tvSelLabel;
    private TextView btnAddServer, btnUseCustom, btnDeleteCustom;
    private TextView tvCustomName, tvCustomHost, tvCustomProto;
    private TextView btnWg, btnOvpn, btnAutoProto, btnPremiumBadge;
    private LinearLayout statsRow, customServerCard, customServerEmpty;
    private View ring1, ring2;

    private Handler handler = new Handler(Looper.getMainLooper());
    private Runnable timerRunnable, speedRunnable, pulseRunnable;
    private AppState st;
    private ExecutorService executor = Executors.newSingleThreadExecutor();
    private Random rnd = new Random();
    private SharedPreferences prefs;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inf.inflate(R.layout.fragment_home, container, false);
        st = AppState.get();
        prefs = requireContext().getSharedPreferences("pulsevpn", Context.MODE_PRIVATE);

        // Load saved custom server
        String saved = prefs.getString("custom_server", null);
        if (saved != null) st.customServer = CustomServer.deserialize(saved);

        bindViews(v);
        setupListeners();
        refreshCustomServerUI();
        updateSelectedCard();

        if (!st.ipLoaded) fetchRealIp();
        else updateIpDisplay(false);

        updateUI();
        if (st.connected) { startTimer(); startSpeedSim(); startPulse(); }

        return v;
    }

    private void bindViews(View v) {
        tvStatus       = v.findViewById(R.id.tv_status);
        tvTimer        = v.findViewById(R.id.tv_timer);
        tvDl           = v.findViewById(R.id.tv_dl);
        tvUl           = v.findViewById(R.id.tv_ul);
        tvIp           = v.findViewById(R.id.tv_ip);
        tvIpLocation   = v.findViewById(R.id.tv_ip_location);
        tvIpFlag       = v.findViewById(R.id.tv_ip_flag);
        statsRow       = v.findViewById(R.id.stats_row);
        btnConnect     = v.findViewById(R.id.btn_connect);
        ring1          = v.findViewById(R.id.ring1);
        ring2          = v.findViewById(R.id.ring2);
        btnWg          = v.findViewById(R.id.btn_wg);
        btnOvpn        = v.findViewById(R.id.btn_ovpn);
        btnAutoProto   = v.findViewById(R.id.btn_auto_proto);
        tvSelFlag      = v.findViewById(R.id.tv_sel_flag);
        tvSelLabel     = v.findViewById(R.id.tv_sel_label);
        tvSelName      = v.findViewById(R.id.tv_sel_name);
        tvSelSub       = v.findViewById(R.id.tv_sel_sub);
        tvSelPing      = v.findViewById(R.id.tv_sel_ping);
        btnAddServer   = v.findViewById(R.id.btn_add_server);
        customServerCard  = v.findViewById(R.id.custom_server_card);
        customServerEmpty = v.findViewById(R.id.custom_server_empty);
        tvCustomName   = v.findViewById(R.id.tv_custom_name);
        tvCustomHost   = v.findViewById(R.id.tv_custom_host);
        tvCustomProto  = v.findViewById(R.id.tv_custom_proto);
        btnUseCustom   = v.findViewById(R.id.btn_use_custom);
        btnDeleteCustom= v.findViewById(R.id.btn_delete_custom);
        btnPremiumBadge= v.findViewById(R.id.btn_premium_badge);
    }

    private void setupListeners() {
        btnConnect.setOnClickListener(v -> onConnectClick());
        btnWg.setOnClickListener(v -> setProtocol("wireguard"));
        btnOvpn.setOnClickListener(v -> setProtocol("openvpn"));
        btnAutoProto.setOnClickListener(v -> setProtocol("auto"));
        btnAddServer.setOnClickListener(v -> showAddServerDialog());
        btnUseCustom.setOnClickListener(v -> selectCustomServer());
        btnDeleteCustom.setOnClickListener(v -> deleteCustomServer());
        btnPremiumBadge.setOnClickListener(v -> MainActivity.get(this).openPaywall());
    }

    // ===== CUSTOM SERVER =====
    private void showAddServerDialog() {
        View dv = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_server, null);
        EditText etName  = dv.findViewById(R.id.et_name);
        EditText etHost  = dv.findViewById(R.id.et_host);
        EditText etPort  = dv.findViewById(R.id.et_port);
        TextView protoWg   = dv.findViewById(R.id.proto_wg);
        TextView protoOvpn = dv.findViewById(R.id.proto_ovpn);
        TextView btnSave   = dv.findViewById(R.id.btn_save);
        TextView btnCancel = dv.findViewById(R.id.btn_cancel);
        TextView btnQr     = dv.findViewById(R.id.btn_qr_scan);

        final String[] selectedProto = {"wireguard"};

        protoWg.setOnClickListener(v -> {
            selectedProto[0] = "wireguard";
            protoWg.setBackgroundResource(R.drawable.btn_proto_active);
            protoWg.setTextColor(Color.parseColor("#000000"));
            protoOvpn.setBackgroundResource(R.drawable.btn_proto_inactive);
            protoOvpn.setTextColor(Color.parseColor("#8CA8A0"));
        });
        protoOvpn.setOnClickListener(v -> {
            selectedProto[0] = "openvpn";
            protoOvpn.setBackgroundResource(R.drawable.btn_proto_active);
            protoOvpn.setTextColor(Color.parseColor("#000000"));
            protoWg.setBackgroundResource(R.drawable.btn_proto_inactive);
            protoWg.setTextColor(Color.parseColor("#8CA8A0"));
        });

        // Pre-fill if editing
        if (st.customServer != null) {
            etName.setText(st.customServer.name);
            etHost.setText(st.customServer.host);
            etPort.setText(st.customServer.port);
            selectedProto[0] = st.customServer.proto;
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
            .setView(dv).create();
        if (dialog.getWindow() != null)
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        btnQr.setOnClickListener(v -> {
            dialog.dismiss();
            MainActivity.get(this).showToast("📷 QR-сканер: вставь конфиг WireGuard и он заполнится автоматически!");
            // In real app: launch QR scanner intent
        });

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String host = etHost.getText().toString().trim();
            String port = etPort.getText().toString().trim();
            if (host.isEmpty()) {
                MainActivity.get(this).showToast("⚠️ Введи хост или IP");
                return;
            }
            if (name.isEmpty()) name = host;
            if (port.isEmpty()) port = selectedProto[0].equals("wireguard") ? "51820" : "1194";

            st.customServer = new CustomServer(name, host, port, selectedProto[0]);
            prefs.edit().putString("custom_server", st.customServer.serialize()).apply();
            refreshCustomServerUI();
            dialog.dismiss();
            MainActivity.get(this).showToast("✅ Сервер сохранён: " + name);
        });

        dialog.show();
    }

    private void refreshCustomServerUI() {
        if (st.customServer != null) {
            customServerCard.setVisibility(View.VISIBLE);
            customServerEmpty.setVisibility(View.GONE);
            tvCustomName.setText(st.customServer.name);
            tvCustomHost.setText(st.customServer.getDisplayHost());
            tvCustomProto.setText(st.customServer.getProtoDisplay());
        } else {
            customServerCard.setVisibility(View.GONE);
            customServerEmpty.setVisibility(View.VISIBLE);
        }
        if (st.isPremium && btnPremiumBadge != null)
            btnPremiumBadge.setVisibility(View.VISIBLE);
    }

    private void selectCustomServer() {
        if (st.customServer == null) return;
        st.selectedServerId = -2;
        updateSelectedCard();
        MainActivity.get(this).showToast("🔧 Выбран: " + st.customServer.name);
        if (st.connected) { doDisconnect(); handler.postDelayed(this::doConnect, 400); }
    }

    private void deleteCustomServer() {
        st.customServer = null;
        if (st.selectedServerId == -2) st.selectedServerId = -1;
        prefs.edit().remove("custom_server").apply();
        refreshCustomServerUI();
        updateSelectedCard();
        MainActivity.get(this).showToast("🗑 Сервер удалён");
    }

    private void updateSelectedCard() {
        if (!isAdded()) return;
        if (st.isCustomSelected() && st.customServer != null) {
            tvSelFlag.setText("🔧");
            tvSelLabel.setText("🔧 МОЙ СЕРВЕР");
            tvSelName.setText(st.customServer.name);
            tvSelSub.setText(st.customServer.getDisplayHost() + " · " + st.customServer.getProtoDisplay());
            tvSelPing.setText("— ms");
        } else {
            Server srv = st.getSelectedServer();
            if (srv != null) {
                tvSelFlag.setText(srv.flag);
                tvSelLabel.setText("📍 ВЫБРАН");
                tvSelName.setText(srv.name + ", " + srv.city);
                tvSelSub.setText(srv.proto);
                tvSelPing.setText(srv.ping + " ms");
            } else {
                tvSelFlag.setText("⚡");
                tvSelLabel.setText("⚡ SMART SELECT");
                tvSelName.setText("Лучший сервер");
                tvSelSub.setText("Авто · WireGuard");
                tvSelPing.setText("12 ms");
            }
        }
    }

    // ===== CONNECT =====
    private void onConnectClick() {
        if (st.connecting) return;
        if (st.connected) doDisconnect();
        else doConnect();
    }

    private void doConnect() {
        st.connecting = true;
        updateUI();
        handler.postDelayed(() -> {
            if (!isAdded()) return;
            st.connecting = false;
            st.connected = true;
            updateUI();
            startTimer(); startSpeedSim(); startPulse();
            String name;
            if (st.isCustomSelected()) name = "🔧 " + st.customServer.name;
            else { Server s = st.getSelectedServer(); name = s != null ? s.flag+" "+s.name : "⚡ Smart"; }
            MainActivity.get(this).showToast("✅ Подключён — " + name);
            updateIpDisplay(true);
        }, 2200);
    }

    private void doDisconnect() {
        st.connected = false; st.connecting = false; st.timerSec = 0;
        stopAll(); updateUI(); updateIpDisplay(false);
        MainActivity.get(this).showToast("🔌 Отключён");
    }

    // ===== UI =====
    private void updateUI() {
        if (!isAdded()) return;
        int green  = Color.parseColor("#00FF88");
        int yellow = Color.parseColor("#FFCC00");
        int dim    = Color.parseColor("#8CA8A0");

        if (st.connected) {
            tvStatus.setText("● ПОДКЛЮЧЁН"); tvStatus.setTextColor(green);
            btnConnect.setText("⏻\nОТКЛЮЧИТЬ"); btnConnect.setTextColor(green);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_connected);
            statsRow.setVisibility(View.VISIBLE);
            tvTimer.setVisibility(View.VISIBLE);
        } else if (st.connecting) {
            tvStatus.setText("● ПОДКЛЮЧЕНИЕ…"); tvStatus.setTextColor(yellow);
            btnConnect.setText("⏻\n…"); btnConnect.setTextColor(yellow);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_normal);
            statsRow.setVisibility(View.GONE); tvTimer.setVisibility(View.GONE);
            AlphaAnimation a = new AlphaAnimation(0.3f, 1f);
            a.setDuration(600); a.setRepeatMode(Animation.REVERSE); a.setRepeatCount(Animation.INFINITE);
            btnConnect.startAnimation(a);
        } else {
            tvStatus.setText("● НЕ ПОДКЛЮЧЁН"); tvStatus.setTextColor(dim);
            btnConnect.setText("⏻\nCONNECT"); btnConnect.setTextColor(dim);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_normal);
            btnConnect.clearAnimation();
            statsRow.setVisibility(View.GONE); tvTimer.setVisibility(View.GONE);
        }
    }

    // ===== TIMER =====
    private void startTimer() {
        timerRunnable = new Runnable() { public void run() {
            if (!isAdded() || !st.connected) return;
            st.timerSec++;
            tvTimer.setText(String.format(Locale.US, "%02d:%02d:%02d",
                st.timerSec/3600, (st.timerSec%3600)/60, st.timerSec%60));
            handler.postDelayed(this, 1000);
        }};
        handler.post(timerRunnable);
    }

    // ===== SPEED =====
    private void startSpeedSim() {
        speedRunnable = new Runnable() { public void run() {
            if (!isAdded() || !st.connected) return;
            tvDl.setText(String.format(Locale.US, "%.1f MB/s", 2 + rnd.nextDouble()*8));
            tvUl.setText(String.format(Locale.US, "%.1f MB/s", 0.5 + rnd.nextDouble()*3));
            handler.postDelayed(this, 1000);
        }};
        handler.post(speedRunnable);
    }

    // ===== PULSE =====
    private void startPulse() {
        pulseRunnable = new Runnable() { boolean s=true; public void run() {
            if (!isAdded() || !st.connected) return;
            ring1.animate().alpha(s?0.4f:0.1f).setDuration(800).start();
            ring2.animate().alpha(s?0.25f:0.08f).setDuration(1000).start();
            s=!s; handler.postDelayed(this, 900);
        }};
        handler.post(pulseRunnable);
    }

    private void stopAll() {
        btnConnect.clearAnimation();
        if (timerRunnable != null) handler.removeCallbacks(timerRunnable);
        if (speedRunnable != null) handler.removeCallbacks(speedRunnable);
        if (pulseRunnable != null) handler.removeCallbacks(pulseRunnable);
        if (isAdded()) { tvTimer.setText(""); ring1.setAlpha(0.15f); ring2.setAlpha(0.2f); }
    }

    // ===== PROTOCOL =====
    private void setProtocol(String p) {
        st.protocol = p;
        int black = Color.parseColor("#000000");
        int dim   = Color.parseColor("#8CA8A0");
        btnWg.setBackgroundResource(p.equals("wireguard") ? R.drawable.btn_proto_active : R.drawable.btn_proto_inactive);
        btnWg.setTextColor(p.equals("wireguard") ? black : dim);
        btnOvpn.setBackgroundResource(p.equals("openvpn") ? R.drawable.btn_proto_active : R.drawable.btn_proto_inactive);
        btnOvpn.setTextColor(p.equals("openvpn") ? black : dim);
        btnAutoProto.setBackgroundResource(p.equals("auto") ? R.drawable.btn_proto_active : R.drawable.btn_proto_inactive);
        btnAutoProto.setTextColor(p.equals("auto") ? black : dim);
        String n = p.equals("wireguard")?"WireGuard":p.equals("openvpn")?"OpenVPN":"Auto";
        MainActivity.get(this).showToast("⚡ Протокол: " + n);
    }

    // ===== REAL IP =====
    private void fetchRealIp() {
        tvIp.setText("Определяется…"); tvIpLocation.setText("Загрузка…"); tvIpFlag.setText("🌐");
        executor.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL("https://ipapi.co/json/").openConnection();
                c.setConnectTimeout(5000); c.setReadTimeout(5000);
                c.setRequestProperty("User-Agent","PulseVPN/2.0");
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line); br.close();
                JSONObject j = new JSONObject(sb.toString());
                st.realIp = j.optString("ip","");
                st.realCountry = j.optString("country_name","") + ", " + j.optString("city","");
                st.realFlag = countryToFlag(j.optString("country_code","").toUpperCase());
                st.ipLoaded = true;
                handler.post(() -> { if (isAdded()) updateIpDisplay(st.connected); });
            } catch (Exception e) {
                handler.post(() -> { if (!isAdded()) return;
                    tvIp.setText("Нет подключения"); tvIpLocation.setText("—"); tvIpFlag.setText("❌"); });
            }
        });
    }

    private void updateIpDisplay(boolean vpn) {
        if (!isAdded()) return;
        if (vpn) {
            String host = st.isCustomSelected() ? st.customServer.host :
                (st.getSelectedServer() != null ? st.getSelectedServer().city + " VPN" : "VPN");
            tvIp.setText("10." + rnd.nextInt(255) + "." + rnd.nextInt(255) + "." + rnd.nextInt(255));
            tvIpLocation.setText("📍 " + host);
            tvIpFlag.setText(st.isCustomSelected() ? "🔧" :
                (st.getSelectedServer() != null ? st.getSelectedServer().flag : "⚡"));
        } else {
            if (st.ipLoaded && !st.realIp.isEmpty()) {
                tvIp.setText(st.realIp);
                tvIpLocation.setText("📍 " + st.realCountry);
                tvIpFlag.setText(st.realFlag);
            } else fetchRealIp();
        }
    }

    private String countryToFlag(String cc) {
        if (cc.length() != 2) return "🌐";
        return new String(Character.toChars(cc.charAt(0)-'A'+0x1F1E6)) +
               new String(Character.toChars(cc.charAt(1)-'A'+0x1F1E6));
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        handler.removeCallbacksAndMessages(null);
        executor.shutdown();
    }
}
