package com.pulsevpn.app;

public class CustomServer {
    public String name;
    public String host;
    public String port;
    public String proto; // "wireguard" or "openvpn"

    public CustomServer(String name, String host, String port, String proto) {
        this.name = name;
        this.host = host;
        this.port = port;
        this.proto = proto;
    }

    public String getDisplayHost() {
        return host + ":" + port;
    }

    public String getProtoDisplay() {
        return proto.equals("wireguard") ? "WireGuard" : "OpenVPN";
    }

    // Save/load from SharedPreferences as simple string
    public String serialize() {
        return name + "|" + host + "|" + port + "|" + proto;
    }

    public static CustomServer deserialize(String s) {
        if (s == null || s.isEmpty()) return null;
        String[] p = s.split("\\|");
        if (p.length < 4) return null;
        return new CustomServer(p[0], p[1], p[2], p[3]);
    }
}
