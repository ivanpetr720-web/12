# UI_REFACTOR_PLAN.md — PulseVPN V6 Premium Minimalism
> Статус: ОЖИДАЕТ УТВЕРЖДЕНИЯ  
> Этап 0 / Дизайн-аудит

---

## ЧАСТЬ 1 — ДУБЛИКАТЫ К УДАЛЕНИЮ

### Файлы-дубликаты (обнаружены):

| Файл | Дублирует | Действие |
|------|-----------|----------|
| `drawable/selected_card_bg.xml` | `drawable/card_selected.xml` | **УДАЛИТЬ** `selected_card_bg.xml`. Оставить `card_selected.xml` (1.5dp stroke — более чёткий). Обновить все ссылки. |
| `layout/dialog_add_subscription.xml` | URL-панель внутри `dialog_add_server.xml` | **УДАЛИТЬ** `dialog_add_subscription.xml` — в коде не используется, весь функционал уже есть в `dialog_add_server.xml`. |
| `values/colors_switch.xml` | `values/colors.xml` | **СЛИТЬ** switch-цвета в `colors.xml`, удалить `colors_switch.xml`. |
| `drawable/smart_card_bg.xml` | `drawable/card_bg.xml` + stroke | **УДАЛИТЬ** `smart_card_bg.xml`. Заменить на `card_selected` (прозрачный вариант) или новый `card_accent_bg`. |
| `drawable/custom_card_bg.xml` | `drawable/card_bg.xml` (идентичен) | **УДАЛИТЬ** `custom_card_bg.xml`. Заменить на `card_bg`. |
| `drawable/ring_glow_outer.xml` | `drawable/ring_glow.xml` (один и тот же эффект) | **ОСТАВИТЬ один** `ring_glow.xml`, удалить `ring_glow_outer.xml`. |
| `drawable/section_header_bg.xml` | Не используется нигде в layout | **УДАЛИТЬ** |
| `drawable/paywall_feature_bg.xml` | `drawable/card_bg.xml` | **УДАЛИТЬ**, использовать `card_bg`. |

**Итого: 7 файлов к удалению → проект станет чище и легче.**

---

## ЧАСТЬ 2 — V6 ДИЗАЙН-СИСТЕМА

### 2A. Цветовые токены (9 токенов вместо 30+ hardcoded hex)

```
bg              = #03090C   Самый тёмный фон (почти чёрный с тёплым сине-зелёным)
surface         = #0A1720   Карточки, нижняя навигация, input-поля
surface_raised  = #0F1F2A   Диалоги, вторичные карточки, выделенные планы
accent          = #00E07A   Основной акцент: кнопки, активные состояния
accent_bright   = #00FF88   ТОЛЬКО: хороший пинг, индикатор подключён, маленькие метки
accent_dim      = #0D2A1E   Фон selected-карточек, фон кнопки Ping Good
text_primary    = #DCE8E2   Основной текст (заголовки, контент)
text_secondary  = #4A6870   Описания, подписи, неактивные элементы
text_dim        = #1E3A30   Метки секций (UPPERCASE капшены)
danger          = #FF3358   Ошибки, утечки DNS
warning         = #FFBA00   Предупреждения, пинг средний
```

**Принцип: больше никаких `#FFD700`, `#FFCC00`, `#4A6A64`, `#2A5A44`, `#8CA8A0` в XML напрямую — только через color-ресурсы.**

### 2B. Сетка отступов (базовая единица = 4dp)

```
4dp  — micro: зазор между иконкой и текстом
8dp  — small: между элементами внутри карточки
12dp — card-internal: внутренний padding карточки (vertical), gap между строками в настройках
16dp — base: горизонтальный margin экрана, padding карточки (horizontal)
24dp — section: между секциями на экране
32dp — header: padding-top у заголовков экранов
```

**Нарушения сетки сейчас:** 6dp padding в nav items, 10dp gap вместо 8dp, 14dp padding карточек вместо 12dp или 16dp, 20dp padding в profile/paywall вместо 16dp, секции разделены то 8dp, то 12dp, то 16dp, то 20dp.

### 2C. Типографическая шкала (6 размеров вместо 14+)

| Роль | Размер | Жирность | Tracking |
|------|--------|----------|----------|
| Screen Title | 20sp | Bold | 0 |
| Item Title | 14sp | Bold | 0 |
| Body | 13sp | Regular | 0 |
| Caption (секции) | 10sp | Bold | 0.10 |
| Mono (IP, пинг) | 13sp | Bold | 0 (monospace) |
| Nav Label | 10sp | Bold | 0.05 |

**Убрать:** 9sp, 11sp, 12sp, 15sp, 16sp, 18sp, 22sp, 24sp, 26sp, 28sp, 32sp, 44sp.

### 2D. Иконки — замена ВСЕХ emoji

Emoji создают визуальный хаос и не масштабируются. Заменяем на:

**Нижняя навигация:**
| Вкладка | Было | Станет |
|---------|------|--------|
| Защита | 🛡️ 20sp | Текст `VPN` + индикатор, без иконки |
| Серверы | 🌍 20sp | Текст `Серверы` + индикатор |
| Настройки | ⚙️ 20sp | Текст `Настройки` + индикатор |
| Профиль | 👤 20sp | Текст `Профиль` + индикатор |

→ Nav превращается в **текстовый таб-бар** с 2dp active-линией сверху (минимализм). Высота навигации: `60dp` (было `64dp`).

**Иконки в строках настроек** (заменить emoji → Unicode geometric без вариации `️`):
| Было | Станет |
|------|--------|
| 🔀 Протокол | `⇄` |
| 🌐 DNS | `◎` |
| 📦 MTU | `▦` |
| 🔒 Kill Switch | `⊘` |
| 🛡️ DNS Leak | `◈` |
| 🕵️ Stealth | `◉` |
| 6️⃣ IPv6 | `⑥` |
| 🔄 Авто-переподключение | `↻` |
| 🚫 Блок рекламы | `⊗` |
| 📤 Экспорт | `↑` |
| 📋 Лог | `≡` |
| 🧪 Диагностика | `◎` |
| 🌐 в диагностике | `◍` |
| 🔒 VPN статус | `⊙` |
| 🧪 DNS | `≋` |
| 📡 Пинг | `≈` |

**Диагностика:** иконки-эмодзи 26sp → Unicode символы 18sp `text_secondary`.

**Подписки:** `📡` 16sp → двухбуквенный тег вида `SS` / `VL` / `WG` в colored box.

**Splash лого:** `⚡` 44sp emoji → **монограмма «P»** — окружность со stroke 2dp accent, внутри буква `P` 24sp Bold #accent. Это уникальный айдентити, а не emoji.

---

## ЧАСТЬ 3 — ЭКРАНЫ: КОНКРЕТНЫЕ ИЗМЕНЕНИЯ

### Экран 1: Сплэш (`activity_splash.xml`)

**Текущее состояние:**
- ⚡ emoji 44sp — дешёво
- "PulseVPN" 28sp bold — ОК
- "SECURE · PRIVATE · FAST" — ОК, но цвет #2A4A40 почти невидим
- ProgressBar внизу — скучно

**Изменения:**
1. **Логотип:** Убрать FrameLayout с ⚡. Заменить на:
   - `View` 80×80dp, background = новый `drawable/logo_mark.xml` — окружность, stroke 2dp `@color/accent`, fill `@color/surface` → центр пустой
   - Поверх `TextView` 80×80dp, text=`"P"`, 28sp, Bold, color=`@color/accent`, gravity=center
2. **"PulseVPN"**: размер → 20sp (было 28sp), цвет → `@color/text_primary`
3. **"SECURE · PRIVATE · FAST"**: цвет → `@color/text_secondary` (было почти невидимый #2A4A40)
4. **ProgressBar:** убрать. Заменить на: `View` 48dp×2dp с цветом `@color/accent`, анимация `anim_progress_bar` — ширина пульсирует от 0 до 48dp за 1.4с
5. **Отступы:** marginTop от лого до text → 24dp (было 20dp), между subtitle и loader → 32dp (было 48dp)
6. **Фон:** `@color/bg` (через ресурс, не hardcoded)

### Экран 2: Главная / Home (`fragment_home.xml`)

**Текущее состояние:**
- Хэдер: зелёный кружок "P" + "PulseVPN" + кнопка "+" — разнородно
- Кнопка CONNECT: 180×180dp кнопка + 3 кольца 0.05/0.08/0.12 alpha → почти невидимые кольца, нет анимации в XML
- Status text сверху над кнопкой — занимает место
- Stats row: 2 карточки inline — хорошо
- IP card: 14dp padding — нарушает сетку
- Selected server card: отдельный drawable → убрать

**Изменения:**
1. **Хэдер:**
   - Убрать кружок "P" слева (это не логотип, это шум)
   - "PulseVPN": 20sp bold, `@color/text_primary` → как wordmark, paddingTop=32dp
   - Кнопка "+": размер 36×36dp, background `@drawable/btn_icon` (скруглённый квадрат surface_raised), text "+", 20sp, accent, gravity=center
   - Высота хэдера: 56dp
2. **Status label:** Убрать отдельный `tv_status` между хэдером и кнопкой. Вместо него — статус **внутри кнопки** как вторая строка (две строки текста: большая "CONNECT" / маленькая "НЕ ЗАЩИЩЁН")
3. **Кнопка CONNECT (переработка):**
   - Убрать 3-слойную систему колец (ring1, ring2, ring_outer) → ОДИН внешний ring
   - Кнопка: 112×112dp (было 120dp) — компактнее
   - FrameLayout контейнер: 160×160dp (было 180dp)
   - `ring_glow.xml` (1 штука): 152×152dp, stroke 1dp accent с alpha 0.15, gravity=center
   - Нет alpha=0.05 на ring_outer — просто удалить
   - Состояние NORMAL: oval fill=surface, stroke 1.5dp=text_dim
   - Состояние CONNECTED: oval fill=accent, stroke 0dp → текст тёмный
   - Состояние CONNECTING: oval fill=surface, stroke 1.5dp=accent (мигает через anim)
   - **Анимация подключения:** ScaleAnimation (0.97→1.0→0.97, 2000ms infinite, RESTART) вместо alpha-blink
4. **Timer TV:** paddingTop=8dp (было auto от layout margin)
5. **Stats row:** marginTop=8dp, padding карточки 12dp (было нет внешнего кол-ва)
6. **IP card:** padding=16dp (было 14dp), marginTop=12dp
7. **Selected server card:** убрать отдельный drawable `smart_card_bg` → использовать `@drawable/card_bg` + у него слева полоска 3dp accent через `layer-list`
8. **Секция "МОИ СЕРВЕРЫ":** marginTop=24dp (было 20dp), метка 10sp bold `@color/text_dim`
9. **Custom server empty state:** высота 56dp (было 64dp), убрать `card_dashed_bg` → просто `@color/text_dim` border dashed

### Экран 3: Серверы (`fragment_servers.xml`)

**Текущее состояние:**
- Header "Серверы" — ОК
- Search bar — ОК, но hint "🔍 Поиск..." — emoji в hint
- Info text "Серверы из ваших подписок" — лишнее
- Нет кнопки "Обновить пинг" (Фишка #3)

**Изменения:**
1. **Search bar:** убрать emoji "🔍" из hint → "Поиск серверов..."
2. **Info text** ("Серверы из ваших подписок"): удалить — лишний шум
3. **Добавить кнопку "Обновить пинг":** row между search и списком: 
   - `LinearLayout` horizontal, gravity=end, padding=0×4dp
   - `TextView` id=`btn_ping_refresh` → background=transparent, text="Обновить пинг", textSize=12sp, textColor=accent, paddingEnd=4dp
4. **item_server.xml:**
   - Флаг emoji 🌐 28sp → убрать emoji. Вместо него: `TextView` 36×36dp, background=`@drawable/flag_badge_bg` (oval surface_raised), text=first 2 letters of country code (определяется в SubServer.getCountryCode()), textSize=11sp, bold, color=text_secondary
   - Padding: 16dp (было 14dp)
   - marginBottom: 6dp (было 8dp)
   - Ping text: 12sp mono bold (было 13sp)
   - Bars (▮▮▮▮): убрать — дублируют цвет пинга, шум
5. **item_server_compact.xml:**
   - Флаг emoji 🌐 22sp → аналогичный badge 28×28dp, 10sp
   - padding: 12dp×10dp (без изменений)
   - Убрать tv_bars если есть
6. **item_sub_header.xml:**
   - paddingTop: 16dp (было 14dp), paddingBottom: 8dp
   - Имя подписки: text_secondary (было #2A5A44)
   - Счётчик: text_dim, 10sp
7. **item_subscription.xml:**
   - Иконка 📡 → `TextView` "SUB" 10sp bold accent, background oval accent_dim, 28×28dp
   - Убрать `section_header_bg` drawable (дубликат)
   - btn_sub_refresh ↻: padding=8dp (было 6dp)

### Экран 4: Настройки (`fragment_settings.xml`)

**ГЛАВНОЕ:** Настройки из Happ скопированы как стандартный Android-паттерн. Нужно их ПЕРЕРАБОТАТЬ под уникальный стиль PulseVPN.

**Уникальный подход для PulseVPN Settings:**

Вместо стандартных карточек с переключателями — **секции с разделителями**. Карточки остаются, но:
- Иконки становятся 24×24dp плашками (surface_raised background, oval) с Unicode-символом
- Строка настройки: высота 60dp (было 56dp) → больше воздуха
- Каждая секция имеет **header с accent-линией** слева (3dp×16dp, расположена за текстом)
- Разделители между строками: 1dp, но отступ слева = 52dp (иконка 24 + margin 12 + padding 16)
- Переключатели: кастомный стиль — track 36dp wide, thumb circle accent

**Уникальные элементы, которых нет в стандартном Android:**
1. Строки протокола/DNS — при тапе открывают **bottom-sheet** вместо AlertDialog (планируем — отмечаем в плане)
2. Секция "УМНЫЕ ФУНКЦИИ" — имеет **специальный badge "NEW"** у заголовка секции (accent pill 6sp bold)
3. В Battery Optimizer строке — **live preview**: текст меняется на "MTU: 1280 · Интервал: 25мс" при включении
4. Версия в футере: 11sp, center, text_dim — убрать жирность

**Изменения по секциям:**
1. **Header экрана**: "Настройки" → 20sp bold, paddingTop=32dp, paddingBottom=20dp
2. **Метки секций** (VPN, БЕЗОПАСНОСТЬ, и т.д.): цвет text_dim (очень тёмный — читаемый, но не акцентный), + добавить 3dp×12dp accent-линию ПЕРЕД текстом (через compound drawable или отдельный View)
3. **Иконки:** Все emoji заменить на Unicode-символы (таблица выше). Обернуть в View 28×28dp, background oval surface_raised
4. **Переключатели:** SwitchCompat с кастомным ColorStateList: track `@color/switch_track`, thumb `@color/switch_thumb`
5. **Padding строки настроек:** paddingStart=16dp, paddingEnd=16dp, paddingTop=0, paddingBottom=0 (высота фиксирована 60dp)
6. **Padding иконки:** убрать 30dp width на TextView с эмодзи → View 28×28dp
7. **Версия в footer:** "PulseVPN 6.1" → 10sp, text_dim, gravity=center, marginTop=16dp

### Экран 5: Профиль (`fragment_profile.xml`)

**Текущее состояние:**
- Auth panel: 3 поля + 2 кнопки внутри card_bg (20dp padding) — OK, но emoji 🔑
- User panel: avatar "P" в зелёном кружке — OK
- Stats: числа 24sp — слишком крупно
- Premium block: отдельная карточка с 20dp padding и gradient
- Log: OK структура

**Изменения:**
1. **Auth panel:**
   - `🔑 Войти через Google` → убрать emoji, текст "Войти через Google"
   - Кнопка Google: 44dp → 48dp высота, border 1dp text_dim (было btn_outline)
   - Поля ввода: высота 48dp (без изменений), padding-horizontal 16dp (было 14dp)
   - marginBottom между полями: 8dp (было 10dp) — сетка
2. **User panel:**
   - Avatar: 48×48dp (было 56dp) — компактнее, более премиально
   - Avatar bg: сохранить accent fill, но радиус 50% (oval)
   - marginStart от аватара к тексту: 16dp (без изменений)
3. **Stats card:**
   - Числа 24sp → 20sp bold accent
   - Метки "Подписок", "Серверов": 11sp → 10sp caption
   - Разделитель: 1dp height 32dp
4. **Plan info card:** метки "Тип плана", "Доступных" → 13sp (было 14sp)
5. **Premium block:**
   - Убрать hardcoded gradient — использовать `@drawable/premium_card_bg` (оставить)
   - Убрать "✓ Все 12+ серверов" список → 3 строки в одну: "Все серверы · Приоритет · Настройки"
   - Цена "149 ₽/мес" → 20sp (было 22sp), убрать "от" text перед ней
   - Кнопка "Купить Premium": 48dp высота (без изменений)
6. **Лог:** убрать лишний padding=8dp у wrapper → padding=0 (лог items имеют свой padding)
7. **"Очистить лог"**: фон убрать (`btn_proto_inactive`) → только текст 12sp danger underline-style
8. **tv_version**: "PulseVPN v6.0" → "v6.1", 10sp text_dim

### Экран 6: Paywall (`fragment_paywall.xml`)

**Текущее состояние:**
- ⚡ header с gradient + "PulseVPN Premium"
- Feature rows: 52dp high с emoji иконками
- Plan rows: 68dp high с #FFD700 ценой
- Кнопка "Оплатить" — OK

**Изменения:**
1. **Header:**
   - ⚡ emoji 44sp → монограмма "P" как на сплэше, 64×64dp
   - "PulseVPN Premium" → 20sp (было 22sp)
   - subtitle цвет → text_secondary (было #4A6A64 hardcoded)
   - paddingTop: 32dp (было 36dp), paddingBottom: 24dp (без изменений)
2. **Feature rows:**
   - Высота 48dp (было 52dp)
   - Emoji иконки (🌍, 🕵️, ⚙️) → 32×32dp плашки с Unicode (◎, ◉, ▦), oval surface_raised bg
   - marginBottom: 8dp (без изменений)
3. **Plan rows:**
   - Высота: 72dp (было 68dp) → добавить воздух
   - Цена: убрать `#FFD700` → `@color/text_primary` (белый), жирный 20sp
   - Скидка "-33%" → `@color/accent_bright` 10sp bold (было #00FF88 hardcoded)
   - "Лучшее" badge: bg=accent, radius=4dp, padding=2dp×6dp, 9sp
   - `plan_selected.xml`: stroke 1.5dp accent, fill surface_raised (было #0A1E1A)
   - `plan_normal.xml`: stroke 1dp text_dim, fill surface (было #0D1E24/#1A3530)
4. **Pay button:** "Оплатить" → "Оформить подписку", высота 52dp (без изменений), radius 10dp (было 8dp)
5. **Footer disclaimer**: 10sp, text_dim (было #2A4A40 hardcoded)

### Экран 7: Диагностика (`fragment_diagnostics.xml`)

**Текущее состояние:**
- Back arrow "‹" 32sp green — слишком крупный
- 4 карточки с emoji 26sp иконками (🌐, 🔒, 🧪, 📡)
- Кнопка "▶ Запустить тест" — emoji символ

**Изменения:**
1. **Back arrow**: "‹" → `TextView` ← 18sp text_secondary (без акцента), paddingEnd=12dp
2. **Заголовок**: "Диагностика" 20sp bold
3. **Карточки:** emoji иконки 26sp → Unicode 16sp surface_raised badge 32×32dp
4. **Кнопка запуска:** "▶  Запустить тест" → "Запустить тест" (убрать ▶), радиус 10dp
5. **Секции labels** (РЕАЛЬНЫЙ IP, VPN, DNS-УТЕЧКА, ПИНГ): цвет text_dim с 3dp линией
6. **Overall result card:** padding=16dp (было 20dp)
7. **Отступы:** все marginBottom=16dp → соответствуют 16dp (уже ОК, не трогаем)

### Экран 8: Нижняя навигация (`activity_main.xml`)

**Текущее состояние:**
- Emoji иконки 20sp: 🛡️, 🌍, ⚙️, 👤 — убивают премиальность
- Высота 64dp
- Индикатор 2dp line сверху — OK, но слишком тонко

**Изменения:**
1. **Убрать все emoji иконки** (4 строки с TextView)
2. **Новый layout каждой вкладки:** только `TextView` label + indicator
   ```
   [indicator view 32dp×3dp radius=1.5dp]  ← СВЕРХУ
   [label 10sp bold letter-spacing=0.05]
   ```
3. **Активная метка:** цвет accent (было #00FF88 hardcoded) → `@color/accent`
4. **Неактивная метка:** цвет text_secondary → `@color/text_secondary`
5. **Высота навигации:** 56dp (было 64dp) — компактнее, более iOS-like минимализм
6. **Background:** `@color/surface` (было `@drawable/bottom_nav_bg` с stroke)
   - Заменить `bottom_nav_bg.xml` — добавить stroke только сверху (через layer-list 1dp top divider)
7. **Индикатор:** width=28dp, height=3dp, radius=1.5dp, цвет accent

### Диалог: Добавить сервер (`dialog_add_server.xml`)

**Текущее состояние:**
- Заголовок "Добавить" — OK
- Tabs "Вручную" / "URL подписка" — OK
- Кнопки протокола 32dp — OK

**Изменения:**
1. **Padding:** 24dp (было 20dp) → больше воздуха в диалоге
2. **Заголовок:** 18sp → 17sp (Item Title)
3. **Поля ввода:** высота 48dp (было 44dp) — единый размер
4. **Метка "ПРОТОКОЛ":** добавить 3dp линию слева
5. **Кнопки протокола:** высота 36dp (было 32dp), border-radius 8dp
6. **"СКАНИРОВАТЬ QR-КОД"**: убрать UPPERCASE → "Сканировать QR", 13sp
7. **Кнопки OK/Cancel:** высота 48dp (было 44dp), btn_green radius=10dp (было 8dp)

---

## ЧАСТЬ 4 — ЛОГОТИП И МОНОГРАММА

### Монограмма PulseVPN "P" — единая айдентити

**Идея:** Простой, чистый знак. Буква "P" в окружности. Работает везде — сплэш, лончер, уведомления.

**Реализация (векторная, без внешних ресурсов):**
- Shape: `oval`, 80×80dp
- Fill: `@color/surface_raised`
- Stroke: 2dp, `@color/accent`
- Поверх: TextView "P", 28sp, Bold, `@color/accent`

**Отличие от текущего:** Сейчас ⚡ emoji в произвольном фрейме. Новая монограмма — чёткая геометрия, фирменный цвет, читается на любом фоне.

**Где появляется:**
- `activity_splash.xml` — 80×80dp вместо FrameLayout с ⚡
- `fragment_home.xml` — кнопка "+" в хэдере убирает "P" (там вообще не нужен логотип)
- `fragment_paywall.xml` — 64×64dp вместо ⚡ в header
- Нотификация — ic_launcher (без изменений)

---

## ЧАСТЬ 5 — АНИМАЦИИ

### Анимация 1: Кнопка CONNECT — пульс

**Файл:** `res/anim/pulse_connect.xml`
```xml
ScaleAnimation:
  fromX=0.96, toX=1.0, fromY=0.96, toY=1.0
  duration=1800ms
  repeatCount=INFINITE, repeatMode=REVERSE
  interpolator=accelerateDecelerate
  pivotX=50%, pivotY=50%
```
**Где:** кольцо вокруг кнопки, когда connected. Кнопка сама не масштабируется — только ring.

**Когда подключается:** ring сначала ScaleAnimation 0.0→1.2 за 400ms (появление), потом loop pulse.

### Анимация 2: Кнопка CONNECT — подключение (blink)

**Файл:** `res/anim/btn_connecting.xml`
```xml
AlphaAnimation:
  fromAlpha=0.4, toAlpha=1.0
  duration=550ms
  repeatCount=INFINITE, repeatMode=REVERSE
  interpolator=decelerate
```
**Где:** бордер кнопки (ring) мигает, кнопка остаётся неподвижной.

### Анимация 3: Переходы между экранами

**Текущее:** `android.R.anim.fade_in / fade_out` — базово.

**Улучшение:** Добавить собственные файлы анимаций:
- `res/anim/slide_up_enter.xml` — translateY +30dp→0, alpha 0→1, 220ms
- `res/anim/slide_down_exit.xml` — translateY 0→+30dp, alpha 1→0, 180ms

**Где используется:** переход к DiagnosticsFragment и PaywallFragment (фрагменты второго уровня).

### Анимация 4: Сплэш логотип

**Файл:** `res/anim/splash_logo.xml`
```xml
AnimationSet:
  AlphaAnimation 0→1, 400ms
  ScaleAnimation 0.85→1.0, 500ms
  interpolator=overshoot (tension=1.5)
```
**Текущее:** просто AlphaAnimation на root — слабо.

### Анимация 5: Строки настроек (нажатие)

Через `android:foreground="?selectableItemBackground"` — стандартный ripple, цвет изменить на `@color/accent` 10% opacity. Не нужны отдельные файлы.

### Анимация 6: Ping Refresh кнопка (Фишка #3)

Кнопка "Обновить пинг" при нажатии: RotateAnimation 0→360°, 600ms, на символе ↻.

---

## ЧАСТЬ 6 — DRAWABLES К ИЗМЕНЕНИЮ

| Drawable | Текущее | Изменение |
|----------|---------|-----------|
| `card_bg.xml` | fill=#0D1E24, r=12dp | fill=@color/surface, r=10dp |
| `connect_btn_normal.xml` | oval fill=#0D1E24, stroke 2dp #1A3530 | fill=@color/surface, stroke 1.5dp @color/text_dim |
| `connect_btn_connected.xml` | oval fill=#00FF88 | fill=@color/accent, stroke=0 |
| `btn_green.xml` | fill=#00FF88, r=8dp | fill=@color/accent, r=10dp |
| `ring_glow.xml` | oval stroke 1.5dp #00FF88 | stroke 1dp @color/accent, fill=transparent |
| `bottom_nav_bg.xml` | fill=#0A1218, stroke 1dp | fill=@color/surface, stroke top-only 1dp |
| `plan_selected.xml` | fill=#0A1E1A, stroke #00FF88 | fill=@color/surface_raised, stroke @color/accent |
| `plan_normal.xml` | fill=#0D1E24, stroke #1A3530 | fill=@color/surface, stroke @color/text_dim |
| `premium_card_bg.xml` | gradient #0D2030→#0A1A18 | gradient @color/surface→@color/surface_raised |
| `input_bg.xml` | (не видел) | fill=@color/surface_raised, stroke @color/text_dim 1dp, r=10dp |
| `dialog_bg.xml` | (не видел) | fill=@color/surface_raised, r=16dp |
| `search_bg.xml` | (не видел) | fill=@color/surface, stroke @color/text_dim 1dp, r=8dp |
| `switch_thumb_tint.xml` | thumb on=#00FF88 | thumb on=@color/accent |
| `switch_track_tint.xml` | track on=#20... | track on=@color/accent 30% |

**Новые drawables к созданию:**
- `logo_mark.xml` — oval stroke 2dp accent (монограмма логотип)
- `flag_badge_bg.xml` — oval fill surface_raised (бэйдж флага в списке серверов)
- `nav_tab_bg.xml` — selector для подсветки нажатий в навигации
- `card_accent_left.xml` — layer-list: card_bg + left 3dp accent stroke (для selected server)
- `btn_icon.xml` — rounded rect surface_raised 8dp (для кнопки "+" в хэдере)
- `progress_bar_slim.xml` — shape для аналога ProgressBar на сплэше

---

## ЧАСТЬ 7 — ПЕРЕРАБОТКА НАСТРОЕК (уникальный стиль vs Happ)

### Проблема
Happ-настройки скопированы 1:1: карточка → список строк с emoji → переключатель. Это стандартный Android-паттерн, который у каждого второго VPN-приложения.

### Уникальный паттерн PulseVPN Settings V6

**Концепция: "Command Console"**

Каждая секция настроек — как панель управления. Иконка — не emoji, а строгий геометрический символ в серой плашке. Текущее значение настройки показывается как `badge` справа у строк-кнопок, а не просто серым текстом.

**Уникальные элементы:**

1. **Section header** — не просто "VPN" жирным. А:
   ```
   [3dp×14dp accent линия] [текст "VPN" 10sp bold text_dim]
   ```
   Визуальная якорная точка для каждой секции.

2. **Строки-переключатели** — высота 60dp + иконка в плашке 28×28dp:
   ```
   [28dp icon badge] [12dp gap] [Title 14sp bold] ... [SwitchCompat custom]
   ```
   Переключатель: кастомный ColorStateList (accent track, белый thumb).

3. **Строки-навигационные** (Protocol, DNS, Diagnostics) — справа не просто "›", а:
   ```
   [value badge: "WireGuard" 11sp surface_raised r=4dp] [8dp] [› text_dim 16sp]
   ```
   Текущее значение видно без тапа.

4. **Секция "УМНЫЕ ФУНКЦИИ"** — единственная секция с badge "NEW" рядом с заголовком:
   ```
   [accent линия] [text "УМНЫЕ ФУНКЦИИ"] [8dp] [badge "NEW" 8sp accent fill black r=3dp]
   ```

5. **Battery Optimizer** — при включении в реальном времени обновляется subtitle:
   - Выкл: "Сниж. MTU, реже опрос — экономия ~20%"
   - Вкл: "MTU 1280 · Интервал 25мс — активно"

---

## ЧАСТЬ 8 — ОЧЕРЁДНОСТЬ ВЫПОЛНЕНИЯ

После утверждения этого плана, реализация строго по этапам:

**ЭТАП 0 (этот документ):** Дизайн-план + аудит дубликатов  
**ЭТАП 1:** Удаление дубликатов (7 файлов) + создание color-ресурсов V6  
**ЭТАП 2:** Drawables — исправить все 14 существующих + создать 6 новых  
**ЭТАП 3:** Layouts — 8 экранов + 2 диалога + 5 item-layout  
**ЭТАП 4:** Анимации — 4 anim-файла + применение в коде  
**ЭТАП 5:** Логика — парсеры, фишки, IAP (только после UI готов)  
**ЭТАП 6:** Проверка + Release Notes + ZIP  

---

**Жду утверждения плана перед любым кодингом.**
