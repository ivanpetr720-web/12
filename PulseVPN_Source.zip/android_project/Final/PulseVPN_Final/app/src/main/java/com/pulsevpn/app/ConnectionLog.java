package com.pulsevpn.app;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ConnectionLog {
    public static final int TYPE_CONNECT    = 0;
    public static final int TYPE_DISCONNECT = 1;
    public static final int TYPE_ERROR      = 2;

    private static final List<ConnectionLog> logs = new ArrayList<>();
    private static final int MAX_LOGS = 50;

    public int    type;
    public String message;
    public String host;
    public long   timestamp;

    public ConnectionLog(int type, String message, String host) {
        this.type      = type;
        this.message   = message;
        this.host      = host;
        this.timestamp = System.currentTimeMillis();
    }

    public static void add(int type, String message, String host) {
        synchronized (logs) {
            logs.add(0, new ConnectionLog(type, message, host));
            if (logs.size() > MAX_LOGS) logs.remove(logs.size() - 1);
        }
    }

    public static List<ConnectionLog> getAll() {
        synchronized (logs) { return new ArrayList<>(logs); }
    }

    public static void clear() {
        synchronized (logs) { logs.clear(); }
    }

    public String getIcon() {
        switch (type) {
            case TYPE_CONNECT:    return "●";
            case TYPE_DISCONNECT: return "○";
            case TYPE_ERROR:      return "✕";
            default:              return "·";
        }
    }

    public int getColor() {
        switch (type) {
            case TYPE_CONNECT:    return 0xFF00FF88;
            case TYPE_DISCONNECT: return 0xFF4A6A64;
            case TYPE_ERROR:      return 0xFFFF4466;
            default:              return 0xFF8CA8A0;
        }
    }

    public String getTimeText() {
        return new SimpleDateFormat("HH:mm", Locale.US).format(new Date(timestamp));
    }
}
