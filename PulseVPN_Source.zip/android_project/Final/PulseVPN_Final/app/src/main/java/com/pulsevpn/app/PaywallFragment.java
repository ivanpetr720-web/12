package com.pulsevpn.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

/**
 * PaywallFragment — subscription purchase screen with Google Play Billing.
 *
 * Plans:
 *   1 месяц   = 149  ₽   SKU: pulsevpn_premium_1m
 *   3 месяца  = 299  ₽   SKU: pulsevpn_premium_3m  (-33%)
 *   6 месяцев = 774  ₽   SKU: pulsevpn_premium_6m  (-14%)
 *  12 месяцев = 1357 ₽   SKU: pulsevpn_premium_12m (-24%)
 */
public class PaywallFragment extends Fragment {

    private int selectedPlan = 0;  // 0=1m, 1=3m, 2=6m, 3=12m
    private LinearLayout plan1m, plan3m, plan6m, plan12m;
    private TextView radio1m, radio3m, radio6m, radio12m;

    private BillingManager billingManager;

    // Product IDs — replace with your actual Google Play product IDs
    private static final String[] SKUS = {
        "pulsevpn_premium_1m",
        "pulsevpn_premium_3m",
        "pulsevpn_premium_6m",
        "pulsevpn_premium_12m"
    };

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inflater.inflate(R.layout.fragment_paywall, container, false);

        plan1m  = v.findViewById(R.id.plan_1m);
        plan3m  = v.findViewById(R.id.plan_3m);
        plan6m  = v.findViewById(R.id.plan_6m);
        plan12m = v.findViewById(R.id.plan_12m);
        radio1m  = v.findViewById(R.id.radio_1m);
        radio3m  = v.findViewById(R.id.radio_3m);
        radio6m  = v.findViewById(R.id.radio_6m);
        radio12m = v.findViewById(R.id.radio_12m);

        if (plan1m  != null) plan1m.setOnClickListener(vv  -> selectPlan(0));
        if (plan3m  != null) plan3m.setOnClickListener(vv  -> selectPlan(1));
        if (plan6m  != null) plan6m.setOnClickListener(vv  -> selectPlan(2));
        if (plan12m != null) plan12m.setOnClickListener(vv -> selectPlan(3));

        selectPlan(0);

        // Initialize billing manager
        billingManager = new BillingManager(requireActivity(), new BillingManager.BillingCallback() {
            @Override
            public void onBillingReady() {
                // Billing client connected — load prices for each plan
            }

            @Override
            public void onPurchaseSuccess(String sku) {
                AppState.get().isPremium = true;
                AppState.get().save(requireActivity());
                toast("Подписка активирована!");
                requireActivity().getSupportFragmentManager().popBackStack();
            }

            @Override
            public void onPurchaseFailed(String reason) {
                toast("Ошибка оплаты: " + reason);
            }

            @Override
            public void onAlreadySubscribed() {
                AppState.get().isPremium = true;
                AppState.get().save(requireActivity());
                toast("Подписка уже активна");
                requireActivity().getSupportFragmentManager().popBackStack();
            }
        });

        TextView btnPay = v.findViewById(R.id.btn_pay);
        if (btnPay != null) {
            btnPay.setOnClickListener(vv -> launchPurchase());
        }

        TextView btnRestore = v.findViewById(R.id.btn_restore);
        if (btnRestore != null) {
            btnRestore.setOnClickListener(vv -> billingManager.restorePurchases());
        }

        return v;
    }

    private void launchPurchase() {
        if (billingManager == null) return;
        String sku = SKUS[selectedPlan];
        billingManager.launchPurchaseFlow(requireActivity(), sku);
    }

    private void selectPlan(int plan) {
        selectedPlan = plan;
        LinearLayout[] plans  = {plan1m, plan3m, plan6m, plan12m};
        TextView[]     radios = {radio1m, radio3m, radio6m, radio12m};

        int clrActive   = ContextCompat.getColor(requireContext(), R.color.green);
        int clrInactive = ContextCompat.getColor(requireContext(), R.color.nav_inactive);

        for (int i = 0; i < 4; i++) {
            if (plans[i] != null)
                plans[i].setBackgroundResource(i == plan ? R.drawable.plan_selected : R.drawable.plan_normal);
            if (radios[i] != null) {
                radios[i].setText(i == plan ? "●" : "○");
                radios[i].setTextColor(i == plan ? clrActive : clrInactive);
            }
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (billingManager != null) billingManager.destroy();
    }

    private void toast(String msg) {
        if (isAdded()) ((MainActivity) requireActivity()).showToast(msg);
    }
}
