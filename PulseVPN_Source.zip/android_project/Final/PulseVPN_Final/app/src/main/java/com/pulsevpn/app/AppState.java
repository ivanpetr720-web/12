package com.pulsevpn.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AppState {
    private static AppState instance;

    // Connection state
    public boolean connected  = false;
    public boolean connecting = false;
    public int     timerSec   = 0;
    public String  protocol   = "wireguard";
    public long    bytesDown  = 0;
    public long    bytesUp    = 0;

    // Subscriptions (URL-based)
    public List<Subscription> subscriptions = new ArrayList<>();

    // Custom server (manual entry or single URI)
    public CustomServer customServer;

    // Selection state
    public int    selectedServerId    = -1;   // -1=none, -2=custom, -3=sub, >=0=built-in
    public int    selectedSubServerId = 0;
    public String selectedSubId       = null;

    // Settings — Security
    public boolean autoReconnect  = false;
    public boolean killSwitch     = false;
    public boolean stealthMode    = false;
    public boolean blockAds       = true;
    public boolean blockIpv6      = true;
    public boolean dnsLeakProtect = true;

    // Settings — New features (V6.1)
    /** Фишка #1: Smart Network Reconnect — авто-переподключение при смене Wi-Fi/мобильной сети */
    public boolean smartNetworkReconnect = true;
    /** Фишка #2: Battery Optimizer Mode — снижает потребление батареи в фоне */
    public boolean batteryOptimizer = false;
    /** Фишка #3: Quick Ping Refresh — авто-пинг серверов при открытии списка */
    public boolean quickPingRefresh = true;

    // Live IP info
    public String  realIp      = "";
    public String  realCountry = "";
    public String  realFlag    = "";
    public boolean ipLoaded    = false;

    private AppState() {}

    public static synchronized AppState get() {
        if (instance == null) instance = new AppState();
        return instance;
    }

    // ─── Selection helpers ────────────────────────────────────────────────────

    public boolean isCustomSelected() { return selectedServerId == -2; }

    public boolean isSubSelected() {
        return selectedServerId == -3 && selectedSubId != null;
    }

    public SubServer getSelectedSubServer() {
        if (selectedSubId == null) return null;
        for (Subscription sub : subscriptions) {
            if (sub.id.equals(selectedSubId)) {
                if (selectedSubServerId >= 0 && selectedSubServerId < sub.servers.size())
                    return sub.servers.get(selectedSubServerId);
            }
        }
        return null;
    }

    public Subscription getSelectedSubscription() {
        if (selectedSubId == null) return null;
        for (Subscription sub : subscriptions) {
            if (sub.id.equals(selectedSubId)) return sub;
        }
        return null;
    }

    public List<SubServer> getAllSubscriptionServers() {
        List<SubServer> all = new ArrayList<>();
        for (Subscription sub : subscriptions) all.addAll(sub.servers);
        return all;
    }

    public int getTotalServerCount() {
        int count = 0;
        for (Subscription sub : subscriptions) count += sub.servers.size();
        return count;
    }

    // ─── Persistence ──────────────────────────────────────────────────────────

    public void save(Context ctx) {
        SharedPreferences.Editor ed = prefs(ctx).edit();

        try {
            JSONArray arr = new JSONArray();
            for (Subscription sub : subscriptions) {
                JSONObject o = new JSONObject();
                o.put("id", sub.id);
                o.put("name", sub.name);
                o.put("url", sub.url);
                o.put("lastUpdated", sub.lastUpdated);
                arr.put(o);
            }
            ed.putString("subscriptions", arr.toString());
        } catch (Exception ignored) {}

        try {
            JSONArray arr = new JSONArray();
            for (Subscription sub : subscriptions) {
                JSONArray srvArr = new JSONArray();
                for (SubServer s : sub.servers) {
                    JSONObject o = new JSONObject();
                    o.put("name", s.name);
                    o.put("host", s.host);
                    o.put("port", s.port);
                    o.put("proto", s.proto);
                    o.put("raw", s.rawConfig != null ? s.rawConfig : "");
                    srvArr.put(o);
                }
                JSONObject subObj = new JSONObject();
                subObj.put("id", sub.id);
                subObj.put("servers", srvArr);
                arr.put(subObj);
            }
            ed.putString("subscription_servers", arr.toString());
        } catch (Exception ignored) {}

        if (customServer != null) ed.putString("custom_server", customServer.serialize());
        else ed.remove("custom_server");

        ed.putString("protocol", protocol);
        ed.putBoolean("autoReconnect",         autoReconnect);
        ed.putBoolean("killSwitch",            killSwitch);
        ed.putBoolean("stealthMode",           stealthMode);
        ed.putBoolean("blockAds",              blockAds);
        ed.putBoolean("blockIpv6",             blockIpv6);
        ed.putBoolean("dnsLeakProtect",        dnsLeakProtect);
        ed.putBoolean("smartNetworkReconnect", smartNetworkReconnect);
        ed.putBoolean("batteryOptimizer",      batteryOptimizer);
        ed.putBoolean("quickPingRefresh",      quickPingRefresh);
        ed.putInt("selectedServerId",    selectedServerId);
        ed.putInt("selectedSubServerId", selectedSubServerId);
        if (selectedSubId != null) ed.putString("selectedSubId", selectedSubId);
        else ed.remove("selectedSubId");
        ed.apply();
    }

    public void load(Context ctx) {
        SharedPreferences p = prefs(ctx);

        subscriptions.clear();
        try {
            String json = p.getString("subscriptions", "[]");
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Subscription sub = new Subscription(
                    o.optString("id", UUID.randomUUID().toString()),
                    o.optString("name", "Подписка"),
                    o.optString("url", "")
                );
                sub.lastUpdated = o.optLong("lastUpdated", 0);
                subscriptions.add(sub);
            }
        } catch (Exception ignored) {}

        try {
            String json = p.getString("subscription_servers", "[]");
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject subObj = arr.getJSONObject(i);
                String subId = subObj.optString("id", "");
                Subscription found = null;
                for (Subscription sub : subscriptions) {
                    if (sub.id.equals(subId)) { found = sub; break; }
                }
                if (found == null) continue;
                JSONArray srvArr = subObj.optJSONArray("servers");
                if (srvArr == null) continue;
                for (int j = 0; j < srvArr.length(); j++) {
                    JSONObject o = srvArr.getJSONObject(j);
                    SubServer s = new SubServer(
                        o.optString("name", "Server"),
                        o.optString("host", ""),
                        o.optString("port", "443"),
                        o.optString("proto", "auto"),
                        o.optString("raw", "")
                    );
                    s.subscriptionId = subId;
                    found.servers.add(s);
                }
            }
        } catch (Exception ignored) {}

        String cs = p.getString("custom_server", null);
        if (cs != null) customServer = CustomServer.deserialize(cs);

        protocol              = p.getString("protocol", "wireguard");
        autoReconnect         = p.getBoolean("autoReconnect",         false);
        killSwitch            = p.getBoolean("killSwitch",            false);
        stealthMode           = p.getBoolean("stealthMode",           false);
        blockAds              = p.getBoolean("blockAds",              true);
        blockIpv6             = p.getBoolean("blockIpv6",             true);
        dnsLeakProtect        = p.getBoolean("dnsLeakProtect",        true);
        smartNetworkReconnect = p.getBoolean("smartNetworkReconnect", true);
        batteryOptimizer      = p.getBoolean("batteryOptimizer",      false);
        quickPingRefresh      = p.getBoolean("quickPingRefresh",      true);
        selectedServerId      = p.getInt("selectedServerId",    -1);
        selectedSubServerId   = p.getInt("selectedSubServerId", 0);
        selectedSubId         = p.getString("selectedSubId", null);
    }

    private SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences("pulsevpn6", Context.MODE_PRIVATE);
    }
}
