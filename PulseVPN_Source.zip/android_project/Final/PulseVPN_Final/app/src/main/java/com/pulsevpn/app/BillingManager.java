package com.pulsevpn.app;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * BillingManager — Google Play Billing v7 wrapper for PulseVPN.
 *
 * Usage:
 *   BillingManager bm = new BillingManager(activity, callback);
 *   bm.launchPurchaseFlow(activity, "pulsevpn_premium_1m");
 *   bm.restorePurchases();
 *   // call bm.destroy() in onDestroy()
 *
 * Product IDs to register in Google Play Console:
 *   pulsevpn_premium_1m   — 149 ₽/месяц
 *   pulsevpn_premium_3m   — 299 ₽/3 месяца
 *   pulsevpn_premium_6m   — 774 ₽/6 месяцев
 *   pulsevpn_premium_12m  — 1357 ₽/12 месяцев
 */
public class BillingManager implements PurchasesUpdatedListener {

    private static final String TAG = "BillingManager";

    // ─── Subscription SKUs ────────────────────────────────────────────────────
    public static final String SKU_1M  = "pulsevpn_premium_1m";
    public static final String SKU_3M  = "pulsevpn_premium_3m";
    public static final String SKU_6M  = "pulsevpn_premium_6m";
    public static final String SKU_12M = "pulsevpn_premium_12m";

    public static final List<String> ALL_SKUS = Arrays.asList(SKU_1M, SKU_3M, SKU_6M, SKU_12M);

    // ─── Callback interface ───────────────────────────────────────────────────
    public interface BillingCallback {
        void onBillingReady();
        void onPurchaseSuccess(String sku);
        void onPurchaseFailed(String reason);
        void onAlreadySubscribed();
    }

    // ─── Fields ───────────────────────────────────────────────────────────────
    private final BillingClient                  billingClient;
    private final BillingCallback                callback;
    private final Map<String, ProductDetails>    productDetailsMap = new HashMap<>();
    private       boolean                        isReady           = false;

    // ─── Constructor ──────────────────────────────────────────────────────────
    public BillingManager(@NonNull Activity activity, @NonNull BillingCallback callback) {
        this.callback = callback;

        billingClient = BillingClient.newBuilder(activity)
            .setListener(this)
            .enablePendingPurchases()
            .build();

        startConnection();
    }

    // ─── Connection ───────────────────────────────────────────────────────────
    private void startConnection() {
        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(@NonNull BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    isReady = true;
                    loadProductDetails();
                    checkExistingPurchases();
                } else {
                    Log.w(TAG, "Billing setup failed: " + result.getDebugMessage());
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                isReady = false;
                Log.w(TAG, "Billing service disconnected — retrying...");
                // Retry after delay
                new android.os.Handler(android.os.Looper.getMainLooper())
                    .postDelayed(BillingManager.this::startConnection, 3000);
            }
        });
    }

    // ─── Load product details ─────────────────────────────────────────────────
    private void loadProductDetails() {
        List<QueryProductDetailsParams.Product> products = new ArrayList<>();
        for (String sku : ALL_SKUS) {
            products.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(sku)
                .setProductType(BillingClient.ProductType.SUBS)
                .build());
        }

        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
            .setProductList(products)
            .build();

        billingClient.queryProductDetailsAsync(params, (billingResult, productDetailsList) -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                for (ProductDetails pd : productDetailsList) {
                    productDetailsMap.put(pd.getProductId(), pd);
                }
                callback.onBillingReady();
            } else {
                Log.w(TAG, "Failed to load products: " + billingResult.getDebugMessage());
            }
        });
    }

    // ─── Launch purchase ──────────────────────────────────────────────────────
    public void launchPurchaseFlow(@NonNull Activity activity, @NonNull String sku) {
        if (!isReady) {
            callback.onPurchaseFailed("Сервис оплаты недоступен — попробуй позже");
            return;
        }

        ProductDetails details = productDetailsMap.get(sku);
        if (details == null) {
            // Product details not loaded yet — fallback: try querying inline
            callback.onPurchaseFailed("Информация о тарифе не загружена — проверь подключение");
            return;
        }

        List<ProductDetails.SubscriptionOfferDetails> offerDetails =
            details.getSubscriptionOfferDetails();
        if (offerDetails == null || offerDetails.isEmpty()) {
            callback.onPurchaseFailed("Тариф временно недоступен");
            return;
        }

        String offerToken = offerDetails.get(0).getOfferToken();

        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(
                List.of(BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(details)
                    .setOfferToken(offerToken)
                    .build()))
            .build();

        BillingResult result = billingClient.launchBillingFlow(activity, flowParams);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            callback.onPurchaseFailed("Не удалось открыть оплату: " + result.getDebugMessage());
        }
    }

    // ─── Purchases updated listener ───────────────────────────────────────────
    @Override
    public void onPurchasesUpdated(@NonNull BillingResult billingResult,
                                   @androidx.annotation.Nullable List<Purchase> purchases) {
        int code = billingResult.getResponseCode();

        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) {
                handlePurchase(purchase);
            }
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            // User cancelled — no error shown
            Log.d(TAG, "User cancelled purchase");
        } else if (code == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            callback.onAlreadySubscribed();
        } else {
            callback.onPurchaseFailed(billingResult.getDebugMessage());
        }
    }

    // ─── Handle purchase ──────────────────────────────────────────────────────
    private void handlePurchase(@NonNull Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;

        // Acknowledge the purchase if not already acknowledged
        if (!purchase.isAcknowledged()) {
            AcknowledgePurchaseParams ackParams = AcknowledgePurchaseParams.newBuilder()
                .setPurchaseToken(purchase.getPurchaseToken())
                .build();

            billingClient.acknowledgePurchase(ackParams, result -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    String sku = purchase.getProducts().isEmpty() ? "" : purchase.getProducts().get(0);
                    callback.onPurchaseSuccess(sku);
                } else {
                    callback.onPurchaseFailed("Не удалось подтвердить покупку");
                }
            });
        } else {
            String sku = purchase.getProducts().isEmpty() ? "" : purchase.getProducts().get(0);
            callback.onPurchaseSuccess(sku);
        }
    }

    // ─── Restore purchases ────────────────────────────────────────────────────
    public void restorePurchases() {
        if (!isReady) {
            callback.onPurchaseFailed("Сервис оплаты недоступен");
            return;
        }

        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build();

        billingClient.queryPurchasesAsync(params, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                boolean found = false;
                for (Purchase purchase : purchases) {
                    if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                        handlePurchase(purchase);
                        found = true;
                    }
                }
                if (!found) {
                    callback.onPurchaseFailed("Активных подписок не найдено");
                }
            } else {
                callback.onPurchaseFailed("Ошибка восстановления: " + billingResult.getDebugMessage());
            }
        });
    }

    // ─── Get formatted price ──────────────────────────────────────────────────
    @androidx.annotation.Nullable
    public String getFormattedPrice(String sku) {
        ProductDetails details = productDetailsMap.get(sku);
        if (details == null) return null;
        List<ProductDetails.SubscriptionOfferDetails> offers = details.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) return null;
        List<ProductDetails.PricingPhase> phases =
            offers.get(0).getPricingPhases().getPricingPhaseList();
        if (phases.isEmpty()) return null;
        return phases.get(0).getFormattedPrice();
    }

    // ─── Cleanup ──────────────────────────────────────────────────────────────
    public void destroy() {
        if (billingClient != null && billingClient.isReady()) {
            billingClient.endConnection();
        }
    }
}
