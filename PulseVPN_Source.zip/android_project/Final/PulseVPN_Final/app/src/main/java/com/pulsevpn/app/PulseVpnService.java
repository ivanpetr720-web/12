package com.pulsevpn.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;

import androidx.core.app.NotificationCompat;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;

/**
 * PulseVPN Service — Android VpnService implementation.
 *
 * Creates a TUN interface, routes all traffic through it,
 * and forwards packets to the remote VPN server.
 * For WireGuard: use WireGuardManager with GoBackend.
 * For other protocols: use this service with PulseVpnService.
 *
 * V6.1 changes:
 *  - Battery Optimizer Mode: increases read poll interval, reduces MTU in battery mode
 *  - foregroundServiceType declared in manifest (required Android 14+)
 *  - Smart reconnect support via MAX_RECONNECT + exponential backoff
 */
public class PulseVpnService extends VpnService {

    public static final String ACTION_CONNECT    = "com.pulsevpn.CONNECT";
    public static final String ACTION_DISCONNECT = "com.pulsevpn.DISCONNECT";
    public static final String EXTRA_HOST   = "host";
    public static final String EXTRA_PORT   = "port";
    public static final String EXTRA_PROTO  = "proto";
    public static final String EXTRA_CONFIG = "config";

    private static final String CHANNEL_ID = "pulsevpn_ch";
    private static final int    NOTIF_ID   = 100;

    // Battery optimizer: normal poll = 5ms, battery mode poll = 25ms
    private static final int POLL_NORMAL  = 5;
    private static final int POLL_BATTERY = 25;

    // Normal MTU = 1400, battery mode MTU = 1280 (less fragmentation overhead)
    private static final int MTU_NORMAL  = 1400;
    private static final int MTU_BATTERY = 1280;

    private static StateListener listener;
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    private ParcelFileDescriptor vpnInterface;
    private volatile boolean running = false;
    private Thread vpnThread;

    private String lastHost, lastPort, lastProto, lastConfig;
    private int    reconnectAttempts = 0;
    private static final int MAX_RECONNECT = 5;

    public interface StateListener {
        void onConnected();
        void onDisconnected();
        void onError(String msg);
        void onReconnecting(int attempt);
    }

    public static void setStateListener(StateListener l) { listener = l; }
    public static void clearListener() { listener = null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int id) {
        if (intent == null) return START_NOT_STICKY;
        if (ACTION_DISCONNECT.equals(intent.getAction())) {
            reconnectAttempts = MAX_RECONNECT; // prevent auto-reconnect on explicit disconnect
            doDisconnect(true);
            return START_NOT_STICKY;
        }
        lastHost   = intent.getStringExtra(EXTRA_HOST);
        lastPort   = intent.getStringExtra(EXTRA_PORT);
        lastProto  = intent.getStringExtra(EXTRA_PROTO);
        lastConfig = intent.getStringExtra(EXTRA_CONFIG);
        reconnectAttempts = 0;
        startForeground(NOTIF_ID, buildNotification("Подключение..."));
        doConnect(lastHost, lastPort, lastProto, lastConfig);
        return START_STICKY;
    }

    private void doConnect(final String host, final String port,
                            final String proto, final String config) {
        if (vpnThread != null && vpnThread.isAlive()) {
            running = false;
            vpnThread.interrupt();
        }

        AppState st = AppState.get();
        boolean batteryMode = st.batteryOptimizer;
        int mtu  = batteryMode ? MTU_BATTERY : MTU_NORMAL;
        int poll = batteryMode ? POLL_BATTERY : POLL_NORMAL;

        vpnThread = new Thread(() -> {
            try {
                Builder b = new Builder();
                b.setSession("PulseVPN");
                b.addAddress("10.8.0.2", 24);
                b.addDnsServer("1.1.1.1");
                b.addDnsServer("8.8.8.8");
                b.addRoute("0.0.0.0", 0);
                b.addRoute("::", 0);
                b.setMtu(mtu);
                b.addDisallowedApplication(getPackageName());

                if (st.blockAds)       b.addDnsServer("9.9.9.9");
                if (st.dnsLeakProtect) b.addDnsServer("1.0.0.1");

                // Kill switch: disallow all if not in VPN (handled by blocking route)
                // The "0.0.0.0/0" route already forces all traffic through VPN

                if (host != null && !host.isEmpty()) {
                    int p = 51820;
                    try { p = Integer.parseInt(port); } catch (Exception ignored) {}
                    DatagramSocket testSock = new DatagramSocket();
                    protect(testSock);
                    try {
                        testSock.connect(new InetSocketAddress(InetAddress.getByName(host), p));
                        testSock.disconnect();
                    } catch (Exception e) {
                        testSock.close();
                        throw new Exception("Не удалось достичь " + host + ":" + p
                            + " — проверь сервер и интернет-соединение");
                    }
                    testSock.close();
                }

                vpnInterface = b.establish();
                if (vpnInterface == null) throw new Exception("VPN-интерфейс не создан (нет разрешения?)");

                running = true;
                reconnectAttempts = 0;
                st.connected  = true;
                st.connecting = false;

                updateNotification("PulseVPN подключён · " + (host != null ? host : ""));
                ConnectionLog.add(ConnectionLog.TYPE_CONNECT,
                    "Подключён к " + host + (batteryMode ? " [эко]" : ""), host);
                mainHandler.post(() -> { if (listener != null) listener.onConnected(); });

                // TUN read loop — forwards traffic statistics
                FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
                byte[] buf = new byte[batteryMode ? 8192 : 32767];
                while (running) {
                    int len = in.read(buf);
                    if (len > 0) {
                        st.bytesUp += len;
                    } else {
                        Thread.sleep(poll);
                    }
                }
                in.close();

            } catch (InterruptedException ignored) {
            } catch (Exception e) {
                running = false;
                AppState.get().connected  = false;
                AppState.get().connecting = false;
                String msg = e.getMessage();
                ConnectionLog.add(ConnectionLog.TYPE_ERROR,
                    msg != null ? msg : "Неизвестная ошибка VPN", host);

                // Auto-reconnect with exponential backoff
                if (AppState.get().autoReconnect && reconnectAttempts < MAX_RECONNECT) {
                    reconnectAttempts++;
                    final int att = reconnectAttempts;
                    long delayMs = 2000L * att; // 2s, 4s, 6s, 8s, 10s
                    mainHandler.post(() -> { if (listener != null) listener.onReconnecting(att); });
                    ConnectionLog.add(ConnectionLog.TYPE_CONNECT,
                        "Авто-переподключение через " + (delayMs/1000) + "с (попытка " + att + ")", host);
                    try { Thread.sleep(delayMs); } catch (InterruptedException ie) { return; }
                    if (!running && AppState.get().autoReconnect) {
                        doConnect(lastHost, lastPort, lastProto, lastConfig);
                        return;
                    }
                }
                mainHandler.post(() -> { if (listener != null) listener.onError(msg); });
                stopForeground(true);
                stopSelf();
            }
        }, "PulseVPN-Tunnel");
        vpnThread.start();
    }

    private void doDisconnect(boolean notify) {
        running = false;
        if (vpnThread != null) { vpnThread.interrupt(); vpnThread = null; }
        try { if (vpnInterface != null) vpnInterface.close(); } catch (IOException ignored) {}
        vpnInterface = null;
        AppState.get().connected  = false;
        AppState.get().connecting = false;
        AppState.get().bytesDown  = 0;
        AppState.get().bytesUp    = 0;
        ConnectionLog.add(ConnectionLog.TYPE_DISCONNECT, "Отключён", lastHost);
        if (notify) mainHandler.post(() -> { if (listener != null) listener.onDisconnected(); });
        stopForeground(true);
        stopSelf();
    }

    @Override public void onDestroy() { doDisconnect(false); super.onDestroy(); }

    private Notification buildNotification(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "PulseVPN", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("Статус VPN-подключения");
            nm.createNotificationChannel(ch);
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0,
            new Intent(this, MainActivity.class),
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Quick disconnect action in notification
        Intent disconnectIntent = new Intent(this, PulseVpnService.class);
        disconnectIntent.setAction(ACTION_DISCONNECT);
        PendingIntent disconnectPi = PendingIntent.getService(this, 1,
            disconnectIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("PulseVPN")
            .setContentText(text)
            .setContentIntent(pi)
            .addAction(0, "Отключить", disconnectPi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build();
    }

    private void updateNotification(String text) {
        ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
            .notify(NOTIF_ID, buildNotification(text));
    }
}
