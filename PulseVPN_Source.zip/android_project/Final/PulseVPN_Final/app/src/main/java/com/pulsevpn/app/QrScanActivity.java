package com.pulsevpn.app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.CompoundBarcodeView;

public class QrScanActivity extends AppCompatActivity {
    public static final String RESULT_TEXT = "qr_result";
    private CompoundBarcodeView barcodeView;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_qr_scan);

        barcodeView = findViewById(R.id.barcode_scanner);
        if (barcodeView != null) {
            barcodeView.decodeContinuous(new BarcodeCallback() {
                @Override
                public void barcodeResult(BarcodeResult result) {
                    if (result.getText() != null) {
                        Intent data = new Intent();
                        data.putExtra(RESULT_TEXT, result.getText());
                        setResult(RESULT_OK, data);
                        finish();
                    }
                }
            });
        }

        TextView btnBack = findViewById(R.id.btn_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> { setResult(RESULT_CANCELED); finish(); });
        }
    }

    @Override protected void onResume() { super.onResume(); if (barcodeView != null) barcodeView.resume(); }
    @Override protected void onPause()  { super.onPause();  if (barcodeView != null) barcodeView.pause(); }
    @Override public void onBackPressed() { setResult(RESULT_CANCELED); super.onBackPressed(); }
}
