package com.pulsevpn.app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ServersFragment — subscription server list with search.
 *
 * V6.1 — Фишка #3: Quick Ping Refresh
 *  - "Обновить пинг" кнопка запускает параллельный TCP-пинг по всем серверам.
 *  - Если AppState.quickPingRefresh = true — запускается автоматически при открытии.
 *  - Цвет пинга обновляется в реальном времени (нет фейков).
 */
public class ServersFragment extends Fragment {

    private LinearLayout container;
    private EditText     etSearch;
    private AppState     st;

    private final Handler         mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService pingExec    = Executors.newFixedThreadPool(8);
    private volatile boolean      pinging     = false;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf,
                             @Nullable ViewGroup c, @Nullable Bundle b) {
        View v = inf.inflate(R.layout.fragment_servers, c, false);
        st = AppState.get();

        container = v.findViewById(R.id.server_list_container);
        etSearch  = v.findViewById(R.id.et_search);

        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                public void beforeTextChanged(CharSequence s, int i, int c2, int a) {}
                public void onTextChanged(CharSequence s, int i, int b2, int c2) { render(); }
                public void afterTextChanged(Editable s) {}
            });
        }

        // Quick ping refresh button
        TextView btnPing = v.findViewById(R.id.btn_ping_refresh);
        if (btnPing != null) {
            btnPing.setOnClickListener(vv -> runPingRefresh(btnPing));
        }

        render();

        // Auto-ping if enabled (Фишка #3)
        if (st.quickPingRefresh && st.getTotalServerCount() > 0) {
            if (btnPing != null) {
                final TextView pingBtnFinal = btnPing;
                mainHandler.postDelayed(() -> { if (isAdded()) runPingRefresh(pingBtnFinal); }, 400);
            } else {
                mainHandler.postDelayed(() -> { if (isAdded()) startBackgroundPing(null); }, 400);
            }
        }

        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        render();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        pingExec.shutdownNow();
    }

    public void render() {
        if (container == null || !isAdded()) return;
        container.removeAllViews();
        String q = etSearch != null ? etSearch.getText().toString().toLowerCase().trim() : "";
        renderSubscriptions(q);
    }

    private void renderSubscriptions(String q) {
        if (st.subscriptions.isEmpty()) {
            addHint("Нет серверов",
                    "Добавь подписку на вкладке «Защита» — нажми + и введи URL подписки");
            return;
        }

        int totalShown = 0;

        for (Subscription sub : st.subscriptions) {
            List<SubServer> filtered = new ArrayList<>();
            for (SubServer s : sub.servers) {
                if (q.isEmpty()
                    || s.name.toLowerCase().contains(q)
                    || s.host.toLowerCase().contains(q)
                    || s.getProtoLabel().toLowerCase().contains(q)) {
                    filtered.add(s);
                }
            }
            if (filtered.isEmpty() && !q.isEmpty()) continue;

            // Subscription header
            View header = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_sub_header, container, false);
            TextView tvN = header.findViewById(R.id.tv_sub_name);
            TextView tvC = header.findViewById(R.id.tv_sub_count);
            if (tvN != null) tvN.setText(sub.name);
            if (tvC != null) {
                int cnt = sub.servers.size();
                tvC.setText(cnt + (cnt == 1 ? " сервер" : cnt < 5 ? " сервера" : " серверов"));
            }
            container.addView(header);

            if (filtered.isEmpty()) {
                addHint(null, "Серверов нет — обнови подписку на вкладке Защита");
                continue;
            }

            for (SubServer srv : filtered) {
                final int idx = sub.servers.indexOf(srv);
                View card = LayoutInflater.from(requireContext())
                    .inflate(R.layout.item_server, container, false);

                LinearLayout root = card.findViewById(R.id.server_card_root);
                TextView tf  = card.findViewById(R.id.tv_flag);
                TextView tn  = card.findViewById(R.id.tv_name);
                TextView ts  = card.findViewById(R.id.tv_sub);
                TextView tp  = card.findViewById(R.id.tv_ping);
                TextView tb  = card.findViewById(R.id.tv_bars);
                TextView tl  = card.findViewById(R.id.tv_locked);

                if (tf != null) tf.setText(srv.getEmoji());
                if (tn != null) tn.setText(srv.name);
                if (ts != null) ts.setText(srv.host + ":" + srv.port + " · " + srv.getProtoLabel());
                if (tp != null) { tp.setText(srv.getPingText()); tp.setTextColor(srv.getPingColor()); }
                if (tb != null) { tb.setText(srv.getPingBars()); tb.setTextColor(srv.getPingColor()); }
                if (tl != null) tl.setVisibility(View.GONE);

                boolean sel = st.isSubSelected()
                    && sub.id.equals(st.selectedSubId)
                    && st.selectedSubServerId == idx;
                if (root != null) {
                    root.setBackgroundResource(sel ? R.drawable.card_selected : R.drawable.card_bg);
                }

                card.setOnClickListener(vv -> {
                    st.selectedServerId    = -3;
                    st.selectedSubId       = sub.id;
                    st.selectedSubServerId = idx;
                    MainActivity.get(this).saveState();
                    render();
                    HomeFragment home = MainActivity.get(this).getHomeFragment();
                    if (home != null) home.updateSelCard();
                    MainActivity.get(this).showToast(srv.getEmoji() + " " + srv.name);
                });

                container.addView(card);
                totalShown++;
            }
        }

        if (totalShown == 0 && !q.isEmpty()) {
            addHint(null, "Ничего не найдено по запросу «" + q + "»");
        }
    }

    // ─── Ping refresh (Фишка #3) ──────────────────────────────────────────────

    private void runPingRefresh(TextView btnPing) {
        if (pinging) return;
        pinging = true;
        if (btnPing != null) {
            btnPing.setText("Измерение...");
            // Rotate animation from XML
            Animation rotAnim = AnimationUtils.loadAnimation(requireContext(), R.anim.rotate_refresh);
            btnPing.startAnimation(rotAnim);
        }
        startBackgroundPing(btnPing);
        mainHandler.postDelayed(() -> {
            pinging = false;
            if (isAdded() && btnPing != null) {
                btnPing.clearAnimation();
                btnPing.setText("Обновить пинг");
            }
        }, 6000);
    }

    /**
     * Фишка #3 — Quick Ping Refresh:
     * Запускает параллельный TCP-пинг для каждого сервера.
     * Реальные задержки через Socket.connect() — никаких фейков.
     */
    private void startBackgroundPing(@Nullable TextView btnPing) {
        List<SubServer> allServers = st.getAllSubscriptionServers();
        for (SubServer srv : allServers) {
            final SubServer s = srv;
            pingExec.execute(() -> {
                int ping = measurePing(s.host, s.port);
                s.pingMs = ping;
                mainHandler.post(() -> { if (isAdded()) render(); });
            });
        }
    }

    /**
     * Real TCP-connect ping — measures actual round-trip latency.
     * Falls back to HTTP GET if TCP connect is blocked.
     */
    private int measurePing(String host, String portStr) {
        int port = 443;
        try { port = Integer.parseInt(portStr); } catch (Exception ignored) {}

        // Method 1: TCP connect (fastest, most accurate)
        try {
            long t0 = System.currentTimeMillis();
            Socket sock = new Socket();
            sock.connect(new InetSocketAddress(host, port), 4000);
            sock.close();
            return (int)(System.currentTimeMillis() - t0);
        } catch (Exception ignored) {}

        // Method 2: HTTP GET fallback
        try {
            long t0 = System.currentTimeMillis();
            HttpURLConnection conn = (HttpURLConnection) new URL("https://" + host).openConnection();
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(2000);
            conn.connect();
            conn.disconnect();
            return (int)(System.currentTimeMillis() - t0);
        } catch (Exception ignored) {}

        return 999; // unreachable
    }

    private void addHint(String title, String msg) {
        if (!isAdded()) return;
        LinearLayout box = new LinearLayout(requireContext());
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(0, 48, 0, 48);
        box.setGravity(android.view.Gravity.CENTER);

        if (title != null) {
            TextView t = new TextView(requireContext());
            t.setText(title);
            t.setTextColor(ContextCompat.getColor(requireContext(), R.color.text));
            t.setTextSize(15);
            t.setTypeface(null, android.graphics.Typeface.BOLD);
            t.setGravity(android.view.Gravity.CENTER);
            t.setPadding(0, 0, 0, 8);
            box.addView(t);
        }

        TextView sub = new TextView(requireContext());
        sub.setText(msg);
        sub.setTextColor(ContextCompat.getColor(requireContext(), R.color.text3));
        sub.setTextSize(12);
        sub.setGravity(android.view.Gravity.CENTER);
        sub.setLineSpacing(4, 1.3f);
        box.addView(sub);

        container.addView(box);
    }
}
