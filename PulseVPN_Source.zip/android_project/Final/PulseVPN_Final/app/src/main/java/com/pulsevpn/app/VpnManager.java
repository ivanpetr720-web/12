package com.pulsevpn.app;

import android.content.Context;
import android.content.Intent;
import android.net.VpnService;

public class VpnManager {

    public interface ConnectCallback {
        void onPermissionNeeded(Intent permIntent);
        void onStarted();
        void onError(String msg);
    }

    public static void connect(Context ctx, String host, String port,
                               String proto, String config, ConnectCallback cb) {
        Intent perm = VpnService.prepare(ctx);
        if (perm != null) {
            cb.onPermissionNeeded(perm);
            return;
        }
        Intent i = new Intent(ctx, PulseVpnService.class);
        i.setAction(PulseVpnService.ACTION_CONNECT);
        i.putExtra(PulseVpnService.EXTRA_HOST,   host);
        i.putExtra(PulseVpnService.EXTRA_PORT,   port);
        i.putExtra(PulseVpnService.EXTRA_PROTO,  proto);
        i.putExtra(PulseVpnService.EXTRA_CONFIG, config);
        ctx.startService(i);
        cb.onStarted();
    }

    public static void disconnect(Context ctx) {
        Intent i = new Intent(ctx, PulseVpnService.class);
        i.setAction(PulseVpnService.ACTION_DISCONNECT);
        ctx.startService(i);
    }
}
