package com.pulsevpn.app;

import java.util.ArrayList;
import java.util.List;

public class ServerData {

    public static List<Server> getFreeServers() {
        List<Server> list = new ArrayList<>();
        list.add(new Server("Germany",     "Frankfurt",  "de.pulsevpn.net",  "51820", "wireguard", "🇩🇪", false));
        list.add(new Server("Netherlands", "Amsterdam",  "nl.pulsevpn.net",  "51820", "wireguard", "🇳🇱", false));
        list.add(new Server("Finland",     "Helsinki",   "fi.pulsevpn.net",  "51820", "wireguard", "🇫🇮", false));
        return list;
    }

    public static List<Server> getPremiumServers() {
        List<Server> list = new ArrayList<>();
        list.add(new Server("United States",  "New York",    "us-ny.pulsevpn.net",  "51820", "wireguard", "🇺🇸", true));
        list.add(new Server("United States",  "Los Angeles", "us-la.pulsevpn.net",  "51820", "wireguard", "🇺🇸", true));
        list.add(new Server("United Kingdom", "London",      "uk.pulsevpn.net",     "51820", "wireguard", "🇬🇧", true));
        list.add(new Server("France",         "Paris",       "fr.pulsevpn.net",     "51820", "wireguard", "🇫🇷", true));
        list.add(new Server("Sweden",         "Stockholm",   "se.pulsevpn.net",     "51820", "wireguard", "🇸🇪", true));
        list.add(new Server("Switzerland",    "Zurich",      "ch.pulsevpn.net",     "51820", "wireguard", "🇨🇭", true));
        list.add(new Server("Singapore",      "Singapore",   "sg.pulsevpn.net",     "51820", "wireguard", "🇸🇬", true));
        list.add(new Server("Japan",          "Tokyo",       "jp.pulsevpn.net",     "51820", "wireguard", "🇯🇵", true));
        list.add(new Server("Canada",         "Toronto",     "ca.pulsevpn.net",     "51820", "wireguard", "🇨🇦", true));
        list.add(new Server("Australia",      "Sydney",      "au.pulsevpn.net",     "51820", "wireguard", "🇦🇺", true));
        return list;
    }
}
