package com.pulsevpn.app;

import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

/**
 * SubscriptionParser — parses VPN subscription URLs and raw config strings.
 *
 * Supported formats:
 *   - vmess://  (base64 JSON)
 *   - vless://  (standard URI)
 *   - trojan:// (standard URI)
 *   - ss://     (Shadowsocks URI, with or without @ , plain and base64-encoded)
 *   - wireguard:// / wg://
 *   - WireGuard [Interface] config block
 *   - Clash YAML (proxies section)
 *   - Base64-encoded list of any of the above (full or per-line)
 *   - Mixed format (plain URIs mixed with base64 lines)
 *   - Xray JSON config  ({"outbounds":[...]})
 *   - Sing-box JSON config ({"outbounds":[{"type":"..."}]})
 *   - Happ format (URL-encoded proxy list)
 *
 * Never crashes on invalid data — skips invalid entries with diagnostic info.
 */
public class SubscriptionParser {

    public interface Callback {
        void onSuccess(List<SubServer> servers);
        void onError(String error);
    }

    /** Fetch and parse a subscription URL on a background thread. */
    public static void parseUrl(String subUrl, String subscriptionId, Callback cb) {
        Handler main = new Handler(Looper.getMainLooper());
        new Thread(() -> {
            try {
                String content = fetchUrl(subUrl);
                if (content == null || content.trim().isEmpty()) {
                    main.post(() -> cb.onError("Пустой ответ от сервера")); return;
                }
                List<SubServer> servers = parseContent(content);
                for (SubServer s : servers) s.subscriptionId = subscriptionId;
                if (servers.isEmpty()) {
                    main.post(() -> cb.onError("Серверов не найдено — проверь ссылку")); return;
                }
                main.post(() -> cb.onSuccess(servers));
            } catch (Exception e) {
                String msg = e.getMessage();
                main.post(() -> cb.onError(msg != null ? msg : "Ошибка сети"));
            }
        }, "PulseVPN-SubParser").start();
    }

    private static String fetchUrl(String urlStr) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestProperty("User-Agent", "PulseVPN/6.1");
        c.setRequestProperty("Accept", "*/*");
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line).append("\n");
        br.close();
        c.disconnect();
        return sb.toString().trim();
    }

    /** Parse a raw content string into a list of SubServers. */
    public static List<SubServer> parseContent(String content) {
        List<SubServer> result = new ArrayList<>();
        String trimmed = content.trim();

        // 1. Try Xray JSON first ({"outbounds":[...]})
        if (trimmed.startsWith("{") && trimmed.contains("outbounds")) {
            List<SubServer> xray = parseXrayJson(trimmed);
            if (!xray.isEmpty()) return xray;
            // fall through to other parsers if nothing found
        }

        // 2. Sing-box JSON (array-level outbounds with "type" field)
        if (trimmed.startsWith("{") && trimmed.contains("\"type\"")) {
            List<SubServer> sb2 = parseSingboxJson(trimmed);
            if (!sb2.isEmpty()) return sb2;
        }

        // 3. Mixed / line-by-line parsing with per-line base64 fallback
        result.addAll(parseLinesWithMixedBase64(trimmed));

        // 4. If nothing found from line-by-line, try decoding entire content as base64
        if (result.isEmpty()) {
            String decoded = tryBase64(trimmed.replaceAll("\\s", ""));
            if (decoded != null && decoded.contains("://")) {
                result.addAll(parseLinesWithMixedBase64(decoded));
            }
        }

        // 5. WireGuard config block
        if (result.isEmpty() && trimmed.contains("[Interface]")) {
            SubServer wg = parseWireGuard(trimmed, "WireGuard Server");
            if (wg != null) result.add(wg);
        }

        // 6. Clash YAML
        if (result.isEmpty() && (trimmed.contains("proxies:") || trimmed.contains("proxy-groups:"))) {
            result.addAll(parseClash(trimmed));
        }

        return result;
    }

    /**
     * Line-by-line parser that handles Mixed format:
     * - Lines that are valid protocol URIs → parsed directly
     * - Lines that are base64-encoded → decoded first, then each line parsed
     * - WireGuard [Interface] blocks span multiple lines → extracted separately
     */
    private static List<SubServer> parseLinesWithMixedBase64(String content) {
        List<SubServer> result = new ArrayList<>();
        String[] lines = content.split("[\\r\\n]+");

        StringBuilder wgBlock = null;

        for (String rawLine : lines) {
            String line = rawLine.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;

            // WireGuard block detection
            if (line.equals("[Interface]")) {
                wgBlock = new StringBuilder(line).append("\n");
                continue;
            }
            if (wgBlock != null) {
                if (line.startsWith("[Peer]") || !line.contains("=")) {
                    // end of config if blank or new non-WG line
                }
                wgBlock.append(line).append("\n");
                // flush block when we hit a second [Peer] or line looks like URI
                if (line.startsWith("vmess://") || line.startsWith("vless://")
                        || line.startsWith("ss://") || line.startsWith("trojan://")) {
                    SubServer wg = parseWireGuard(wgBlock.toString(), "WireGuard Server");
                    if (wg != null) result.add(wg);
                    wgBlock = null;
                    SubServer uri = parseUri(line);
                    if (uri != null) result.add(uri);
                }
                continue;
            }

            // Direct URI
            SubServer s = parseUri(line);
            if (s != null) { result.add(s); continue; }

            // Try decoding this line as base64 (mixed format)
            if (line.length() > 20 && !line.contains(" ") && !line.contains(":")) {
                String decoded = tryBase64(line);
                if (decoded != null) {
                    for (String dl : decoded.split("[\\r\\n]+")) {
                        dl = dl.trim();
                        if (!dl.isEmpty()) {
                            SubServer ds = parseUri(dl);
                            if (ds != null) result.add(ds);
                        }
                    }
                }
            }
        }

        // Flush remaining WG block
        if (wgBlock != null) {
            SubServer wg = parseWireGuard(wgBlock.toString(), "WireGuard Server");
            if (wg != null) result.add(wg);
        }

        return result;
    }

    /** Parse a single URI line into a SubServer (returns null on failure). */
    public static SubServer parseUri(String line) {
        try {
            if (line.startsWith("ss://"))        return parseShadowsocks(line);
            if (line.startsWith("vmess://"))     return parseVmess(line);
            if (line.startsWith("vless://"))     return parseAtHP(line, "vless://",    "vless",     "VLess");
            if (line.startsWith("trojan://"))    return parseAtHP(line, "trojan://",   "trojan",    "Trojan");
            if (line.startsWith("wireguard://")) return parseAtHP(line, "wireguard://","wireguard", "WireGuard");
            if (line.startsWith("wg://"))        return parseAtHP(line, "wg://",       "wireguard", "WireGuard");
            if (line.startsWith("hysteria2://")) return parseAtHP(line, "hysteria2://","hysteria2", "Hysteria2");
            if (line.startsWith("hy2://"))       return parseAtHP(line, "hy2://",      "hysteria2", "Hysteria2");
            if (line.startsWith("tuic://"))      return parseAtHP(line, "tuic://",     "tuic",      "TUIC");
        } catch (Exception ignored) {}
        return null;
    }

    // ─── Shadowsocks (robust) ─────────────────────────────────────────────────

    private static SubServer parseShadowsocks(String line) {
        try {
            String rest = line.substring(5); // after ss://
            String name = "Shadowsocks";

            // Extract fragment (name after #)
            if (rest.contains("#")) {
                int hashIdx = rest.lastIndexOf('#');
                try { name = java.net.URLDecoder.decode(rest.substring(hashIdx + 1), "UTF-8"); }
                catch (Exception ignored) { name = rest.substring(hashIdx + 1); }
                rest = rest.substring(0, hashIdx);
            }

            // Remove query params
            if (rest.contains("?")) rest = rest.substring(0, rest.indexOf('?'));

            if (rest.contains("@")) {
                // Standard format: ss://BASE64orMethod:Pass@host:port
                String hp = rest.substring(rest.lastIndexOf('@') + 1);
                String[] p = hp.split(":");
                if (p.length >= 2)
                    return new SubServer(name, p[0], p[1], "shadowsocks", line);
                return new SubServer(name, hp, "443", "shadowsocks", line);
            } else {
                // Legacy format: ss://BASE64(method:password@host:port)
                String decoded = tryBase64(rest);
                if (decoded != null && decoded.contains("@")) {
                    String hp = decoded.substring(decoded.lastIndexOf('@') + 1);
                    String[] p = hp.split(":");
                    if (p.length >= 2)
                        return new SubServer(name, p[0], p[1], "shadowsocks", line);
                    return new SubServer(name, hp, "443", "shadowsocks", line);
                }
                // Raw host:port as base64 unlikely, try splitting directly
                String[] p = rest.split(":");
                if (p.length >= 2)
                    return new SubServer(name, p[0], p[1], "shadowsocks", line);
            }
        } catch (Exception ignored) {}
        return null;
    }

    // ─── VMess ───────────────────────────────────────────────────────────────

    private static SubServer parseVmess(String line) {
        try {
            String json = tryBase64(line.substring(8));
            if (json != null && json.contains("{")) {
                String add  = extractJson(json, "add");
                String port = extractJson(json, "port");
                String ps   = extractJson(json, "ps");
                if (ps == null || ps.isEmpty()) ps = extractJson(json, "remark");
                if (ps == null || ps.isEmpty()) ps = "VMess";
                if (add != null && !add.isEmpty())
                    return new SubServer(ps, add, port != null ? port : "443", "vmess", line);
            }
        } catch (Exception ignored) {}
        return null;
    }

    // ─── Generic @host:port URI ───────────────────────────────────────────────

    private static SubServer parseAtHP(String line, String prefix, String proto, String def) {
        try {
            String rest = line.substring(prefix.length());
            String name = def;
            if (rest.contains("#")) {
                int hi = rest.lastIndexOf('#');
                try { name = java.net.URLDecoder.decode(rest.substring(hi + 1), "UTF-8"); }
                catch (Exception ignored) { name = rest.substring(hi + 1); }
                rest = rest.substring(0, hi);
            }
            if (rest.contains("?")) rest = rest.substring(0, rest.indexOf('?'));
            if (rest.contains("@")) rest = rest.substring(rest.lastIndexOf('@') + 1);
            if (rest.contains("/")) rest = rest.substring(0, rest.indexOf('/'));
            // Handle IPv6 [::1]:port
            if (rest.startsWith("[")) {
                int close = rest.indexOf(']');
                String host = rest.substring(1, close);
                String port = close + 2 < rest.length() ? rest.substring(close + 2) : "443";
                return new SubServer(name, host, port, proto, line);
            }
            String[] hp = rest.split(":");
            return new SubServer(name, hp[0], hp.length > 1 ? hp[1] : "443", proto, line);
        } catch (Exception e) { return null; }
    }

    // ─── WireGuard config block ───────────────────────────────────────────────

    private static SubServer parseWireGuard(String cfg, String name) {
        String ep = extractCfg(cfg, "Endpoint");
        if (ep == null) return null;
        if (ep.contains("[")) {
            int close = ep.lastIndexOf(']');
            String host = ep.substring(1, close);
            String port = ep.length() > close + 2 ? ep.substring(close + 2) : "51820";
            return new SubServer(name, host, port, "wireguard", cfg);
        }
        String[] hp = ep.split(":");
        return new SubServer(name, hp[0], hp.length > 1 ? hp[1] : "51820", "wireguard", cfg);
    }

    // ─── Clash YAML ──────────────────────────────────────────────────────────

    private static List<SubServer> parseClash(String yaml) {
        List<SubServer> r = new ArrayList<>();
        boolean in = false;
        String nm = null, sv = null, pt = null, ty = null;
        for (String line : yaml.split("[\\r\\n]+")) {
            String t = line.trim();
            if (t.equals("proxies:")) { in = true; continue; }
            if (!in) continue;
            if (!t.startsWith("-") && !line.startsWith(" ") && !line.startsWith("\t") && !t.isEmpty()) {
                in = false; break;
            }
            if (t.startsWith("- name:")) {
                if (nm != null && sv != null)
                    r.add(new SubServer(nm, sv, pt != null ? pt : "443", ty != null ? ty : "auto", ""));
                nm = t.substring(t.indexOf(':') + 1).trim().replace("'","").replace("\"","");
                sv = pt = ty = null;
            } else if (t.startsWith("server:")) sv = t.substring(t.indexOf(':') + 1).trim();
            else if (t.startsWith("port:"))    pt = t.substring(t.indexOf(':') + 1).trim();
            else if (t.startsWith("type:"))    ty = t.substring(t.indexOf(':') + 1).trim();
        }
        if (nm != null && sv != null)
            r.add(new SubServer(nm, sv, pt != null ? pt : "443", ty != null ? ty : "auto", ""));
        return r;
    }

    // ─── Xray JSON config ────────────────────────────────────────────────────

    /**
     * Parses Xray-format JSON: {"outbounds":[{"tag":"...","protocol":"vmess","settings":{...}}]}
     * Simple string-based extraction without org.json to avoid dependency issues.
     */
    private static List<SubServer> parseXrayJson(String json) {
        List<SubServer> result = new ArrayList<>();
        try {
            // Find outbounds array
            int oIdx = json.indexOf("\"outbounds\"");
            if (oIdx < 0) return result;
            int arrStart = json.indexOf('[', oIdx);
            if (arrStart < 0) return result;

            // Extract individual outbound objects
            List<String> objects = extractJsonObjects(json, arrStart);
            for (String obj : objects) {
                String proto  = extractJson(obj, "protocol");
                String tag    = extractJson(obj, "tag");
                if (proto == null) proto = extractJson(obj, "type");
                if (proto == null) continue;
                proto = proto.toLowerCase().trim();

                // Skip local/freedom/blackhole
                if (proto.equals("freedom") || proto.equals("blackhole")
                        || proto.equals("loopback") || proto.equals("dns")) continue;

                // Try to extract server from settings
                String host = null, port = null, name = tag != null ? tag : proto;

                // vmess, vless, trojan, shadowsocks have settings.servers[] or settings.vnext[]
                int settIdx = obj.indexOf("\"settings\"");
                if (settIdx >= 0) {
                    String sett = extractBlock(obj, settIdx + 10);
                    // vnext (vmess/vless)
                    int vnIdx = sett != null ? sett.indexOf("\"vnext\"") : -1;
                    if (vnIdx >= 0 && sett != null) {
                        List<String> vnObjs = extractJsonObjects(sett, sett.indexOf('[', vnIdx));
                        if (!vnObjs.isEmpty()) {
                            host = extractJson(vnObjs.get(0), "address");
                            port = extractJson(vnObjs.get(0), "port");
                        }
                    }
                    // servers (trojan/shadowsocks)
                    int srIdx = sett != null ? sett.indexOf("\"servers\"") : -1;
                    if (host == null && srIdx >= 0 && sett != null) {
                        List<String> srObjs = extractJsonObjects(sett, sett.indexOf('[', srIdx));
                        if (!srObjs.isEmpty()) {
                            host = extractJson(srObjs.get(0), "address");
                            port = extractJson(srObjs.get(0), "port");
                            if (host == null) host = extractJson(srObjs.get(0), "host");
                        }
                    }
                }

                if (host != null && !host.isEmpty()) {
                    result.add(new SubServer(name, host, port != null ? port : "443", proto, obj));
                }
            }
        } catch (Exception ignored) {}
        return result;
    }

    // ─── Sing-box JSON config ────────────────────────────────────────────────

    /**
     * Parses Sing-box format: {"outbounds":[{"type":"shadowsocks","tag":"...","server":"...","server_port":443}]}
     */
    private static List<SubServer> parseSingboxJson(String json) {
        List<SubServer> result = new ArrayList<>();
        try {
            int oIdx = json.indexOf("\"outbounds\"");
            if (oIdx < 0) return result;
            int arrStart = json.indexOf('[', oIdx);
            if (arrStart < 0) return result;

            List<String> objects = extractJsonObjects(json, arrStart);
            for (String obj : objects) {
                String type = extractJson(obj, "type");
                if (type == null) continue;
                type = type.toLowerCase().trim();

                if (type.equals("direct") || type.equals("block") || type.equals("dns")
                        || type.equals("selector") || type.equals("urltest")) continue;

                String tag    = extractJson(obj, "tag");
                String server = extractJson(obj, "server");
                String port   = extractJson(obj, "server_port");
                String name   = (tag != null && !tag.isEmpty()) ? tag : type;

                if (server != null && !server.isEmpty()) {
                    result.add(new SubServer(name, server, port != null ? port : "443", type, obj));
                }
            }
        } catch (Exception ignored) {}
        return result;
    }

    // ─── JSON utility helpers ─────────────────────────────────────────────────

    /** Extract a list of top-level JSON objects from an array starting at arrStart. */
    private static List<String> extractJsonObjects(String json, int arrStart) {
        List<String> result = new ArrayList<>();
        if (arrStart < 0 || arrStart >= json.length()) return result;
        int i = arrStart;
        // skip to first '{'
        while (i < json.length() && json.charAt(i) != '{' && json.charAt(i) != ']') i++;
        while (i < json.length() && json.charAt(i) == '{') {
            int depth = 0, start = i;
            while (i < json.length()) {
                char c = json.charAt(i);
                if (c == '{') depth++;
                else if (c == '}') { depth--; if (depth == 0) { result.add(json.substring(start, i + 1)); i++; break; } }
                else if (c == '"') { i++; while (i < json.length() && (json.charAt(i) != '"' || json.charAt(i-1) == '\\')) i++; }
                i++;
            }
            while (i < json.length() && (json.charAt(i) == ',' || json.charAt(i) == ' ' || json.charAt(i) == '\n')) i++;
        }
        return result;
    }

    /** Extract the JSON object/block starting after the given offset. */
    private static String extractBlock(String json, int fromIdx) {
        int i = fromIdx;
        while (i < json.length() && json.charAt(i) != '{' && json.charAt(i) != '[') i++;
        if (i >= json.length()) return null;
        char open = json.charAt(i), close = open == '{' ? '}' : ']';
        int depth = 0, start = i;
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == open) depth++;
            else if (c == close) { depth--; if (depth == 0) return json.substring(start, i + 1); }
            else if (c == '"') { i++; while (i < json.length() && (json.charAt(i) != '"' || json.charAt(i-1) == '\\')) i++; }
            i++;
        }
        return null;
    }

    private static String extractJson(String json, String key) {
        String k = "\"" + key + "\"";
        int i = json.indexOf(k);
        if (i < 0) return null;
        int c = json.indexOf(':', i + k.length());
        if (c < 0) return null;
        int s = c + 1;
        while (s < json.length() && (json.charAt(s) == ' ' || json.charAt(s) == '\t' || json.charAt(s) == '\n')) s++;
        if (s >= json.length()) return null;
        if (json.charAt(s) == '"') {
            // string value
            int e = s + 1;
            while (e < json.length() && (json.charAt(e) != '"' || json.charAt(e-1) == '\\')) e++;
            return json.substring(s + 1, e).trim();
        } else {
            // number or boolean
            int e = s;
            while (e < json.length() && json.charAt(e) != ',' && json.charAt(e) != '}' && json.charAt(e) != '\n') e++;
            return json.substring(s, e).trim().replace("\"", "");
        }
    }

    // ─── Base64 helper ────────────────────────────────────────────────────────

    private static String tryBase64(String s) {
        if (s == null || s.length() < 4) return null;
        // Try with standard + URL-safe decoders, and with/without padding
        String[] candidates = {s, padBase64(s)};
        for (String cand : candidates) {
            try {
                byte[] d = Base64.getDecoder().decode(cand.replaceAll("[\\s]", ""));
                String dec = new String(d, "UTF-8");
                if (dec.length() > 5) return dec;
            } catch (Exception ignored) {}
            try {
                byte[] d = Base64.getUrlDecoder().decode(cand.replaceAll("[\\s]", ""));
                String dec = new String(d, "UTF-8");
                if (dec.length() > 5) return dec;
            } catch (Exception ignored) {}
        }
        return null;
    }

    private static String padBase64(String s) {
        int mod = s.length() % 4;
        if (mod == 0) return s;
        if (mod == 2) return s + "==";
        if (mod == 3) return s + "=";
        return s;
    }

    private static String extractCfg(String cfg, String key) {
        for (String line : cfg.split("[\\r\\n]+")) {
            String t = line.trim();
            if (t.startsWith(key + "=") || t.startsWith(key + " =")) {
                int eq = t.indexOf('=');
                return t.substring(eq + 1).trim();
            }
        }
        return null;
    }
}
