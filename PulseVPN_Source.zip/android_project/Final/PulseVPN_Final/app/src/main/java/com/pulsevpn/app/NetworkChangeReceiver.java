package com.pulsevpn.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;

/**
 * NetworkChangeReceiver — Фишка #1: Smart Network Reconnect.
 *
 * Отслеживает смену сети (Wi-Fi ↔ мобильные данные ↔ потеря связи).
 * Если VPN был активен и сеть переключилась — автоматически переподключается
 * через 2 секунды (даёт время на установку нового соединения).
 *
 * Регистрируется в MainActivity при включённой настройке smartNetworkReconnect.
 * Использует последние параметры подключения из AppState.
 */
public class NetworkChangeReceiver extends BroadcastReceiver {

    private static final long RECONNECT_DELAY_MS = 2000L;
    private static final Handler handler = new Handler(Looper.getMainLooper());

    private boolean lastConnected = true;
    private ReconnectListener listener;

    public interface ReconnectListener {
        void onNetworkReconnectNeeded();
    }

    public NetworkChangeReceiver(ReconnectListener listener) {
        this.listener = listener;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        AppState st = AppState.get();

        // Only act if Smart Network Reconnect is enabled
        if (!st.smartNetworkReconnect) return;

        ConnectivityManager cm = (ConnectivityManager)
            context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return;

        NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
        boolean nowConnected = (activeNetwork != null && activeNetwork.isConnected());

        if (!lastConnected && nowConnected) {
            // Network just came back
            if (st.connected || st.connecting) {
                // VPN was active — schedule reconnect
                ConnectionLog.add(ConnectionLog.TYPE_CONNECT,
                    "Сеть восстановлена — переподключение VPN...", "network");
                handler.removeCallbacksAndMessages("net_reconnect");
                handler.postDelayed(() -> {
                    if (listener != null) listener.onNetworkReconnectNeeded();
                }, RECONNECT_DELAY_MS);
            }
        }

        lastConnected = nowConnected;
    }
}
