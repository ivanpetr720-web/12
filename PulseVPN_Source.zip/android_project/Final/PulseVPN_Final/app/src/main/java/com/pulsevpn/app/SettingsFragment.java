package com.pulsevpn.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;

/**
 * SettingsFragment — unique PulseVPN settings UI.
 *
 * V6.1 additions:
 *  - Smart Network Reconnect toggle (Фишка #1)
 *  - Battery Optimizer Mode toggle  (Фишка #2)
 *  - Quick Ping Refresh toggle      (Фишка #3)
 */
public class SettingsFragment extends Fragment {
    private AppState st;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inflater.inflate(R.layout.fragment_settings, container, false);
        st = AppState.get();

        // ─── Protocol ──────────────────────────────────────────────────────
        TextView tvProtoValue = v.findViewById(R.id.tv_proto_value);
        if (tvProtoValue != null) {
            tvProtoValue.setText(protoDisplay(st.protocol));
        }
        View settingProtocol = v.findViewById(R.id.setting_protocol);
        if (settingProtocol != null) {
            settingProtocol.setOnClickListener(vv -> {
                String[] protos = {"wireguard", "shadowsocks", "vmess", "vless", "trojan"};
                String[] labels = {"WireGuard", "Shadowsocks", "VMess", "VLess", "Trojan"};
                new android.app.AlertDialog.Builder(requireContext())
                    .setTitle("Протокол")
                    .setItems(labels, (d, w) -> {
                        st.protocol = protos[w];
                        if (tvProtoValue != null) tvProtoValue.setText(labels[w]);
                        MainActivity.get(this).saveState();
                        toast("Протокол: " + labels[w]);
                    })
                    .show();
            });
        }

        // ─── DNS ───────────────────────────────────────────────────────────
        TextView tvDnsValue = v.findViewById(R.id.tv_dns_value);
        View settingDns = v.findViewById(R.id.setting_dns);
        if (settingDns != null) {
            settingDns.setOnClickListener(vv -> {
                String[] opts = {
                    "1.1.1.1 (Cloudflare)", "8.8.8.8 (Google)",
                    "9.9.9.9 (Quad9)",      "208.67.222.222 (OpenDNS)",
                    "94.140.14.14 (AdGuard)"
                };
                new android.app.AlertDialog.Builder(requireContext())
                    .setTitle("DNS-сервер")
                    .setItems(opts, (d, w) -> {
                        if (tvDnsValue != null) tvDnsValue.setText(opts[w]);
                        toast("DNS: " + opts[w]);
                        MainActivity.get(this).saveState();
                    })
                    .show();
            });
        }

        // ─── Security switches ─────────────────────────────────────────────
        SwitchCompat swKs = v.findViewById(R.id.sw_ks);
        if (swKs != null) {
            swKs.setChecked(st.killSwitch);
            swKs.setOnCheckedChangeListener((btn, checked) -> {
                st.killSwitch = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Kill Switch включён" : "Kill Switch выключен");
            });
        }

        SwitchCompat swDnsLeak = v.findViewById(R.id.sw_dns_leak);
        if (swDnsLeak != null) {
            swDnsLeak.setChecked(st.dnsLeakProtect);
            swDnsLeak.setOnCheckedChangeListener((btn, checked) -> {
                st.dnsLeakProtect = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Защита DNS включена" : "Защита DNS выключена");
            });
        }

        SwitchCompat swStealth = v.findViewById(R.id.sw_stealth);
        if (swStealth != null) {
            swStealth.setChecked(st.stealthMode);
            swStealth.setOnCheckedChangeListener((btn, checked) -> {
                st.stealthMode = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Stealth Mode включён" : "Stealth Mode выключен");
            });
        }

        SwitchCompat swIpv6 = v.findViewById(R.id.sw_ipv6);
        if (swIpv6 != null) {
            swIpv6.setChecked(st.blockIpv6);
            swIpv6.setOnCheckedChangeListener((btn, checked) -> {
                st.blockIpv6 = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "IPv6 заблокирован" : "IPv6 разрешён");
            });
        }

        // ─── Connection switches ───────────────────────────────────────────
        SwitchCompat swAutoReconnect = v.findViewById(R.id.sw_auto_reconnect);
        if (swAutoReconnect != null) {
            swAutoReconnect.setChecked(st.autoReconnect);
            swAutoReconnect.setOnCheckedChangeListener((btn, checked) -> {
                st.autoReconnect = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Авто-переподключение включено" : "Авто-переподключение выключено");
            });
        }

        SwitchCompat swAds = v.findViewById(R.id.sw_ads);
        if (swAds != null) {
            swAds.setChecked(st.blockAds);
            swAds.setOnCheckedChangeListener((btn, checked) -> {
                st.blockAds = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Блокировка рекламы включена" : "Блокировка рекламы выключена");
            });
        }

        // ─── New Features (V6.1) ───────────────────────────────────────────

        // Фишка #1: Smart Network Reconnect
        SwitchCompat swSmartNet = v.findViewById(R.id.sw_smart_network_reconnect);
        if (swSmartNet != null) {
            swSmartNet.setChecked(st.smartNetworkReconnect);
            swSmartNet.setOnCheckedChangeListener((btn, checked) -> {
                st.smartNetworkReconnect = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Умное переподключение включено" : "Умное переподключение выключено");
            });
        }

        // Фишка #2: Battery Optimizer
        SwitchCompat swBattery = v.findViewById(R.id.sw_battery_optimizer);
        if (swBattery != null) {
            swBattery.setChecked(st.batteryOptimizer);
            swBattery.setOnCheckedChangeListener((btn, checked) -> {
                st.batteryOptimizer = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Режим экономии батареи включён" : "Режим экономии батареи выключен");
            });
        }

        // Фишка #3: Quick Ping Refresh
        SwitchCompat swPingRefresh = v.findViewById(R.id.sw_quick_ping);
        if (swPingRefresh != null) {
            swPingRefresh.setChecked(st.quickPingRefresh);
            swPingRefresh.setOnCheckedChangeListener((btn, checked) -> {
                st.quickPingRefresh = checked;
                MainActivity.get(this).saveState();
                toast(checked ? "Авто-пинг серверов включён" : "Авто-пинг серверов выключен");
            });
        }

        // ─── Advanced ──────────────────────────────────────────────────────
        View btnExport = v.findViewById(R.id.btn_export);
        if (btnExport != null) {
            btnExport.setOnClickListener(vv -> toast("Экспорт конфигурации — скоро"));
        }

        View btnLogs = v.findViewById(R.id.btn_logs);
        if (btnLogs != null) {
            btnLogs.setOnClickListener(vv -> {
                StringBuilder sb = new StringBuilder();
                for (ConnectionLog log : ConnectionLog.getAll()) {
                    sb.append("[").append(log.getTimeText()).append("] ")
                      .append(log.getIcon()).append(" ")
                      .append(log.message).append("\n");
                }
                new android.app.AlertDialog.Builder(requireContext())
                    .setTitle("Лог соединений")
                    .setMessage(sb.length() > 0 ? sb.toString() : "Лог пустой")
                    .setPositiveButton("OK", null)
                    .setNeutralButton("Очистить", (d, w) -> { ConnectionLog.clear(); toast("Лог очищен"); })
                    .show();
            });
        }

        View btnDiag = v.findViewById(R.id.btn_diagnostics);
        if (btnDiag != null) {
            btnDiag.setOnClickListener(vv -> {
                requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right,
                                        android.R.anim.slide_in_left, android.R.anim.slide_out_right)
                    .replace(R.id.fragment_container, new DiagnosticsFragment())
                    .addToBackStack("diagnostics")
                    .commit();
            });
        }

        return v;
    }

    private String protoDisplay(String proto) {
        if (proto == null) return "Auto";
        switch (proto.toLowerCase()) {
            case "wireguard":   return "WireGuard";
            case "shadowsocks": return "Shadowsocks";
            case "vmess":       return "VMess";
            case "vless":       return "VLess";
            case "trojan":      return "Trojan";
            default:            return proto;
        }
    }

    private void toast(String msg) {
        if (isAdded()) MainActivity.get(this).showToast(msg);
    }
}
