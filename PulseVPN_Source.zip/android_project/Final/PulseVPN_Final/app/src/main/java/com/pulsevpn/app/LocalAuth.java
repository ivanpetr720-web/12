package com.pulsevpn.app;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * LocalAuth — simple on-device account system.
 * No server required — name/email/password hash stored in SharedPreferences.
 */
public class LocalAuth {
    private static final String PREFS    = "pulse_local_auth";
    private static final String KEY_NAME = "name";
    private static final String KEY_MAIL = "email";
    private static final String KEY_PASS = "pass_hash";
    private static final String KEY_IN   = "logged_in";
    private static final String KEY_GOOG = "google_name";  // set if signed in via Google
    private static final String KEY_GOOG_MAIL = "google_email";

    public static boolean isLoggedIn(Context ctx) {
        return prefs(ctx).getBoolean(KEY_IN, false);
    }

    public static String getName(Context ctx) {
        String g = prefs(ctx).getString(KEY_GOOG, "");
        if (!g.isEmpty()) return g;
        return prefs(ctx).getString(KEY_NAME, "Гость");
    }

    public static String getEmail(Context ctx) {
        String g = prefs(ctx).getString(KEY_GOOG_MAIL, "");
        if (!g.isEmpty()) return g;
        return prefs(ctx).getString(KEY_MAIL, "");
    }

    public static boolean isGoogleAuth(Context ctx) {
        return !prefs(ctx).getString(KEY_GOOG, "").isEmpty();
    }

    /** Login or register with local credentials. Returns false if fields empty. */
    public static boolean loginLocal(Context ctx, String name, String email, String password) {
        if (name.trim().isEmpty() || email.trim().isEmpty()) return false;
        prefs(ctx).edit()
            .putString(KEY_NAME, name.trim())
            .putString(KEY_MAIL, email.trim().toLowerCase())
            .putString(KEY_PASS, Integer.toHexString(password.hashCode()))
            .remove(KEY_GOOG).remove(KEY_GOOG_MAIL)
            .putBoolean(KEY_IN, true)
            .apply();
        return true;
    }

    /** Called after successful Google Sign-In. */
    public static void loginGoogle(Context ctx, String displayName, String email) {
        prefs(ctx).edit()
            .putString(KEY_GOOG, displayName != null ? displayName : "Google User")
            .putString(KEY_GOOG_MAIL, email != null ? email : "")
            .putBoolean(KEY_IN, true)
            .apply();
    }

    public static void logout(Context ctx) {
        prefs(ctx).edit()
            .putBoolean(KEY_IN, false)
            .remove(KEY_GOOG).remove(KEY_GOOG_MAIL)
            .apply();
    }

    private static SharedPreferences prefs(Context ctx) {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
