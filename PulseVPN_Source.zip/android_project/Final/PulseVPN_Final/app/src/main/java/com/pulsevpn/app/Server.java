package com.pulsevpn.app;

public class Server {
    public String  name;
    public String  location;
    public String  host;
    public String  port;
    public String  proto;
    public String  flag;
    public boolean isPremium;
    public int     pingMs = -1;

    public Server(String name, String location, String host, String port,
                  String proto, String flag, boolean isPremium) {
        this.name      = name;
        this.location  = location;
        this.host      = host;
        this.port      = port;
        this.proto     = proto;
        this.flag      = flag;
        this.isPremium = isPremium;
    }

    public String getPingText() {
        if (pingMs < 0)  return "—";
        return pingMs + "ms";
    }

    public int getPingColor() {
        if (pingMs < 0)   return 0xFF4A6A64;
        if (pingMs < 80)  return 0xFF00FF88;
        if (pingMs < 200) return 0xFFFFCC00;
        return 0xFFFF4466;
    }

    public String getPingBars() {
        if (pingMs < 0)   return "▮▯▯▯";
        if (pingMs < 80)  return "▮▮▮▮";
        if (pingMs < 150) return "▮▮▮▯";
        if (pingMs < 300) return "▮▮▯▯";
        return "▮▯▯▯";
    }
}
