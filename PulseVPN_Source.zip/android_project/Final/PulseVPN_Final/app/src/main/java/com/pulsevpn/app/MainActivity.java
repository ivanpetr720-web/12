package com.pulsevpn.app;

import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    private TextView  lblHome, lblServers, lblSettings, lblProfile;
    private View      indHome, indServers, indSettings, indProfile;
    private int       currentTab = -1;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);

        AppState.get().load(this);

        lblHome     = findViewById(R.id.nav_home_label);
        lblServers  = findViewById(R.id.nav_servers_label);
        lblSettings = findViewById(R.id.nav_settings_label);
        lblProfile  = findViewById(R.id.nav_profile_label);
        indHome     = findViewById(R.id.ind_home);
        indServers  = findViewById(R.id.ind_servers);
        indSettings = findViewById(R.id.ind_settings);
        indProfile  = findViewById(R.id.ind_profile);

        LinearLayout navHome     = findViewById(R.id.nav_home);
        LinearLayout navServers  = findViewById(R.id.nav_servers);
        LinearLayout navSettings = findViewById(R.id.nav_settings);
        LinearLayout navProfile  = findViewById(R.id.nav_profile);

        if (navHome     != null) navHome.setOnClickListener(v     -> show(0));
        if (navServers  != null) navServers.setOnClickListener(v  -> show(1));
        if (navSettings != null) navSettings.setOnClickListener(v -> show(2));
        if (navProfile  != null) navProfile.setOnClickListener(v  -> show(3));

        if (b == null) show(0);
    }

    public void show(int tab) {
        if (tab == currentTab) return;
        currentTab = tab;

        Fragment f;
        switch (tab) {
            case 1:  f = new ServersFragment();  break;
            case 2:  f = new SettingsFragment(); break;
            case 3:  f = new ProfileFragment();  break;
            default: f = new HomeFragment();     break;
        }

        getSupportFragmentManager()
            .beginTransaction()
            .setCustomAnimations(R.anim.slide_up_enter, R.anim.slide_down_exit)
            .replace(R.id.fragment_container, f)
            .commitAllowingStateLoss();

        updateNavUI(tab);
    }

    private void updateNavUI(int tab) {
        int active   = ContextCompat.getColor(this, R.color.nav_active);
        int inactive = ContextCompat.getColor(this, R.color.nav_inactive);

        if (lblHome     != null) lblHome.setTextColor(tab == 0 ? active : inactive);
        if (lblServers  != null) lblServers.setTextColor(tab == 1 ? active : inactive);
        if (lblSettings != null) lblSettings.setTextColor(tab == 2 ? active : inactive);
        if (lblProfile  != null) lblProfile.setTextColor(tab == 3 ? active : inactive);

        if (indHome     != null) indHome.setVisibility(tab == 0 ? View.VISIBLE : View.GONE);
        if (indServers  != null) indServers.setVisibility(tab == 1 ? View.VISIBLE : View.GONE);
        if (indSettings != null) indSettings.setVisibility(tab == 2 ? View.VISIBLE : View.GONE);
        if (indProfile  != null) indProfile.setVisibility(tab == 3 ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        AppState.get().save(this);
    }

    public static MainActivity get(Fragment f) {
        return (MainActivity) f.requireActivity();
    }

    public void showToast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_SHORT).show());
    }

    public void saveState() {
        AppState.get().save(this);
    }

    public void openServers()  { show(1); }
    public void openSettings() { show(2); }
    public void openProfile()  { show(3); }
    public void openPaywall()  { show(3); }

    public HomeFragment getHomeFragment() {
        androidx.fragment.app.Fragment f = getSupportFragmentManager()
            .findFragmentById(R.id.fragment_container);
        return (f instanceof HomeFragment) ? (HomeFragment) f : null;
    }
}
