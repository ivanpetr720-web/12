package com.pulsevpn.app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * DiagnosticsFragment — real-time IP check and DNS leak test.
 * Fetches current IP from ipapi.co, checks VPN status, compares with stored real IP.
 */
public class DiagnosticsFragment extends Fragment {

    private final Handler         handler = new Handler(Looper.getMainLooper());
    private final ExecutorService exec    = Executors.newCachedThreadPool();

    private TextView tvRealIp, tvRealLoc, tvRealOrg;
    private TextView tvVpnStatus, tvVpnDetail;
    private TextView tvDnsResult, tvDnsDetail;
    private TextView tvPingResult;
    private TextView tvOverall;
    private TextView btnTest;

    private AppState st;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inflater.inflate(R.layout.fragment_diagnostics, container, false);
        st = AppState.get();

        tvRealIp    = v.findViewById(R.id.tv_real_ip);
        tvRealLoc   = v.findViewById(R.id.tv_real_loc);
        tvRealOrg   = v.findViewById(R.id.tv_real_org);
        tvVpnStatus = v.findViewById(R.id.tv_vpn_status);
        tvVpnDetail = v.findViewById(R.id.tv_vpn_detail);
        tvDnsResult = v.findViewById(R.id.tv_dns_result);
        tvDnsDetail = v.findViewById(R.id.tv_dns_detail);
        tvPingResult = v.findViewById(R.id.tv_ping_result);
        tvOverall   = v.findViewById(R.id.tv_overall);
        btnTest     = v.findViewById(R.id.btn_run_test);

        TextView btnBack = v.findViewById(R.id.btn_back);
        if (btnBack != null) {
            btnBack.setOnClickListener(vv ->
                requireActivity().getSupportFragmentManager().popBackStack());
        }

        if (btnTest != null) {
            btnTest.setOnClickListener(vv -> runDiagnostics());
        }

        initState();
        return v;
    }

    private void initState() {
        if (!isAdded()) return;

        int clrGreen  = ContextCompat.getColor(requireContext(), R.color.green);
        int clrDim    = ContextCompat.getColor(requireContext(), R.color.text_dim);
        int clrText2  = ContextCompat.getColor(requireContext(), R.color.text2);

        // Real IP
        if (!st.realIp.isEmpty()) {
            set(tvRealIp,  st.realIp,      clrGreen);
            set(tvRealLoc, st.realCountry,  clrText2);
        } else {
            set(tvRealIp,  "Нажми «Запустить тест»", clrDim);
            set(tvRealLoc, "—", clrDim);
        }
        if (tvRealOrg != null) tvRealOrg.setText("—");

        // VPN
        updateVpnRow();

        set(tvDnsResult, "Ожидание теста...", clrDim);
        set(tvDnsDetail, "—", clrDim);
        set(tvPingResult, "—", clrDim);
        set(tvOverall, "Нажми кнопку для диагностики", clrDim);
    }

    private void updateVpnRow() {
        if (!isAdded()) return;
        int clrGreen = ContextCompat.getColor(requireContext(), R.color.green);
        int clrDim   = ContextCompat.getColor(requireContext(), R.color.text_dim);
        int clrText2 = ContextCompat.getColor(requireContext(), R.color.text2);

        if (st.connected) {
            SubServer sub = st.getSelectedSubServer();
            set(tvVpnStatus, "● Подключён", clrGreen);
            set(tvVpnDetail, sub != null ? sub.host + " · " + sub.getProtoLabel() : "VPN активен", clrText2);
        } else {
            set(tvVpnStatus, "○ Не подключён", clrDim);
            set(tvVpnDetail, "Подключись через вкладку Защита", clrDim);
        }
    }

    private void runDiagnostics() {
        if (!isAdded()) return;

        int clrYellow = ContextCompat.getColor(requireContext(), R.color.yellow);

        if (btnTest != null) { btnTest.setText("Идёт тест..."); btnTest.setEnabled(false); }
        set(tvRealIp,    "Определение...", clrYellow);
        set(tvDnsResult, "Тестирование DNS...", clrYellow);
        set(tvOverall,   "Анализ...", clrYellow);

        exec.execute(() -> {
            // 1. Fetch current IP
            String ipJson  = fetchJson("https://ipapi.co/json/");
            String ip      = "";
            String country = "";
            String city    = "";
            String org     = "";

            try {
                if (ipJson != null) {
                    JSONObject j = new JSONObject(ipJson);
                    ip      = j.optString("ip", "");
                    country = j.optString("country_name", "");
                    city    = j.optString("city", "");
                    org     = j.optString("org", j.optString("asn", ""));
                }
            } catch (Exception ignored) {}

            // 2. Ping test (measure round-trip to 1.1.1.1)
            long pingMs = -1;
            try {
                long t0 = System.currentTimeMillis();
                fetchRaw("https://1.1.1.1");
                pingMs = System.currentTimeMillis() - t0;
            } catch (Exception ignored) {}

            final String fIp      = ip.isEmpty() ? "Не определён" : ip;
            final String fLoc     = buildLoc(country, city);
            final String fOrg     = org;
            final long   fPingMs  = pingMs;

            // 3. DNS leak analysis
            boolean connected = st.connected;
            boolean leak      = false;
            if (connected && !st.realIp.isEmpty() && !ip.isEmpty()) {
                leak = ip.equals(st.realIp);
            }
            final boolean fLeak = leak;

            // Store real IP for future reference (only when not connected)
            if (!connected && !ip.isEmpty()) {
                st.realIp      = ip;
                st.realCountry = fLoc;
            }

            handler.post(() -> {
                if (!isAdded()) return;

                int clrGrn  = ContextCompat.getColor(requireContext(), R.color.green);
                int clrRed  = ContextCompat.getColor(requireContext(), R.color.red);
                int clrYlw  = ContextCompat.getColor(requireContext(), R.color.yellow);
                int clrDim2 = ContextCompat.getColor(requireContext(), R.color.text_dim);
                int clrTxt2 = ContextCompat.getColor(requireContext(), R.color.text2);

                // Real IP card
                set(tvRealIp,  fIp,  fIp.equals("Не определён") ? clrRed : clrGrn);
                set(tvRealLoc, fLoc.isEmpty() ? "Неизвестно" : fLoc, clrTxt2);
                set(tvRealOrg, fOrg.isEmpty() ? "—" : fOrg, clrDim2);

                // VPN row
                updateVpnRow();

                // DNS result
                if (connected) {
                    if (fLeak) {
                        set(tvDnsResult, "⚠  Утечка обнаружена!", clrRed);
                        set(tvDnsDetail, "IP не изменился — DNS утекает через провайдера", clrRed);
                        set(tvOverall,   "⚠  Возможна утечка DNS-данных", clrRed);
                    } else {
                        set(tvDnsResult, "Утечек не обнаружено", clrGrn);
                        set(tvDnsDetail, fOrg.isEmpty() ? "DNS работает через VPN-туннель" : fOrg, clrTxt2);
                        set(tvOverall,   "Вы полностью защищены", clrGrn);
                    }
                } else {
                    set(tvDnsResult, "VPN не активен", clrYlw);
                    set(tvDnsDetail, fOrg.isEmpty() ? "Используется DNS провайдера" : "Провайдер: " + fOrg, clrTxt2);
                    set(tvOverall,   "Ваш реальный IP виден всем", clrYlw);
                }

                // Ping
                if (fPingMs >= 0) {
                    int pingColor = fPingMs < 80 ? clrGrn : fPingMs < 250 ? clrYlw : clrRed;
                    set(tvPingResult, fPingMs + " мс", pingColor);
                } else {
                    set(tvPingResult, "Недоступно", clrDim2);
                }

                if (btnTest != null) { btnTest.setText("Повторить тест"); btnTest.setEnabled(true); }
            });
        });
    }

    private String buildLoc(String country, String city) {
        if (country.isEmpty() && city.isEmpty()) return "";
        if (city.isEmpty())    return country;
        if (country.isEmpty()) return city;
        return country + ", " + city;
    }

    private String fetchJson(String urlStr) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
            c.setConnectTimeout(10000); c.setReadTimeout(10000);
            c.setRequestProperty("User-Agent", "PulseVPN/6.1");
            BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
            StringBuilder sb = new StringBuilder(); String line;
            while ((line = br.readLine()) != null) sb.append(line);
            br.close(); c.disconnect();
            return sb.toString();
        } catch (Exception e) { return null; }
    }

    private void fetchRaw(String urlStr) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(5000); c.setReadTimeout(5000);
        c.getResponseCode(); c.disconnect();
    }

    private void set(TextView tv, String text, int color) {
        if (tv == null) return;
        tv.setText(text); tv.setTextColor(color);
    }
}
