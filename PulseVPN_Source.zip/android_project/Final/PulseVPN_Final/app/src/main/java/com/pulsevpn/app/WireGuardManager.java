package com.pulsevpn.app;

import android.content.Context;

import androidx.annotation.NonNull;

import com.wireguard.android.backend.BackendException;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * WireGuardManager — wraps GoBackend for real WireGuard connections.
 *
 * Uses the official wireguard-android library which provides a native
 * Go userspace WireGuard implementation (BoringTun/wireguard-go).
 */
public class WireGuardManager {

    public interface Callback {
        void onConnected();
        void onDisconnected();
        void onError(String message);
    }

    private static volatile GoBackend  backend;
    private static volatile Tunnel     activeTunnel;
    private static final ExecutorService exec = Executors.newSingleThreadExecutor();

    public static synchronized GoBackend getBackend(Context ctx) {
        if (backend == null) backend = new GoBackend(ctx.getApplicationContext());
        return backend;
    }

    public static void connect(Context ctx, final String rawWgConfig, final Callback cb) {
        exec.execute(() -> {
            try {
                Config config = Config.parse(new BufferedReader(new StringReader(rawWgConfig)));
                GoBackend b   = getBackend(ctx);

                activeTunnel = new Tunnel() {
                    @NonNull @Override public String getName() { return "PulseVPN"; }
                    @Override
                    public void onStateChange(@NonNull State newState) {
                        if (newState == State.UP) {
                            AppState.get().connected  = true;
                            AppState.get().connecting = false;
                            ConnectionLog.add(ConnectionLog.TYPE_CONNECT, "WireGuard подключён", "wg");
                            cb.onConnected();
                        } else if (newState == State.DOWN) {
                            AppState.get().connected  = false;
                            AppState.get().connecting = false;
                            ConnectionLog.add(ConnectionLog.TYPE_DISCONNECT, "WireGuard отключён", "wg");
                            cb.onDisconnected();
                        }
                    }
                };

                b.setState(activeTunnel, Tunnel.State.UP, config);

            } catch (BackendException e) {
                AppState.get().connected  = false;
                AppState.get().connecting = false;
                String msg = "WireGuard: " + e.getReason().name().replace("_", " ").toLowerCase();
                ConnectionLog.add(ConnectionLog.TYPE_ERROR, msg, "wg");
                cb.onError(msg);
            } catch (Exception e) {
                AppState.get().connected  = false;
                AppState.get().connecting = false;
                String msg = e.getMessage() != null ? e.getMessage() : "Ошибка WireGuard";
                ConnectionLog.add(ConnectionLog.TYPE_ERROR, msg, "wg");
                cb.onError(msg);
            }
        });
    }

    public static void disconnect() {
        exec.execute(() -> {
            try {
                if (backend != null && activeTunnel != null)
                    backend.setState(activeTunnel, Tunnel.State.DOWN, null);
            } catch (Exception ignored) {}
            AppState.get().connected  = false;
            AppState.get().connecting = false;
        });
    }

    public static boolean isWireGuardConfig(String rawConfig) {
        return rawConfig != null && (
            rawConfig.contains("[Interface]") ||
            rawConfig.contains("PrivateKey")  ||
            rawConfig.contains("PublicKey")
        );
    }

    public static boolean canParse(String rawConfig) {
        if (rawConfig == null || rawConfig.isEmpty()) return false;
        try {
            Config.parse(new BufferedReader(new StringReader(rawConfig)));
            return true;
        } catch (Exception e) { return false; }
    }
}
