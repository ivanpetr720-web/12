package com.pulsevpn.app;

public class CustomServer {
    public String  name;
    public String  host;
    public String  port;
    public String  proto;
    public String  rawConfig;
    public boolean isSubscription;
    public String  subUrl;

    public CustomServer(String name, String host, String port, String proto) {
        this.name           = name;
        this.host           = host;
        this.port           = port;
        this.proto          = proto;
        this.isSubscription = false;
    }

    public CustomServer(String name, String subUrl) {
        this.name           = name;
        this.subUrl         = subUrl;
        this.isSubscription = true;
        this.host           = subUrl;
        this.port           = "443";
        this.proto          = "auto";
    }

    public String getDisplayHost() {
        if (isSubscription) return subUrl;
        return host + ":" + port;
    }

    public String getProtoDisplay() {
        if (isSubscription) return "URL Subscription";
        if (proto == null) return "Auto";
        switch (proto.toLowerCase()) {
            case "wireguard": return "WireGuard";
            case "openvpn":   return "OpenVPN";
            case "shadowsocks": return "Shadowsocks";
            case "vmess":     return "VMess";
            case "vless":     return "VLess";
            case "trojan":    return "Trojan";
            default: return proto;
        }
    }

    public String serialize() {
        return name + "\u0001" + (host != null ? host : "") + "\u0001"
            + (port != null ? port : "") + "\u0001"
            + (proto != null ? proto : "") + "\u0001"
            + (rawConfig != null ? rawConfig.replace("\n", "\u0002") : "") + "\u0001"
            + (isSubscription ? "1" : "0") + "\u0001"
            + (subUrl != null ? subUrl : "");
    }

    public static CustomServer deserialize(String s) {
        try {
            String[] p = s.split("\u0001", -1);
            if (p.length < 4) return null;
            boolean isSub = p.length >= 6 && "1".equals(p[5]);
            CustomServer cs;
            if (isSub) {
                String url = p.length >= 7 ? p[6] : p[1];
                cs = new CustomServer(p[0], url);
            } else {
                cs = new CustomServer(p[0], p[1], p[2], p[3]);
            }
            if (p.length >= 5 && !p[4].isEmpty()) {
                cs.rawConfig = p[4].replace("\u0002", "\n");
            }
            return cs;
        } catch (Exception e) { return null; }
    }
}
