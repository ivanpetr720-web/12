package com.pulsevpn.app;

import java.util.ArrayList;
import java.util.List;

public class Subscription {
    public String        id;
    public String        name;
    public String        url;
    public List<SubServer> servers;
    public long          lastUpdated;
    public boolean       isLoading;

    public Subscription(String id, String name, String url) {
        this.id          = id;
        this.name        = name;
        this.url         = url;
        this.servers     = new ArrayList<>();
        this.lastUpdated = 0;
        this.isLoading   = false;
    }

    public int getServerCount() {
        return servers != null ? servers.size() : 0;
    }

    public String getStatusText() {
        if (isLoading)       return "Загрузка...";
        if (servers.isEmpty()) return "Нет серверов";
        return servers.size() + " серв.";
    }

    private static String escapeField(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("|", "\\|");
    }

    private static String unescapeField(String s) {
        if (s == null) return "";
        return s.replace("\\|", "|").replace("\\\\", "\\");
    }

    public String serialize() {
        return escapeField(id) + "|" + escapeField(name) + "|" + escapeField(url) + "|" + lastUpdated;
    }

    public static Subscription deserialize(String s) {
        try {
            String[] parts = s.split("\\|", 4);
            if (parts.length < 3) return null;
            Subscription sub = new Subscription(
                unescapeField(parts[0]),
                unescapeField(parts[1]),
                unescapeField(parts[2])
            );
            if (parts.length >= 4) {
                try { sub.lastUpdated = Long.parseLong(parts[3]); } catch (Exception ignored) {}
            }
            return sub;
        } catch (Exception e) { return null; }
    }
}
