package com.pulsevpn.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * HomeFragment — Protection tab.
 *
 * Merges V4 UI identity with V5 backend:
 *   - V4: central connect button, stats row, IP card, selected server card,
 *         custom server section, subscription list with inline servers
 *   - V5: AppState, VpnManager, WireGuardManager, SubscriptionParser,
 *         PulseVpnService state listener, IP detection via ipapi.co
 */
public class HomeFragment extends Fragment {
    private static final int VPN_REQ = 1001;
    private static final int QR_REQ  = 1002;

    // Views
    private TextView tvStatus, tvTimer, tvDl, tvUl, tvIp, tvIpLocation, tvIpFlag;
    private TextView btnConnect, tvSelFlag, tvSelName, tvSelSub, tvSelPing, tvSelLabel;
    private TextView btnAddServer;
    private TextView tvCustomName, tvCustomHost, tvCustomProto, btnUseCustom, btnDeleteCustom;
    private LinearLayout statsRow, subscriptionsContainer;
    private LinearLayout customServerCard, customServerEmpty;
    private View ring1;

    private final Handler         handler = new Handler(Looper.getMainLooper());
    private final ExecutorService exec    = Executors.newCachedThreadPool();
    private final Random          rnd     = new Random();
    private AppState st;

    private Runnable timerR, speedR, pulseR;
    private String   pendHost, pendPort, pendProto, pendConfig;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inf,
                             @Nullable ViewGroup c, @Nullable Bundle b) {
        View v = inf.inflate(R.layout.fragment_home, c, false);
        st = AppState.get();

        PulseVpnService.setStateListener(new PulseVpnService.StateListener() {
            @Override public void onConnected() {
                if (!isAdded()) return;
                MainActivity.get(HomeFragment.this).saveState();
                updateUI(); startTimer(); startSpeed(); startPulse();
                toast("Подключён — " + getConnName());
                updateIpVpn();
            }
            @Override public void onDisconnected() {
                if (!isAdded()) return;
                stopAll(); updateUI(); toast("Отключён"); setIpDefault(); fetchIp();
            }
            @Override public void onError(String msg) {
                if (!isAdded()) return;
                st.connected = false; st.connecting = false;
                stopAll(); updateUI();
                toast(msg != null ? "Ошибка: " + msg : "Ошибка подключения");
            }
            @Override public void onReconnecting(int attempt) {
                if (!isAdded()) return;
                toast("Переподключение... попытка " + attempt);
            }
        });

        bindViews(v);
        setupClicks();
        updateUI();
        setIpDefault();
        fetchIp();
        updateSelCard();
        updateCustomServerView();
        renderSubscriptions();

        if (st.connected) { startTimer(); startSpeed(); startPulse(); }
        return v;
    }

    private void bindViews(View v) {
        tvStatus          = v.findViewById(R.id.tv_status);
        tvTimer           = v.findViewById(R.id.tv_timer);
        tvDl              = v.findViewById(R.id.tv_dl);
        tvUl              = v.findViewById(R.id.tv_ul);
        tvIp              = v.findViewById(R.id.tv_ip);
        tvIpLocation      = v.findViewById(R.id.tv_ip_location);
        tvIpFlag          = v.findViewById(R.id.tv_ip_flag);
        statsRow          = v.findViewById(R.id.stats_row);
        btnConnect        = v.findViewById(R.id.btn_connect);
        ring1             = v.findViewById(R.id.ring1);
        tvSelFlag         = v.findViewById(R.id.tv_sel_flag);
        tvSelLabel        = v.findViewById(R.id.tv_sel_label);
        tvSelName         = v.findViewById(R.id.tv_sel_name);
        tvSelSub          = v.findViewById(R.id.tv_sel_sub);
        tvSelPing         = v.findViewById(R.id.tv_sel_ping);
        btnAddServer      = v.findViewById(R.id.btn_add_server);
        customServerCard  = v.findViewById(R.id.custom_server_card);
        customServerEmpty = v.findViewById(R.id.custom_server_empty);
        tvCustomName      = v.findViewById(R.id.tv_custom_name);
        tvCustomHost      = v.findViewById(R.id.tv_custom_host);
        tvCustomProto     = v.findViewById(R.id.tv_custom_proto);
        btnUseCustom      = v.findViewById(R.id.btn_use_custom);
        btnDeleteCustom   = v.findViewById(R.id.btn_delete_custom);
        subscriptionsContainer = v.findViewById(R.id.subscriptions_container);
    }

    private void setupClicks() {
        if (btnConnect   != null) btnConnect.setOnClickListener(v -> onConn());
        if (btnAddServer != null) btnAddServer.setOnClickListener(v -> showAddDialog());
        if (btnUseCustom != null) btnUseCustom.setOnClickListener(v -> selectCustomServer());
        if (btnDeleteCustom != null) btnDeleteCustom.setOnClickListener(v -> deleteCustomServer());
    }

    @Override
    public void onActivityResult(int req, int res, @Nullable Intent data) {
        super.onActivityResult(req, res, data);
        if (req == VPN_REQ) {
            if (res == Activity.RESULT_OK && pendHost != null)
                startVpnNow(pendHost, pendPort, pendProto, pendConfig);
            else { st.connecting = false; updateUI(); toast("Разрешение VPN отклонено"); }
        } else if (req == QR_REQ && res == Activity.RESULT_OK && data != null) {
            handleQr(data.getStringExtra(QrScanActivity.RESULT_TEXT));
        }
    }

    // ─── Connection ──────────────────────────────────────────────────────────

    private void onConn() {
        if (st.connecting) return;
        if (st.connected) { doDisconnect(); return; }

        // Priority: sub server → custom server → nothing
        SubServer subSrv = st.getSelectedSubServer();
        if (subSrv != null) {
            if (WireGuardManager.isWireGuardConfig(subSrv.rawConfig)) {
                connectWireGuard(subSrv.host, subSrv.rawConfig, subSrv.name);
            } else {
                reqVpn(subSrv.host, subSrv.port, subSrv.proto, subSrv.rawConfig);
            }
            return;
        }
        if (st.isCustomSelected() && st.customServer != null) {
            CustomServer cs = st.customServer;
            if (WireGuardManager.isWireGuardConfig(cs.rawConfig)) {
                connectWireGuard(cs.host, cs.rawConfig, cs.name);
            } else {
                reqVpn(cs.host, cs.port, cs.proto, cs.rawConfig);
            }
            return;
        }
        toast("Выбери сервер ниже или добавь подписку/сервер");
    }

    private void connectWireGuard(String host, String rawConfig, String displayName) {
        st.connecting = true; st.connected = false; updateUI();
        toast("WireGuard: подключение к " + host + "...");

        Intent perm = android.net.VpnService.prepare(requireContext());
        if (perm != null) {
            pendHost = host; pendPort = "51820"; pendProto = "wireguard"; pendConfig = rawConfig;
            startActivityForResult(perm, VPN_REQ);
            return;
        }
        WireGuardManager.connect(requireContext(), rawConfig, new WireGuardManager.Callback() {
            @Override public void onConnected() {
                if (!isAdded()) return;
                handler.post(() -> {
                    MainActivity.get(HomeFragment.this).saveState();
                    updateUI(); startTimer(); startSpeed(); startPulse();
                    toast("🔒 WireGuard подключён: " + displayName);
                    updateIpVpn();
                });
            }
            @Override public void onDisconnected() {
                if (!isAdded()) return;
                handler.post(() -> { stopAll(); updateUI(); toast("Отключён"); setIpDefault(); fetchIp(); });
            }
            @Override public void onError(String msg) {
                if (!isAdded()) return;
                handler.post(() -> { st.connecting = false; updateUI(); toast("Ошибка: " + msg); });
            }
        });
    }

    private void reqVpn(String h, String p, String pr, String cfg) {
        st.connecting = true; st.connected = false; updateUI();
        pendHost = h; pendPort = p; pendProto = pr; pendConfig = cfg;
        VpnManager.connect(requireContext(), h, p, pr, cfg, new VpnManager.ConnectCallback() {
            @Override public void onPermissionNeeded(Intent i) { startActivityForResult(i, VPN_REQ); }
            @Override public void onStarted() { toast("Подключаюсь к " + h + "..."); }
            @Override public void onError(String msg) {
                if (isAdded()) { st.connecting = false; updateUI(); toast(msg); }
            }
        });
    }

    private void startVpnNow(String h, String p, String pr, String cfg) {
        if ("wireguard".equalsIgnoreCase(pr) && WireGuardManager.isWireGuardConfig(cfg)) {
            connectWireGuard(h, cfg, h);
        } else {
            VpnManager.connect(requireContext(), h, p, pr, cfg, new VpnManager.ConnectCallback() {
                @Override public void onPermissionNeeded(Intent i) {}
                @Override public void onStarted() {}
                @Override public void onError(String msg) {
                    if (isAdded()) { st.connecting = false; updateUI(); toast(msg); }
                }
            });
        }
    }

    private void doDisconnect() {
        WireGuardManager.disconnect();
        VpnManager.disconnect(requireContext());
        st.connected = false; st.connecting = false; st.timerSec = 0;
        stopAll(); updateUI(); toast("Отключено"); setIpDefault(); fetchIp();
    }

    // ─── UI update ───────────────────────────────────────────────────────────

    private void updateUI() {
        if (!isAdded() || btnConnect == null) return;

        if (st.connected) {
            set(tvStatus, "ЗАЩИЩЁН", 0xFF00FF88);
            btnConnect.setText("ОТКЛЮЧИТЬ");
            btnConnect.setTextColor(Color.parseColor("#0A0F0D"));
            btnConnect.setBackgroundResource(R.drawable.connect_btn_connected);
            btnConnect.clearAnimation();
            if (statsRow != null) statsRow.setVisibility(View.VISIBLE);
            if (tvTimer  != null) tvTimer.setVisibility(View.VISIBLE);
        } else if (st.connecting) {
            set(tvStatus, "ПОДКЛЮЧЕНИЕ...", 0xFFFFCC00);
            btnConnect.setText("...");
            btnConnect.setTextColor(0xFFFFCC00);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_normal);
            if (statsRow != null) statsRow.setVisibility(View.GONE);
            if (tvTimer  != null) tvTimer.setVisibility(View.GONE);
            AlphaAnimation a = new AlphaAnimation(0.3f, 1f);
            a.setDuration(600); a.setRepeatMode(Animation.REVERSE);
            a.setRepeatCount(Animation.INFINITE);
            btnConnect.startAnimation(a);
        } else {
            set(tvStatus, "НЕ ЗАЩИЩЁН", 0xFF4A6A64);
            btnConnect.setText("CONNECT");
            btnConnect.setTextColor(0xFF4A6A64);
            btnConnect.setBackgroundResource(R.drawable.connect_btn_normal);
            btnConnect.clearAnimation();
            if (statsRow != null) statsRow.setVisibility(View.GONE);
            if (tvTimer  != null) tvTimer.setVisibility(View.GONE);
        }
    }

    private void set(TextView tv, String text, int color) {
        if (tv == null) return;
        tv.setText(text); tv.setTextColor(color);
    }

    void updateSelCard() {
        if (!isAdded()) return;
        SubServer sub = st.getSelectedSubServer();
        if (sub != null) {
            set(tvSelLabel, "ИЗ ПОДПИСКИ", 0xFF00AA55);
            set(tvSelName,  sub.name,       0xFFE8F5F0);
            set(tvSelSub,   sub.host + ":" + sub.port + " · " + sub.getProtoLabel(), 0xFF4A6A60);
            set(tvSelPing,  sub.getPingText(), sub.getPingColor());
            if (tvSelFlag != null) tvSelFlag.setText(sub.getEmoji());
        } else if (st.isCustomSelected() && st.customServer != null) {
            set(tvSelLabel, "МОЙ СЕРВЕР",           0xFF00AA55);
            set(tvSelName,  st.customServer.name,    0xFFE8F5F0);
            set(tvSelSub,   st.customServer.getDisplayHost() + " · " + st.customServer.getProtoDisplay(), 0xFF4A6A60);
            set(tvSelPing,  "—", 0xFF4A6A64);
            if (tvSelFlag != null) tvSelFlag.setText("CS");
        } else {
            if (tvSelFlag  != null) tvSelFlag.setText("–");
            set(tvSelLabel, "СЕРВЕР",                       0xFF00AA55);
            set(tvSelName,  "Не выбран",                    0xFFE8F5F0);
            set(tvSelSub,   "Добавь подписку и выбери сервер", 0xFF4A6A60);
            set(tvSelPing,  "—", 0xFF4A6A64);
        }
    }

    // ─── Custom server section ────────────────────────────────────────────────

    void updateCustomServerView() {
        if (!isAdded()) return;
        boolean has = st.customServer != null;
        if (customServerEmpty != null) customServerEmpty.setVisibility(has ? View.GONE  : View.VISIBLE);
        if (customServerCard  != null) customServerCard.setVisibility(has  ? View.VISIBLE : View.GONE);
        if (has && st.customServer != null) {
            if (tvCustomName  != null) tvCustomName.setText(st.customServer.name);
            if (tvCustomHost  != null) tvCustomHost.setText(st.customServer.getDisplayHost());
            if (tvCustomProto != null) tvCustomProto.setText(st.customServer.getProtoDisplay());
        }
    }

    private void selectCustomServer() {
        st.selectedServerId = -2;
        st.selectedSubId    = null;
        MainActivity.get(this).saveState();
        updateSelCard();
        toast("Выбран: " + (st.customServer != null ? st.customServer.name : "Мой сервер"));
    }

    private void deleteCustomServer() {
        new AlertDialog.Builder(requireContext())
            .setTitle("Удалить сервер?")
            .setPositiveButton("Удалить", (d, w) -> {
                st.customServer = null;
                if (st.isCustomSelected()) { st.selectedServerId = -1; st.selectedSubId = null; }
                MainActivity.get(this).saveState();
                updateCustomServerView(); updateSelCard();
                toast("Сервер удалён");
            })
            .setNegativeButton("Отмена", null)
            .show();
    }

    // ─── Add dialog (Manual + URL tabs) ──────────────────────────────────────

    private void showAddDialog() {
        if (!isAdded()) return;
        View dv = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_add_server, null);

        TextView tabManual = dv.findViewById(R.id.tab_manual);
        TextView tabUrl    = dv.findViewById(R.id.tab_url);
        LinearLayout panelManual = dv.findViewById(R.id.panel_manual);
        LinearLayout panelUrl    = dv.findViewById(R.id.panel_url);

        final boolean[] isUrl = {false};

        AlertDialog dlg = new AlertDialog.Builder(requireContext())
            .setView(dv).create();
        if (dlg.getWindow() != null)
            dlg.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        if (tabManual != null) tabManual.setOnClickListener(v -> {
            isUrl[0] = false;
            tabManual.setBackgroundResource(R.drawable.btn_green);
            tabManual.setTextColor(Color.parseColor("#000000"));
            if (tabUrl != null) { tabUrl.setBackground(null); tabUrl.setTextColor(0xFF4A6A64); }
            if (panelManual != null) panelManual.setVisibility(View.VISIBLE);
            if (panelUrl    != null) panelUrl.setVisibility(View.GONE);
        });
        if (tabUrl != null) tabUrl.setOnClickListener(v -> {
            isUrl[0] = true;
            tabUrl.setBackgroundResource(R.drawable.btn_green);
            tabUrl.setTextColor(Color.parseColor("#000000"));
            if (tabManual != null) { tabManual.setBackground(null); tabManual.setTextColor(0xFF4A6A64); }
            if (panelManual != null) panelManual.setVisibility(View.GONE);
            if (panelUrl    != null) panelUrl.setVisibility(View.VISIBLE);
        });

        // Protocol toggle
        TextView protoWg   = dv.findViewById(R.id.proto_wg);
        TextView protoOvpn = dv.findViewById(R.id.proto_ovpn);
        TextView protoSs   = dv.findViewById(R.id.proto_ss);
        final String[] selectedProto = {"wireguard"};
        View.OnClickListener protoClick = pv -> {
            protoWg.setBackgroundResource(pv == protoWg ? R.drawable.btn_proto_active : R.drawable.btn_proto_inactive);
            protoWg.setTextColor(pv == protoWg ? Color.BLACK : 0xFF4A6A64);
            if (protoOvpn != null) {
                protoOvpn.setBackgroundResource(pv == protoOvpn ? R.drawable.btn_proto_active : R.drawable.btn_proto_inactive);
                protoOvpn.setTextColor(pv == protoOvpn ? Color.BLACK : 0xFF4A6A64);
            }
            if (protoSs != null) {
                protoSs.setBackgroundResource(pv == protoSs ? R.drawable.btn_proto_active : R.drawable.btn_proto_inactive);
                protoSs.setTextColor(pv == protoSs ? Color.BLACK : 0xFF4A6A64);
            }
            if (pv == protoWg)   selectedProto[0] = "wireguard";
            else if (pv == protoOvpn) selectedProto[0] = "openvpn";
            else selectedProto[0] = "shadowsocks";
        };
        if (protoWg   != null) protoWg.setOnClickListener(protoClick);
        if (protoOvpn != null) protoOvpn.setOnClickListener(protoClick);
        if (protoSs   != null) protoSs.setOnClickListener(protoClick);

        TextView btnQr     = dv.findViewById(R.id.btn_qr_scan);
        TextView btnSave   = dv.findViewById(R.id.btn_save);
        TextView btnCancel = dv.findViewById(R.id.btn_cancel);
        EditText etName    = dv.findViewById(R.id.et_name);
        EditText etHost    = dv.findViewById(R.id.et_host);
        EditText etPort    = dv.findViewById(R.id.et_port);
        EditText etUrlName = dv.findViewById(R.id.et_url_name);
        EditText etUrl     = dv.findViewById(R.id.et_url);

        if (btnCancel != null) btnCancel.setOnClickListener(v -> dlg.dismiss());
        if (btnQr != null) btnQr.setOnClickListener(v -> {
            dlg.dismiss();
            startActivityForResult(new Intent(requireContext(), QrScanActivity.class), QR_REQ);
        });

        if (btnSave != null) btnSave.setOnClickListener(v -> {
            if (isUrl[0]) {
                // URL subscription mode
                String name = etUrlName != null ? etUrlName.getText().toString().trim() : "";
                String url  = etUrl     != null ? etUrl.getText().toString().trim()     : "";
                if (name.isEmpty()) { toast("Введи название"); return; }
                if (url.isEmpty() || !url.startsWith("http")) { toast("Введи корректный URL"); return; }
                Subscription sub = new Subscription(UUID.randomUUID().toString(), name, url);
                st.subscriptions.add(sub);
                MainActivity.get(this).saveState();
                renderSubscriptions();
                dlg.dismiss();
                refreshSubscription(sub);
            } else {
                // Manual server mode
                String name = etName != null ? etName.getText().toString().trim() : "";
                String host = etHost != null ? etHost.getText().toString().trim() : "";
                String port = etPort != null ? etPort.getText().toString().trim() : "51820";
                if (host.isEmpty()) { toast("Введи хост или IP"); return; }
                if (name.isEmpty()) name = host;
                if (port.isEmpty()) port = selectedProto[0].equals("wireguard") ? "51820" : "443";
                CustomServer cs = new CustomServer(name, host, port, selectedProto[0]);
                st.customServer = cs;
                st.selectedServerId = -2;
                st.selectedSubId    = null;
                MainActivity.get(this).saveState();
                updateCustomServerView();
                updateSelCard();
                dlg.dismiss();
                toast("Добавлен: " + name);
            }
        });

        dlg.show();
    }

    // ─── Subscription rendering ───────────────────────────────────────────────

    void renderSubscriptions() {
        if (!isAdded() || subscriptionsContainer == null) return;
        subscriptionsContainer.removeAllViews();

        if (st.subscriptions.isEmpty()) {
            View empty = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_empty_sub, subscriptionsContainer, false);
            subscriptionsContainer.addView(empty);
            return;
        }

        for (Subscription sub : st.subscriptions) {
            View card = LayoutInflater.from(requireContext())
                .inflate(R.layout.item_subscription, subscriptionsContainer, false);

            TextView tvName    = card.findViewById(R.id.tv_sub_name);
            TextView tvStatus2 = card.findViewById(R.id.tv_sub_status);
            TextView btnRefresh = card.findViewById(R.id.btn_sub_refresh);
            TextView btnDelete  = card.findViewById(R.id.btn_sub_delete);
            LinearLayout serversIn = card.findViewById(R.id.sub_servers_list);

            if (tvName    != null) tvName.setText(sub.name);
            if (tvStatus2 != null) tvStatus2.setText(sub.getStatusText());

            if (serversIn != null) {
                serversIn.removeAllViews();
                for (int i = 0; i < sub.servers.size(); i++) {
                    final int   idx = i;
                    SubServer   srv = sub.servers.get(i);
                    View        sc  = LayoutInflater.from(requireContext())
                        .inflate(R.layout.item_server_compact, serversIn, false);

                    TextView tf = sc.findViewById(R.id.tv_flag);
                    TextView tn = sc.findViewById(R.id.tv_name);
                    TextView tp = sc.findViewById(R.id.tv_proto);
                    TextView tpi = sc.findViewById(R.id.tv_ping);
                    View    sr  = sc.findViewById(R.id.server_root);

                    if (tf  != null) tf.setText(srv.getEmoji());
                    if (tn  != null) tn.setText(srv.name);
                    if (tp  != null) tp.setText(srv.getProtoLabel());
                    if (tpi != null) { tpi.setText(srv.getPingText()); tpi.setTextColor(srv.getPingColor()); }

                    boolean sel = st.isSubSelected()
                        && sub.id.equals(st.selectedSubId)
                        && st.selectedSubServerId == idx;
                    if (sr != null) sr.setBackgroundResource(sel ? R.drawable.card_selected : R.drawable.card_bg);

                    sc.setOnClickListener(vv -> {
                        st.selectedServerId    = -3;
                        st.selectedSubId       = sub.id;
                        st.selectedSubServerId = idx;
                        MainActivity.get(this).saveState();
                        renderSubscriptions();
                        updateSelCard();
                        toast(srv.getEmoji() + " " + srv.name);
                    });
                    serversIn.addView(sc);
                }
            }

            if (btnRefresh != null) btnRefresh.setOnClickListener(vv -> refreshSubscription(sub));
            if (btnDelete  != null) btnDelete.setOnClickListener(vv -> deleteSubscription(sub));

            subscriptionsContainer.addView(card);
        }
    }

    private void refreshSubscription(Subscription sub) {
        sub.isLoading = true;
        renderSubscriptions();
        toast("Обновление " + sub.name + "...");
        SubscriptionParser.parseUrl(sub.url, sub.id, new SubscriptionParser.Callback() {
            @Override public void onSuccess(List<SubServer> servers) {
                if (!isAdded()) return;
                sub.servers.clear();
                sub.servers.addAll(servers);
                sub.lastUpdated = System.currentTimeMillis();
                sub.isLoading   = false;
                MainActivity.get(HomeFragment.this).saveState();
                renderSubscriptions();
                toast("Загружено: " + servers.size() + " серверов");
            }
            @Override public void onError(String err) {
                if (!isAdded()) return;
                sub.isLoading = false;
                renderSubscriptions();
                toast("Ошибка: " + err);
            }
        });
    }

    private void deleteSubscription(Subscription sub) {
        new AlertDialog.Builder(requireContext())
            .setTitle("Удалить подписку?")
            .setMessage("\"" + sub.name + "\" будет удалена вместе с серверами")
            .setPositiveButton("Удалить", (d, w) -> {
                st.subscriptions.remove(sub);
                if (sub.id.equals(st.selectedSubId)) {
                    st.selectedSubId = null; st.selectedServerId = -1;
                }
                MainActivity.get(this).saveState();
                renderSubscriptions(); updateSelCard();
                toast("Удалено");
            })
            .setNegativeButton("Отмена", null).show();
    }

    // ─── IP detection ─────────────────────────────────────────────────────────

    private void setIpDefault() {
        if (!isAdded()) return;
        if (tvIp         != null) tvIp.setText("Определение...");
        if (tvIpLocation != null) tvIpLocation.setText("—");
        if (tvIpFlag     != null) tvIpFlag.setText("🌐");
    }

    private void fetchIp() {
        exec.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection)
                    new URL("https://ipapi.co/json/").openConnection();
                c.setConnectTimeout(7000); c.setReadTimeout(7000);
                c.setRequestProperty("User-Agent", "PulseVPN/6.0");
                BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) sb.append(line);
                br.close();
                org.json.JSONObject j = new org.json.JSONObject(sb.toString());
                String ip  = j.optString("ip", "");
                String loc = j.optString("country_name", "")
                    + (j.optString("city", "").isEmpty() ? "" : ", " + j.optString("city", ""));
                String flag = ccToFlag(j.optString("country_code", "").toUpperCase());
                st.realIp = ip; st.realCountry = loc; st.realFlag = flag; st.ipLoaded = true;
                handler.post(() -> {
                    if (!isAdded() || st.connected) return;
                    if (tvIp         != null) tvIp.setText(ip.isEmpty() ? "Скрыт" : ip);
                    if (tvIpLocation != null) tvIpLocation.setText(loc);
                    if (tvIpFlag     != null) tvIpFlag.setText(flag);
                });
            } catch (Exception e) {
                handler.post(() -> { if (isAdded() && tvIp != null) tvIp.setText("Скрыт"); });
            }
        });
    }

    private void updateIpVpn() {
        if (!isAdded()) return;
        SubServer sub = st.getSelectedSubServer();
        String fakeIp = "10." + rnd.nextInt(255) + "." + rnd.nextInt(255) + "." + rnd.nextInt(255);
        if (tvIp         != null) tvIp.setText(fakeIp);
        if (tvIpLocation != null) tvIpLocation.setText(sub != null ? sub.host + " · VPN" : "VPN Server");
        if (tvIpFlag     != null) tvIpFlag.setText(sub != null ? sub.getEmoji() : "🔒");
    }

    // ─── Timer / speed / pulse ────────────────────────────────────────────────

    private void startTimer() {
        timerR = new Runnable() {
            public void run() {
                if (!isAdded() || !st.connected) return;
                st.timerSec++;
                if (tvTimer != null) tvTimer.setText(String.format(Locale.US,
                    "%02d:%02d:%02d", st.timerSec / 3600, (st.timerSec % 3600) / 60, st.timerSec % 60));
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(timerR);
    }

    private void startSpeed() {
        speedR = new Runnable() {
            public void run() {
                if (!isAdded() || !st.connected) return;
                double dl = 1 + rnd.nextDouble() * 12;
                double ul = 0.2 + rnd.nextDouble() * 4;
                if (tvDl != null) tvDl.setText(String.format(Locale.US, "%.1f MB/s", dl));
                if (tvUl != null) tvUl.setText(String.format(Locale.US, "%.1f MB/s", ul));
                handler.postDelayed(this, 1000);
            }
        };
        handler.post(speedR);
    }

    private void startPulse() {
        if (ring1 != null && isAdded()) {
            Animation pulseAnim = AnimationUtils.loadAnimation(requireContext(), R.anim.pulse_ring);
            ring1.startAnimation(pulseAnim);
        }
        pulseR = new Runnable() {
            public void run() {
                if (!isAdded() || !st.connected) return;
                handler.postDelayed(this, 2000);
            }
        };
        handler.post(pulseR);
    }

    private void stopAll() {
        if (btnConnect != null) btnConnect.clearAnimation();
        if (timerR != null) handler.removeCallbacks(timerR);
        if (speedR != null) handler.removeCallbacks(speedR);
        if (pulseR != null) handler.removeCallbacks(pulseR);
        if (isAdded() && tvTimer != null) tvTimer.setText("");
        if (ring1 != null) { ring1.clearAnimation(); ring1.setAlpha(0.08f); }
    }

    // ─── QR handling ──────────────────────────────────────────────────────────

    private void handleQr(String txt) {
        if (txt == null || txt.isEmpty()) { toast("QR пустой"); return; }
        if (txt.startsWith("http")) {
            Subscription sub = new Subscription(UUID.randomUUID().toString(), "QR Подписка", txt);
            st.subscriptions.add(sub);
            MainActivity.get(this).saveState();
            renderSubscriptions();
            refreshSubscription(sub);
            return;
        }
        SubServer s = SubscriptionParser.parseUri(txt);
        if (s != null) {
            CustomServer cs = new CustomServer(s.name, s.host, s.port, s.proto);
            cs.rawConfig = s.rawConfig;
            st.customServer = cs;
            st.selectedServerId = -2; st.selectedSubId = null;
            MainActivity.get(this).saveState();
            updateCustomServerView(); updateSelCard();
            toast("Сервер добавлен: " + s.name);
            return;
        }
        toast("Неподдерживаемый QR");
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private String getConnName() {
        SubServer sub = st.getSelectedSubServer();
        if (sub != null) return sub.name;
        if (st.customServer != null) return st.customServer.name;
        return "Сервер";
    }

    private String ccToFlag(String cc) {
        if (cc == null || cc.length() != 2) return "🌐";
        try {
            return new String(Character.toChars(cc.charAt(0) - 'A' + 0x1F1E6))
                 + new String(Character.toChars(cc.charAt(1) - 'A' + 0x1F1E6));
        } catch (Exception e) { return "🌐"; }
    }

    private void toast(String msg) {
        if (isAdded()) MainActivity.get(this).showToast(msg);
    }

    @Override public void onDestroyView() {
        stopAll();
        PulseVpnService.clearListener();
        super.onDestroyView();
    }
}
