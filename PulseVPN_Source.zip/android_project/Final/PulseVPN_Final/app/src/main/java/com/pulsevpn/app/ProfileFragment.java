package com.pulsevpn.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

import java.util.List;

/**
 * ProfileFragment — user account + stats + log.
 *
 * Auth flow:
 *   LocalAuth (name + email + password stored in SharedPreferences) is the primary auth.
 *   Google Sign-In is an optional alternative — shown if Google Play Services available.
 */
public class ProfileFragment extends Fragment {
    private static final int RC_SIGN_IN = 9001;

    private AppState         st;
    private GoogleSignInClient googleClient;

    // Auth panels
    private LinearLayout panelAuth, panelUser;
    // Auth inputs
    private EditText etAuthName, etAuthEmail, etAuthPass;
    // User panel views
    private TextView tvAvatar, tvDisplayName, tvUserEmail;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inflater.inflate(R.layout.fragment_profile, container, false);
        st = AppState.get();

        // ─── Google Sign-In (optional) ─────────────────────────────────────
        try {
            GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail().build();
            googleClient = GoogleSignIn.getClient(requireActivity(), gso);

            // Sync any existing Google session into LocalAuth
            GoogleSignInAccount ga = GoogleSignIn.getLastSignedInAccount(requireContext());
            if (ga != null && !LocalAuth.isLoggedIn(requireContext())) {
                LocalAuth.loginGoogle(requireContext(), ga.getDisplayName(), ga.getEmail());
            }
        } catch (Exception ignored) {}

        // ─── Bind auth views ───────────────────────────────────────────────
        panelAuth    = v.findViewById(R.id.panel_auth);
        panelUser    = v.findViewById(R.id.panel_user);
        etAuthName   = v.findViewById(R.id.et_auth_name);
        etAuthEmail  = v.findViewById(R.id.et_auth_email);
        etAuthPass   = v.findViewById(R.id.et_auth_pass);
        tvAvatar     = v.findViewById(R.id.tv_avatar);
        tvDisplayName = v.findViewById(R.id.tv_display_name);
        tvUserEmail  = v.findViewById(R.id.tv_user_email);

        // ─── Submit (local auth) ───────────────────────────────────────────
        TextView btnSubmit = v.findViewById(R.id.btn_auth_submit);
        if (btnSubmit != null) {
            btnSubmit.setOnClickListener(vv -> {
                String name  = etAuthName  != null ? etAuthName.getText().toString().trim()  : "";
                String email = etAuthEmail != null ? etAuthEmail.getText().toString().trim() : "";
                String pass  = etAuthPass  != null ? etAuthPass.getText().toString()          : "";
                if (name.isEmpty()) { toast("Введи своё имя"); return; }
                if (email.isEmpty() || !email.contains("@")) { toast("Введи корректный email"); return; }
                if (pass.length() < 4) { toast("Пароль минимум 4 символа"); return; }
                LocalAuth.loginLocal(requireContext(), name, email, pass);
                refreshAuthState();
                toast("Добро пожаловать, " + name + "!");
            });
        }

        // ─── Google Sign-In button ─────────────────────────────────────────
        TextView btnGoogle = v.findViewById(R.id.btn_google_signin);
        if (btnGoogle != null) {
            btnGoogle.setOnClickListener(vv -> {
                if (googleClient != null) {
                    try {
                        startActivityForResult(googleClient.getSignInIntent(), RC_SIGN_IN);
                    } catch (Exception e) {
                        toast("Google Sign-In недоступен на этом устройстве");
                    }
                } else {
                    toast("Google Play Services не найдены");
                }
            });
        }

        // ─── Logout ────────────────────────────────────────────────────────
        TextView btnLogout = v.findViewById(R.id.btn_logout);
        if (btnLogout != null) {
            btnLogout.setOnClickListener(vv -> {
                LocalAuth.logout(requireContext());
                if (googleClient != null) {
                    try { googleClient.signOut(); } catch (Exception ignored) {}
                }
                refreshAuthState();
                toast("Вышел из аккаунта");
            });
        }

        refreshAuthState();

        // ─── Stats ─────────────────────────────────────────────────────────
        TextView tvSubCount = v.findViewById(R.id.tv_sub_count);
        TextView tvSrvCount = v.findViewById(R.id.tv_srv_count);
        TextView tvVersion  = v.findViewById(R.id.tv_version);
        if (tvSubCount != null) tvSubCount.setText(String.valueOf(st.subscriptions.size()));
        if (tvSrvCount != null) tvSrvCount.setText(String.valueOf(st.getTotalServerCount()));
        if (tvVersion  != null) tvVersion.setText("PulseVPN v6.0");

        // ─── Premium buy button ────────────────────────────────────────────
        TextView btnBuy = v.findViewById(R.id.btn_buy);
        if (btnBuy != null) {
            btnBuy.setOnClickListener(vv -> {
                requireActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .setCustomAnimations(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
                    .replace(R.id.fragment_container, new PaywallFragment())
                    .addToBackStack("paywall")
                    .commit();
            });
        }

        // ─── Connection log ────────────────────────────────────────────────
        LinearLayout logContainer = v.findViewById(R.id.log_container);
        renderLog(inflater, logContainer);

        TextView btnClearLog = v.findViewById(R.id.btn_clear_log);
        if (btnClearLog != null) {
            btnClearLog.setOnClickListener(vv -> {
                ConnectionLog.clear();
                renderLog(inflater, logContainer);
                toast("Лог очищен");
            });
        }

        return v;
    }

    @Override
    public void onActivityResult(int req, int res, @Nullable Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_SIGN_IN) {
            try {
                Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                GoogleSignInAccount account = task.getResult(ApiException.class);
                LocalAuth.loginGoogle(requireContext(),
                    account.getDisplayName(), account.getEmail());
                refreshAuthState();
                toast("Вошёл как " + LocalAuth.getName(requireContext()));
            } catch (ApiException e) {
                if (e.getStatusCode() == 10) {
                    toast("Google Sign-In: добавь SHA-1 в Google Console");
                } else {
                    toast("Ошибка Google входа: " + e.getStatusCode());
                }
            } catch (Exception e) {
                toast("Google Sign-In ошибка");
            }
        }
    }

    private void refreshAuthState() {
        if (!isAdded()) return;
        boolean loggedIn = LocalAuth.isLoggedIn(requireContext());

        if (panelAuth != null) panelAuth.setVisibility(loggedIn ? View.GONE  : View.VISIBLE);
        if (panelUser != null) panelUser.setVisibility(loggedIn ? View.VISIBLE : View.GONE);

        if (loggedIn) {
            String name  = LocalAuth.getName(requireContext());
            String email = LocalAuth.getEmail(requireContext());
            if (tvDisplayName != null) tvDisplayName.setText(name);
            if (tvUserEmail   != null) tvUserEmail.setText(email.isEmpty() ? "Локальный аккаунт" : email);
            if (tvAvatar != null && !name.isEmpty()) {
                tvAvatar.setText(String.valueOf(name.charAt(0)).toUpperCase());
            }
        }
    }

    private void renderLog(LayoutInflater inflater, LinearLayout container) {
        if (container == null) return;
        container.removeAllViews();
        List<ConnectionLog> logs = ConnectionLog.getAll();
        if (logs.isEmpty()) {
            TextView empty = new TextView(requireContext());
            empty.setText("Нет записей");
            empty.setTextColor(0xFF4A6A64);
            empty.setTextSize(12);
            empty.setPadding(0, 8, 0, 8);
            container.addView(empty);
        } else {
            int shown = 0;
            for (ConnectionLog log : logs) {
                if (shown++ >= 10) break;
                View item = inflater.inflate(R.layout.item_log, container, false);
                TextView ti = item.findViewById(R.id.tv_log_icon);
                TextView tm = item.findViewById(R.id.tv_log_msg);
                TextView tt = item.findViewById(R.id.tv_log_time);
                if (ti != null) { ti.setText(log.getIcon()); ti.setTextColor(log.getColor()); }
                if (tm != null) tm.setText(log.message);
                if (tt != null) tt.setText(log.getTimeText());
                container.addView(item);
            }
        }
    }

    private void toast(String msg) {
        if (isAdded()) MainActivity.get(this).showToast(msg);
    }
}
