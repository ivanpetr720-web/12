package com.pulsevpn.app;

public class SubServer {
    public String name;
    public String host;
    public String port;
    public String proto;
    public String rawConfig;
    public int    pingMs = -1;
    public String subscriptionId;

    public SubServer(String name, String host, String port, String proto, String rawConfig) {
        this.name      = name      != null ? name      : "Server";
        this.host      = host      != null ? host      : "";
        this.port      = port      != null ? port      : "443";
        this.proto     = proto     != null ? proto     : "auto";
        this.rawConfig = rawConfig != null ? rawConfig : "";
    }

    public String getEmoji() {
        if (host == null || host.isEmpty()) return "🌐";
        String h = host.toLowerCase();
        if (h.contains("us") || h.contains("usa") || h.contains("america")) return "🇺🇸";
        if (h.contains("de") || h.contains("germany") || h.contains("frankfurt")) return "🇩🇪";
        if (h.contains("nl") || h.contains("netherlands") || h.contains("amsterdam")) return "🇳🇱";
        if (h.contains("uk") || h.contains("london") || h.contains("britain")) return "🇬🇧";
        if (h.contains("fr") || h.contains("france") || h.contains("paris")) return "🇫🇷";
        if (h.contains("sg") || h.contains("singapore")) return "🇸🇬";
        if (h.contains("jp") || h.contains("japan") || h.contains("tokyo")) return "🇯🇵";
        if (h.contains("ru") || h.contains("russia") || h.contains("moscow")) return "🇷🇺";
        if (h.contains("se") || h.contains("sweden") || h.contains("stockholm")) return "🇸🇪";
        if (h.contains("ch") || h.contains("swiss")) return "🇨🇭";
        if (h.contains("fi") || h.contains("finland")) return "🇫🇮";
        if (h.contains("ca") || h.contains("canada") || h.contains("toronto")) return "🇨🇦";
        if (h.contains("au") || h.contains("australia") || h.contains("sydney")) return "🇦🇺";
        return "🌐";
    }

    public String getProtoLabel() {
        if (proto == null) return "Auto";
        switch (proto.toLowerCase()) {
            case "wireguard": case "wg": return "WireGuard";
            case "openvpn":  case "ovpn": return "OpenVPN";
            case "shadowsocks": case "ss": return "SS";
            case "vmess":   return "VMess";
            case "vless":   return "VLess";
            case "trojan":  return "Trojan";
            default:
                if (proto.length() > 0)
                    return proto.substring(0, 1).toUpperCase() + proto.substring(1);
                return proto;
        }
    }

    public String getPingText() {
        if (pingMs < 0) return "—";
        return pingMs + "ms";
    }

    public int getPingColor() {
        if (pingMs < 0)   return 0xFF4A6A64;
        if (pingMs < 80)  return 0xFF00FF88;
        if (pingMs < 200) return 0xFFFFCC00;
        return 0xFFFF4466;
    }

    public String getPingBars() {
        if (pingMs < 0)   return "▮▯▯▯";
        if (pingMs < 80)  return "▮▮▮▮";
        if (pingMs < 150) return "▮▮▮▯";
        if (pingMs < 300) return "▮▮▯▯";
        return "▮▯▯▯";
    }
}
