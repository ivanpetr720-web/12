# WireGuard
-keep class com.wireguard.** { *; }
-keep class org.bouncycastle.** { *; }

# ZXing QR
-keep class com.google.zxing.** { *; }
-keep class com.journeyapps.** { *; }

# App data models
-keep class com.pulsevpn.app.AppState { *; }
-keep class com.pulsevpn.app.Subscription { *; }
-keep class com.pulsevpn.app.SubServer { *; }
-keep class com.pulsevpn.app.CustomServer { *; }
-keep class com.pulsevpn.app.Server { *; }
-keep class com.pulsevpn.app.ConnectionLog { *; }

# Keep service classes
-keep class com.pulsevpn.app.PulseVpnService { *; }
-keep class com.pulsevpn.app.VpnManager { *; }
-keep class com.pulsevpn.app.WireGuardManager { *; }

# JSON (org.json is part of Android SDK, no rules needed)

# Remove logging in release
-assumenosideeffects class android.util.Log {
    public static int v(...);
    public static int d(...);
    public static int i(...);
}

# Google Play Services (Sign-In)
-keep class com.google.android.gms.** { *; }
-keep class com.google.android.gms.auth.** { *; }
-keep class com.google.android.gms.common.** { *; }
-dontwarn com.google.android.gms.**

# Google Play Billing
-keep class com.android.billingclient.** { *; }
-keep interface com.android.billingclient.api.** { *; }
-dontwarn com.android.billingclient.**

# Standard Android rules
-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*
-dontwarn okhttp3.**
-dontwarn okio.**
