package com.pulsevpn.app;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import java.util.List;

public class ServersFragment extends Fragment {

    private LinearLayout serverListContainer;
    private TextView tabFree, tabPremium;
    private EditText etSearch;
    private boolean showFree = true;
    private AppState st;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inflater.inflate(R.layout.fragment_servers, container, false);
        st = AppState.get();

        serverListContainer = v.findViewById(R.id.server_list_container);
        tabFree    = v.findViewById(R.id.tab_free);
        tabPremium = v.findViewById(R.id.tab_premium);
        etSearch   = v.findViewById(R.id.et_search);

        tabFree.setOnClickListener(view -> switchTab(true));
        tabPremium.setOnClickListener(view -> switchTab(false));

        etSearch.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int i, int c, int a) {}
            public void onTextChanged(CharSequence s, int i, int b2, int c) { renderList(); }
            public void afterTextChanged(Editable s) {}
        });

        renderList();
        return v;
    }

    private void switchTab(boolean free) {
        showFree = free;
        int black = Color.parseColor("#000000");
        int dim   = Color.parseColor("#8CA8A0");
        if (free) {
            tabFree.setBackgroundResource(R.drawable.btn_green);
            tabFree.setTextColor(black);
            tabPremium.setBackgroundColor(Color.TRANSPARENT);
            tabPremium.setTextColor(dim);
        } else {
            tabPremium.setBackgroundResource(R.drawable.btn_green);
            tabPremium.setTextColor(black);
            tabFree.setBackgroundColor(Color.TRANSPARENT);
            tabFree.setTextColor(dim);
        }
        renderList();
    }

    private void renderList() {
        if (serverListContainer == null) return;
        serverListContainer.removeAllViews();
        String q = etSearch.getText().toString().toLowerCase().trim();

        // Filter without stream API
        List<Server> filtered = new ArrayList<>();
        for (Server s : ServerData.ALL) {
            if (s.isFree != showFree) continue;
            if (!q.isEmpty() && !s.name.toLowerCase().contains(q) && !s.city.toLowerCase().contains(q)) continue;
            filtered.add(s);
        }

        if (!showFree) {
            View header = LayoutInflater.from(getContext()).inflate(R.layout.item_server, serverListContainer, false);
            LinearLayout root = header.findViewById(R.id.server_card_root);
            root.setBackgroundResource(R.drawable.premium_card_bg);
            TextView flag = header.findViewById(R.id.tv_flag);
            flag.setText("✨");
            TextView name = header.findViewById(R.id.tv_name);
            name.setText("Premium серверы");
            name.setTextColor(Color.parseColor("#00FF88"));
            TextView sub = header.findViewById(R.id.tv_sub);
            sub.setText("9 серверов по всему миру");
            header.findViewById(R.id.tv_ping).setVisibility(View.GONE);
            header.findViewById(R.id.tv_bars).setVisibility(View.GONE);
            serverListContainer.addView(header);
        }

        if (filtered.isEmpty()) {
            TextView empty = new TextView(getContext());
            empty.setText("Серверов не найдено");
            empty.setTextColor(Color.parseColor("#8CA8A0"));
            empty.setTextSize(14);
            empty.setPadding(0, 32, 0, 32);
            empty.setGravity(android.view.Gravity.CENTER);
            serverListContainer.addView(empty);
            return;
        }

        for (Server srv : filtered) addServerCard(srv);
    }

    private void addServerCard(Server srv) {
        View card = LayoutInflater.from(getContext()).inflate(R.layout.item_server, serverListContainer, false);
        LinearLayout root  = card.findViewById(R.id.server_card_root);
        TextView tvFlag    = card.findViewById(R.id.tv_flag);
        TextView tvName    = card.findViewById(R.id.tv_name);
        TextView tvSub     = card.findViewById(R.id.tv_sub);
        TextView tvPing    = card.findViewById(R.id.tv_ping);
        TextView tvBars    = card.findViewById(R.id.tv_bars);
        TextView tvTag     = card.findViewById(R.id.tv_tag);
        TextView tvLocked  = card.findViewById(R.id.tv_locked);

        tvFlag.setText(srv.flag);
        tvName.setText(srv.name);
        tvSub.setText(srv.city + " · " + srv.proto);
        tvBars.setText(srv.getBarsText());

        if (srv.tag != null && !srv.tag.isEmpty()) {
            tvTag.setText(srv.tag);
            tvTag.setVisibility(View.VISIBLE);
        }

        int pingColor;
        if (srv.ping < 50) pingColor = Color.parseColor("#00FF88");
        else if (srv.ping < 100) pingColor = Color.parseColor("#FFCC00");
        else pingColor = Color.parseColor("#FF4466");
        tvPing.setText(srv.ping + "ms");
        tvPing.setTextColor(pingColor);

        if (st.selectedServerId == srv.id) {
            root.setBackgroundResource(R.drawable.card_selected);
        }

        if (!srv.isFree && tvLocked != null) {
            tvLocked.setVisibility(View.VISIBLE);
        }

        card.setOnClickListener(v -> {
            if (!srv.isFree) {
                MainActivity.get(this).showToast("🔒 Нужен Premium · Купи в Аккаунте");
                MainActivity.get(this).openPaywall();
                return;
            }
            st.selectedServerId = srv.id;
            renderList();
            MainActivity.get(this).showToast(srv.flag + " Выбран: " + srv.name + ", " + srv.city);
        });

        serverListContainer.addView(card);
    }
}
