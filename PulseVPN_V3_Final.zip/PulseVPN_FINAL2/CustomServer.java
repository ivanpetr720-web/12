package com.pulsevpn.app;

public class CustomServer {
    public String name;
    public String host;
    public String port;
    public String proto;
    public String subUrl; // URL subscription
    public boolean isSubscription;

    public CustomServer(String name, String host, String port, String proto) {
        this.name = name; this.host = host; this.port = port; this.proto = proto;
        this.isSubscription = false;
    }

    public CustomServer(String name, String subUrl) {
        this.name = name; this.subUrl = subUrl;
        this.host = extractHostFromUrl(subUrl);
        this.port = "443"; this.proto = "auto";
        this.isSubscription = true;
    }

    private String extractHostFromUrl(String url) {
        try {
            String h = url.replace("https://","").replace("http://","");
            return h.contains("/") ? h.substring(0, h.indexOf('/')) : h;
        } catch (Exception e) { return url; }
    }

    public String getDisplayHost() {
        return isSubscription ? (subUrl != null ? subUrl : host) : host + ":" + port;
    }

    public String getProtoDisplay() {
        if (isSubscription) return "URL подписка";
        return proto.equals("wireguard") ? "WireGuard" : "OpenVPN";
    }

    public String serialize() {
        return name + "|" + (host!=null?host:"") + "|" + (port!=null?port:"") + "|" +
               (proto!=null?proto:"") + "|" + (isSubscription?"1":"0") + "|" + (subUrl!=null?subUrl:"");
    }

    public static CustomServer deserialize(String s) {
        if (s == null || s.isEmpty()) return null;
        try {
            String[] p = s.split("\\|", -1);
            if (p.length >= 6 && "1".equals(p[4])) {
                CustomServer cs = new CustomServer(p[0], p[5]);
                return cs;
            }
            if (p.length >= 4) return new CustomServer(p[0], p[1], p[2], p[3]);
        } catch (Exception e) { return null; }
        return null;
    }
}
