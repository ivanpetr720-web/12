package com.pulsevpn.app;

  import android.app.Activity;
  import android.content.Context;
  import android.content.Intent;
  import android.net.VpnService;
  import java.util.List;

  public class VpnManager {

      public interface ConnectCallback {
          void onPermissionNeeded(Intent intent);
          void onStarted();
          void onError(String msg);
      }

      public static void connect(Context ctx, String host, String port, String proto, String config, ConnectCallback cb) {
          Intent prepare = VpnService.prepare(ctx);
          if (prepare != null) {
              if (cb != null) cb.onPermissionNeeded(prepare);
              return;
          }
          startVpn(ctx, host, port, proto, config);
          if (cb != null) cb.onStarted();
      }

      private static void startVpn(Context ctx, String host, String port, String proto, String config) {
          Intent i = new Intent(ctx, PulseVpnService.class);
          i.setAction(PulseVpnService.ACTION_CONNECT);
          i.putExtra(PulseVpnService.EXTRA_HOST, host);
          i.putExtra(PulseVpnService.EXTRA_PORT, port);
          i.putExtra(PulseVpnService.EXTRA_PROTO, proto);
          i.putExtra(PulseVpnService.EXTRA_CONFIG, config);
          ctx.startForegroundService(i);
      }

      public static void disconnect(Context ctx) {
          Intent i = new Intent(ctx, PulseVpnService.class);
          i.setAction(PulseVpnService.ACTION_DISCONNECT);
          ctx.startService(i);
      }

      public static boolean isConnected() {
          return AppState.get().connected;
      }
  }