package com.pulsevpn.app;

import java.util.ArrayList;
import java.util.List;

public class AppState {
    private static AppState instance;

    public boolean connected = false;
    public boolean connecting = false;
    public int selectedServerId = -1; // -1=Smart, -2=Custom
    public String protocol = "wireguard";
    public int timerSec = 0;
    public double dlMbps = 0;
    public double ulMbps = 0;
    public String realIp = "";
    public String realCountry = "";
    public String realFlag = "🌐";
    public boolean ipLoaded = false;
    public boolean isPremium = false;
    public CustomServer customServer = null;

    public static AppState get() {
        if (instance == null) instance = new AppState();
        return instance;
    }

    public Server getSelectedServer() {
        if (selectedServerId <= 0) return null;
        for (Server s : ServerData.ALL) {
            if (s.id == selectedServerId) return s;
        }
        return null;
    }

    public boolean isCustomSelected() {
        return selectedServerId == -2 && customServer != null;
    }
}
