package com.pulsevpn.app;

  import java.io.BufferedReader;
  import java.io.InputStreamReader;
  import java.net.HttpURLConnection;
  import java.net.URL;
  import java.util.ArrayList;
  import java.util.Base64;
  import java.util.List;

  public class SubscriptionParser {

      public static class ParsedServer {
          public String name;
          public String host;
          public String port;
          public String proto; // wireguard / shadowsocks / vmess
          public String extra; // full config string
          public ParsedServer(String name, String host, String port, String proto, String extra) {
              this.name=name; this.host=host; this.port=port; this.proto=proto; this.extra=extra;
          }
      }

      public interface Callback {
          void onSuccess(List<ParsedServer> servers);
          void onError(String error);
      }

      public static void parseUrl(String subUrl, Callback cb) {
          new Thread(() -> {
              try {
                  String content = fetchUrl(subUrl);
                  if (content == null || content.isEmpty()) { cb.onError("Пустой ответ от сервера"); return; }
                  List<ParsedServer> servers = parseContent(content, subUrl);
                  if (servers.isEmpty()) { cb.onError("Серверы не найдены в подписке"); return; }
                  cb.onSuccess(servers);
              } catch (Exception e) {
                  cb.onError("Ошибка: " + e.getMessage());
              }
          }).start();
      }

      private static String fetchUrl(String urlStr) throws Exception {
          HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
          c.setConnectTimeout(10000); c.setReadTimeout(10000);
          c.setRequestProperty("User-Agent","PulseVPN/3.0");
          c.setRequestProperty("Accept","text/plain,application/json,*/*");
          BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream()));
          StringBuilder sb = new StringBuilder(); String line;
          while ((line = br.readLine()) != null) sb.append(line).append("\n");
          br.close();
          return sb.toString().trim();
      }

      private static List<ParsedServer> parseContent(String content, String originalUrl) {
          List<ParsedServer> result = new ArrayList<>();
          // Try Base64 decode first (common for v2ray/ss subscriptions)
          String decoded = tryBase64Decode(content);
          String toParse = (decoded != null && decoded.contains("://")) ? decoded : content;

          String[] lines = toParse.split("[\r\n]+");
          int idx = 1;
          for (String line : lines) {
              line = line.trim();
              if (line.isEmpty()) continue;
              ParsedServer s = parseLine(line, idx);
              if (s != null) { result.add(s); idx++; }
          }

          // If no URI lines found, try as WireGuard config
          if (result.isEmpty() && toParse.contains("[Interface]")) {
              ParsedServer wg = parseWireGuardConfig(toParse, "WireGuard сервер");
              if (wg != null) result.add(wg);
          }

          // If still nothing, treat as Clash YAML - just add placeholder
          if (result.isEmpty() && (toParse.contains("proxies:") || toParse.contains("proxy-groups:"))) {
              result.addAll(parseClashYaml(toParse));
          }

          return result;
      }

      private static ParsedServer parseLine(String line, int idx) {
          try {
              if (line.startsWith("ss://")) {
                  // Shadowsocks: ss://BASE64(method:password)@host:port#name
                  String rest = line.substring(5);
                  String name = "Shadowsocks " + idx;
                  if (rest.contains("#")) {
                      name = java.net.URLDecoder.decode(rest.substring(rest.lastIndexOf('#')+1), "UTF-8");
                      rest = rest.substring(0, rest.lastIndexOf('#'));
                  }
                  String hostPort = rest.contains("@") ? rest.substring(rest.lastIndexOf('@')+1) : "unknown:443";
                  String[] hp = hostPort.split(":");
                  return new ParsedServer(name, hp[0], hp.length>1?hp[1]:"443", "shadowsocks", line);
              }
              if (line.startsWith("vmess://")) {
                  String json = tryBase64Decode(line.substring(8));
                  if (json != null) {
                      String add = extractJsonField(json, "add");
                      String port = extractJsonField(json, "port");
                      String ps = extractJsonField(json, "ps");
                      if (ps == null || ps.isEmpty()) ps = "VMess " + idx;
                      if (add != null) return new ParsedServer(ps, add, port != null ? port : "443", "vmess", line);
                  }
              }
              if (line.startsWith("vless://")) {
                  // vless://uuid@host:port?params#name
                  String rest = line.substring(8);
                  String name = "VLESS " + idx;
                  if (rest.contains("#")) {
                      name = java.net.URLDecoder.decode(rest.substring(rest.lastIndexOf('#')+1), "UTF-8");
                      rest = rest.substring(0, rest.lastIndexOf('#'));
                  }
                  if (rest.contains("@")) rest = rest.substring(rest.indexOf('@')+1);
                  if (rest.contains("?")) rest = rest.substring(0, rest.indexOf('?'));
                  String[] hp = rest.split(":");
                  return new ParsedServer(name, hp[0], hp.length>1?hp[1]:"443", "vless", line);
              }
              if (line.startsWith("trojan://")) {
                  String rest = line.substring(9);
                  String name = "Trojan " + idx;
                  if (rest.contains("#")) {
                      name = java.net.URLDecoder.decode(rest.substring(rest.lastIndexOf('#')+1), "UTF-8");
                      rest = rest.substring(0, rest.lastIndexOf('#'));
                  }
                  if (rest.contains("@")) rest = rest.substring(rest.indexOf('@')+1);
                  if (rest.contains("?")) rest = rest.substring(0, rest.indexOf('?'));
                  String[] hp = rest.split(":");
                  return new ParsedServer(name, hp[0], hp.length>1?hp[1]:"443", "trojan", line);
              }
              if (line.startsWith("wireguard://") || line.startsWith("wg://")) {
                  String rest = line.contains("://") ? line.substring(line.indexOf("://")+3) : line;
                  String name = "WireGuard " + idx;
                  if (rest.contains("#")) {
                      name = rest.substring(rest.lastIndexOf('#')+1);
                      rest = rest.substring(0, rest.lastIndexOf('#'));
                  }
                  if (rest.contains("@")) rest = rest.substring(rest.indexOf('@')+1);
                  if (rest.contains("?")) rest = rest.substring(0, rest.indexOf('?'));
                  String[] hp = rest.split(":");
                  return new ParsedServer(name, hp[0], hp.length>1?hp[1]:"51820", "wireguard", line);
              }
          } catch (Exception ignored) {}
          return null;
      }

      private static ParsedServer parseWireGuardConfig(String config, String name) {
          String endpoint = extractConfigField(config, "Endpoint");
          if (endpoint == null) return null;
          String[] hp = endpoint.split(":");
          return new ParsedServer(name, hp[0], hp.length>1?hp[1]:"51820", "wireguard", config);
      }

      private static List<ParsedServer> parseClashYaml(String yaml) {
          List<ParsedServer> result = new ArrayList<>();
          String[] lines = yaml.split("[\r\n]+");
          boolean inProxies = false;
          String name=null, server=null, port=null, type=null;
          for (String line : lines) {
              if (line.trim().equals("proxies:")) { inProxies = true; continue; }
              if (inProxies && line.startsWith("  - name:")) {
                  if (name!=null && server!=null) result.add(new ParsedServer(name, server, port!=null?port:"443", type!=null?type:"auto",""));
                  name=line.substring(line.indexOf(':')+1).trim().replace("\"","");
                  server=null; port=null; type=null;
              }
              if (inProxies && line.contains("server:")) server=line.substring(line.indexOf(':')+1).trim();
              if (inProxies && line.contains("port:")) port=line.substring(line.indexOf(':')+1).trim();
              if (inProxies && line.trim().startsWith("type:")) type=line.substring(line.indexOf(':')+1).trim();
              if (!line.startsWith(" ") && !line.startsWith("-") && !line.isEmpty() && inProxies && !line.trim().startsWith("-")) inProxies=false;
          }
          if (name!=null && server!=null) result.add(new ParsedServer(name, server, port!=null?port:"443", type!=null?type:"auto",""));
          return result;
      }

      private static String tryBase64Decode(String s) {
          try {
              byte[] decoded = Base64.decode(s.trim(), Base64.DEFAULT);
              return new String(decoded, "UTF-8");
          } catch (Exception e) { return null; }
      }

      private static String extractJsonField(String json, String key) {
          String search = "\"" + key + "\"";
          int i = json.indexOf(search);
          if (i < 0) return null;
          int colon = json.indexOf(':', i + search.length());
          if (colon < 0) return null;
          int start = colon + 1;
          while (start < json.length() && (json.charAt(start)==' '||json.charAt(start)=='\"')) start++;
          int end = start;
          while (end < json.length() && json.charAt(end) != '"' && json.charAt(end) != ',' && json.charAt(end) != '}') end++;
          return json.substring(start, end).trim().replace("\"","");
      }

      private static String extractConfigField(String config, String key) {
          for (String line : config.split("[\r\n]+")) {
              if (line.trim().startsWith(key + " =") || line.trim().startsWith(key + "=")) {
                  int eq = line.indexOf('=');
                  return line.substring(eq+1).trim();
              }
          }
          return null;
      }
  }