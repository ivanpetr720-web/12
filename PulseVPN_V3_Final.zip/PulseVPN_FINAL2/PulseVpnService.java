package com.pulsevpn.app;

  import android.app.Notification;
  import android.app.NotificationChannel;
  import android.app.NotificationManager;
  import android.app.PendingIntent;
  import android.content.Intent;
  import android.net.VpnService;
  import android.os.Build;
  import android.os.Handler;
  import android.os.Looper;
  import android.os.ParcelFileDescriptor;
  import java.io.FileInputStream;
  import java.io.FileOutputStream;
  import java.io.IOException;
  import java.net.InetSocketAddress;
  import java.nio.ByteBuffer;
  import java.nio.channels.DatagramChannel;

  public class PulseVpnService extends VpnService {

      public static final String ACTION_CONNECT = "com.pulsevpn.app.CONNECT";
      public static final String ACTION_DISCONNECT = "com.pulsevpn.app.DISCONNECT";
      public static final String EXTRA_HOST = "host";
      public static final String EXTRA_PORT = "port";
      public static final String EXTRA_PROTO = "proto";
      public static final String EXTRA_CONFIG = "config";
      private static final String CHANNEL_ID = "pulsevpn_channel";
      private static final int NOTIF_ID = 1;

      private ParcelFileDescriptor vpnInterface;
      private Thread vpnThread;
      private boolean running = false;
      private static PulseVpnService instance;
      private static StateListener stateListener;

      public interface StateListener {
          void onConnected();
          void onDisconnected();
          void onError(String msg);
      }

      public static void setStateListener(StateListener l) { stateListener = l; }
      public static PulseVpnService getInstance() { return instance; }

      @Override
      public void onCreate() {
          super.onCreate();
          instance = this;
          createNotificationChannel();
      }

      @Override
      public int onStartCommand(Intent intent, int flags, int startId) {
          if (intent == null) { stopSelf(); return START_NOT_STICKY; }
          if (ACTION_DISCONNECT.equals(intent.getAction())) {
              disconnect(); return START_NOT_STICKY;
          }
          String host   = intent.getStringExtra(EXTRA_HOST);
          String port   = intent.getStringExtra(EXTRA_PORT);
          String proto  = intent.getStringExtra(EXTRA_PROTO);
          String config = intent.getStringExtra(EXTRA_CONFIG);
          connect(host, port, proto, config);
          return START_STICKY;
      }

      private void connect(String host, String port, String proto, String config) {
          running = true;
          startForeground(NOTIF_ID, buildNotification("Подключение…"));
          vpnThread = new Thread(() -> {
              try {
                  Builder b = new Builder();
                  b.setSession("PulseVPN");
                  b.addAddress("10.8.0.2", 24);
                  b.addRoute("0.0.0.0", 0);
                  b.addDnsServer("1.1.1.1");
                  b.addDnsServer("8.8.8.8");
                  b.setMtu(1500);
                  vpnInterface = b.establish();
                  if (vpnInterface == null) throw new IOException("VPN establish failed");

                  updateNotification("🛡 PulseVPN активен");
                  new Handler(Looper.getMainLooper()).post(() -> {
                      AppState.get().connected = true;
                      AppState.get().connecting = false;
                      if (stateListener != null) stateListener.onConnected();
                  });

                  // Packet forwarding loop
                  runTunnel(host, port != null ? Integer.parseInt(port) : 51820);

              } catch (Exception e) {
                  new Handler(Looper.getMainLooper()).post(() -> {
                      AppState.get().connected = false;
                      AppState.get().connecting = false;
                      if (stateListener != null) stateListener.onError(e.getMessage());
                  });
              } finally {
                  closeTunnel();
                  new Handler(Looper.getMainLooper()).post(() -> {
                      if (stateListener != null && !AppState.get().connected)
                          stateListener.onDisconnected();
                  });
                  stopForeground(true);
                  stopSelf();
              }
          });
          vpnThread.start();
      }

      private void runTunnel(String host, int port) {
          DatagramChannel tunnel = null;
          try {
              tunnel = DatagramChannel.open();
              protect(tunnel.socket());
              tunnel.connect(new InetSocketAddress(host, port));
              tunnel.configureBlocking(false);
              ByteBuffer buf = ByteBuffer.allocate(32767);
              FileInputStream in  = new FileInputStream(vpnInterface.getFileDescriptor());
              FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());
              while (running) {
                  buf.clear();
                  int len = in.read(buf.array());
                  if (len > 0) { buf.limit(len); tunnel.write(buf); }
                  buf.clear();
                  if (tunnel.read(buf) > 0) { buf.flip(); out.write(buf.array(), 0, buf.limit()); }
                  Thread.sleep(5);
              }
          } catch (Exception e) {
              // Tunnel closed
          } finally {
              if (tunnel != null) try { tunnel.close(); } catch (Exception ignored) {}
          }
      }

      public void disconnect() {
          running = false;
          closeTunnel();
          AppState.get().connected = false;
          AppState.get().connecting = false;
          new Handler(Looper.getMainLooper()).post(() -> {
              if (stateListener != null) stateListener.onDisconnected();
          });
          stopForeground(true);
          stopSelf();
      }

      private void closeTunnel() {
          if (vpnInterface != null) {
              try { vpnInterface.close(); } catch (Exception ignored) {}
              vpnInterface = null;
          }
          if (vpnThread != null) { vpnThread.interrupt(); vpnThread = null; }
      }

      private void createNotificationChannel() {
          if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
              NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "PulseVPN", NotificationManager.IMPORTANCE_LOW);
              ch.setDescription("Статус VPN соединения");
              getSystemService(NotificationManager.class).createNotificationChannel(ch);
          }
      }

      private Notification buildNotification(String text) {
          Intent intent = new Intent(this, MainActivity.class);
          PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
              Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
          return new Notification.Builder(this, CHANNEL_ID)
              .setContentTitle("PulseVPN")
              .setContentText(text)
              .setSmallIcon(android.R.drawable.ic_lock_lock)
              .setContentIntent(pi)
              .setOngoing(true)
              .build();
      }

      private void updateNotification(String text) {
          NotificationManager nm = getSystemService(NotificationManager.class);
          if (nm != null) nm.notify(NOTIF_ID, buildNotification(text));
      }

      @Override
      public void onDestroy() {
          instance = null;
          disconnect();
          super.onDestroy();
      }
  }