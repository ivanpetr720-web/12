package com.pulsevpn.app;

  import android.content.Intent;
  import android.os.Bundle;
  import android.os.Handler;
  import android.view.View;
  import android.view.animation.AlphaAnimation;
  import android.view.animation.Animation;
  import android.view.animation.ScaleAnimation;
  import android.view.animation.AnimationSet;
  import android.widget.ImageView;
  import android.widget.TextView;
  import androidx.appcompat.app.AppCompatActivity;

  public class SplashActivity extends AppCompatActivity {

      @Override
      protected void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          setContentView(R.layout.activity_splash);

          View logo = findViewById(R.id.splash_logo);
          TextView title = findViewById(R.id.splash_title);
          TextView subtitle = findViewById(R.id.splash_subtitle);
          View pulse1 = findViewById(R.id.splash_pulse1);
          View pulse2 = findViewById(R.id.splash_pulse2);

          // Animate logo scale + fade
          AnimationSet logoAnim = new AnimationSet(true);
          ScaleAnimation scale = new ScaleAnimation(0.5f, 1f, 0.5f, 1f,
              Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
          scale.setDuration(700);
          AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
          fadeIn.setDuration(700);
          logoAnim.addAnimation(scale);
          logoAnim.addAnimation(fadeIn);
          logoAnim.setFillAfter(true);
          if (logo != null) logo.startAnimation(logoAnim);

          // Animate title
          AlphaAnimation titleAnim = new AlphaAnimation(0f, 1f);
          titleAnim.setDuration(600);
          titleAnim.setStartOffset(400);
          titleAnim.setFillAfter(true);
          if (title != null) { title.setVisibility(View.VISIBLE); title.startAnimation(titleAnim); }

          // Animate subtitle
          AlphaAnimation subAnim = new AlphaAnimation(0f, 1f);
          subAnim.setDuration(600);
          subAnim.setStartOffset(700);
          subAnim.setFillAfter(true);
          if (subtitle != null) { subtitle.setVisibility(View.VISIBLE); subtitle.startAnimation(subAnim); }

          // Pulse rings
          startPulse(pulse1, 0);
          startPulse(pulse2, 400);

          // Go to main after 2.5 seconds
          new Handler().postDelayed(() -> {
              startActivity(new Intent(this, MainActivity.class));
              overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
              finish();
          }, 2500);
      }

      private void startPulse(View v, long delay) {
          if (v == null) return;
          AnimationSet a = new AnimationSet(true);
          ScaleAnimation sc = new ScaleAnimation(0.8f, 1.4f, 0.8f, 1.4f,
              Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
          sc.setDuration(1200);
          sc.setRepeatCount(Animation.INFINITE);
          sc.setRepeatMode(Animation.RESTART);
          AlphaAnimation al = new AlphaAnimation(0.7f, 0f);
          al.setDuration(1200);
          al.setRepeatCount(Animation.INFINITE);
          al.setRepeatMode(Animation.RESTART);
          a.addAnimation(sc);
          a.addAnimation(al);
          a.setStartOffset(delay);
          a.setFillAfter(true);
          v.startAnimation(a);
      }
  }