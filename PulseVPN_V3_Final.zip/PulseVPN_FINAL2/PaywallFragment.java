package com.pulsevpn.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class PaywallFragment extends Fragment {

    private int selectedPlan = 1; // 1, 3, 6, 12 months
    private String[] prices = {"149 ₽", "299 ₽", "499 ₽", "799 ₽"};
    private int[] months = {1, 3, 6, 12};

    private LinearLayout plan1m, plan3m, plan6m, plan12m;
    private TextView radio1m, radio3m, radio6m, radio12m;
    private TextView btnPay;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup container, @Nullable Bundle b) {
        View v = inf.inflate(R.layout.fragment_paywall, container, false);

        plan1m  = v.findViewById(R.id.plan_1m);
        plan3m  = v.findViewById(R.id.plan_3m);
        plan6m  = v.findViewById(R.id.plan_6m);
        plan12m = v.findViewById(R.id.plan_12m);
        radio1m  = v.findViewById(R.id.radio_1m);
        radio3m  = v.findViewById(R.id.radio_3m);
        radio6m  = v.findViewById(R.id.radio_6m);
        radio12m = v.findViewById(R.id.radio_12m);
        btnPay  = v.findViewById(R.id.btn_pay);

        plan1m.setOnClickListener(view  -> selectPlan(0));
        plan3m.setOnClickListener(view  -> selectPlan(1));
        plan6m.setOnClickListener(view  -> selectPlan(2));
        plan12m.setOnClickListener(view -> selectPlan(3));

        btnPay.setOnClickListener(view ->
            MainActivity.get(this).showToast("💳 Оплата скоро! Следи за обновлениями ✨"));

        v.findViewById(R.id.tab_ultra_plan).setOnClickListener(view ->
            MainActivity.get(this).showToast("🔜 Ультра план — скоро!"));

        updatePlanUI();
        return v;
    }

    private void selectPlan(int idx) {
        selectedPlan = idx;
        updatePlanUI();
    }

    private void updatePlanUI() {
        LinearLayout[] plans = {plan1m, plan3m, plan6m, plan12m};
        TextView[] radios = {radio1m, radio3m, radio6m, radio12m};

        for (int i = 0; i < plans.length; i++) {
            if (plans[i] == null || radios[i] == null) continue;
            boolean sel = (i == selectedPlan);
            plans[i].setBackgroundResource(sel ? R.drawable.plan_selected : R.drawable.plan_normal);
            radios[i].setText(sel ? "🔘" : "⭕");
        }

        if (btnPay != null) {
            btnPay.setText("Оплатить — " + months[selectedPlan] +
                (months[selectedPlan] == 1 ? " месяц" :
                 months[selectedPlan] < 5 ? " месяца" : " месяцев") +
                " · " + prices[selectedPlan]);
        }
    }
}
